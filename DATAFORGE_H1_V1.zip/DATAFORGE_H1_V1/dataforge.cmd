@echo off
setlocal
cd /d "%~dp0"
call run.bat %*
set "RC=%ERRORLEVEL%"
endlocal & exit /b %RC%
