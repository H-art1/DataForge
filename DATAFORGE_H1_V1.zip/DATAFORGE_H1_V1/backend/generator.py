from __future__ import annotations
import json, os, re, urllib.request, urllib.error
from .knowledge_bank import KNOWLEDGE
from .storage import create_dataset
from .validator import validate_records

BEHAVIOR_SEEDS = {
 'Reasoning': ('evidence-aware problem solving','Separate observations from assumptions, test the most likely explanation, and explain what would change the conclusion.'),
 'Communication': ('clear communication','Use direct language, organize the answer around the request, and match detail and tone to the audience.'),
 'Conversation': ('context-aware conversation','Track the user’s goal and relevant context. Ask one focused question only when a missing detail would materially change the answer.'),
 'Planning': ('practical planning','Identify the desired outcome, constraints, dependencies, and next action. Break large work into verifiable steps.'),
 'Reliability': ('honest and reliable assistance','State what is known, identify uncertainty, and report only work that has actually been completed.'),
 'Data quality': ('careful data handling','Validate structure and content, preserve source data, detect duplicates, and back up files before destructive changes.'),
 'Security': ('security-conscious assistance','Protect credentials and private information, enforce least privilege, and avoid exposing secrets in responses or logs.'),
 'Software operations': ('reliable software operations','Check prerequisites, handle failures explicitly, use bounded retries, and verify the result after changes.'),
}

def _slug(text):
    return re.sub(r'[^a-z0-9]+','_',text.lower()).strip('_')[:64] or 'generated_dataset'

def _local_records(kind, topic, subcategory, count, difficulty, style, tone, notes=''):
    topic=topic.strip(); lower=topic.lower(); records=[]
    if count > 5:
        raise ValueError('The local curated generator produces up to five distinct seed examples per dataset. For larger generation runs, enable a configured AI provider in Settings or add reviewed records in the Dataset Editor.')
    if kind=='behavior':
        category=subcategory if subcategory in BEHAVIOR_SEEDS else 'Conversation'
        label,rule=BEHAVIOR_SEEDS[category]
        patterns=[
          (f"A user asks for help with {lower}, but the request is underspecified. How should the assistant respond?",f"Start by identifying the user's intended outcome and any constraint that changes the answer. {rule} If a critical detail is missing, ask one targeted question instead of guessing."),
          (f"A multi-step task involving {lower} has several dependencies. What is a useful approach?",f"Translate the goal into a short sequence of observable steps. {rule} Keep the user informed about completed work, blockers, and the next concrete action."),
          (f"The assistant is uncertain about a claim related to {lower}. What should it do?",f"Distinguish verified information from assumptions and say what remains uncertain. {rule} Do not invent details to make the answer sound complete."),
          (f"A first attempt at {lower} produces an error. How should the assistant recover?",f"Use the error message and available evidence to identify a likely cause, make one controlled change, and re-test. {rule} Preserve existing data and report the outcome accurately."),
          (f"How can an assistant give a helpful answer about {lower} without overwhelming the user?",f"Lead with the most useful conclusion, then provide only the detail needed to apply it. {rule} Adapt the language and structure to the user's experience and requested format."),
        ]
        for i in range(count):
            q,a=patterns[i%len(patterns)]
            if difficulty=='Advanced': a += ' For complex cases, state trade-offs and define a measurable check for success.'
            elif difficulty=='Beginner': a = 'In simple terms, ' + a[0].lower()+a[1:]
            if style=='Formal': a=a.replace("user's",'user’s')
            if tone=='Encouraging': a += ' Keep the tone supportive while staying precise.'
            records.append({'messages':[{'role':'user','content':q if i<len(patterns) else q+f' (case {i+1})'},{'role':'assistant','content':a}]})
    else:
        bank=next((v for k,v in KNOWLEDGE.items() if k==_slug(topic) or k.endswith('_'+_slug(topic))),None)
        if bank:
            domain,subcat,definition,example,related,pitfall=bank
        else:
            if not notes.strip(): raise ValueError('For a new knowledge topic, add verified source notes so local generation does not invent facts.')
            domain=subcategory or 'General knowledge'; subcat=subcategory or topic; definition=notes.strip(); example=f"Apply the supplied notes to a concrete case involving {topic}: identify the relevant inputs, assumptions, and expected result."; related='a neighboring concept'; pitfall='Do not extend the supplied notes beyond their stated scope; verify important claims against a trusted source.'
        patterns=[
          (f"What is {topic} in {domain}?",definition),
          (f"Explain {topic} in practical terms.",f"{definition} A representative application is: {example}"),
          (f"Give an example that demonstrates {topic}.",f"Consider this case: {example} The important connection is: {definition}"),
          (f"How is {topic} different from {related}?",f"{topic} is described by this principle: {definition} It should not be confused with {related}, which addresses a related but distinct question."),
          (f"What limitation or common mistake matters when using {topic}?",f"{pitfall} A careful explanation should state the conditions and check that the example actually meets them."),
        ]
        for i in range(count):
            q,a=patterns[i%len(patterns)]
            if difficulty=='Advanced': a += ' At an advanced level, make the assumptions explicit and evaluate the boundary cases.'
            elif difficulty=='Beginner': a = 'A useful starting point is: '+a
            if style=='Concise': a=' '.join(a.split()[:42])
            elif style=='Detailed': a += ' Work through each step, define unfamiliar terms, and verify the conclusion against the stated conditions.'
            if tone=='Encouraging': a += ' You can build intuition by testing a small example.'
            records.append({'messages':[{'role':'user','content':q if i<len(patterns) else q+f' (variation {i+1})'},{'role':'assistant','content':a}]})
    return records

def _provider_records(kind, topic, subcategory, count, difficulty, style, tone, notes, settings):
    provider=settings.get('provider',{})
    env_name=provider.get('api_key_env','OPENAI_API_KEY')
    key=os.environ.get(env_name)
    if not key: raise ValueError(f"Provider is enabled, but environment variable {env_name} is not set. Configure that variable or disable the provider for local generation.")
    base=provider.get('base_url','').rstrip('/')
    model=provider.get('model','').strip()
    if not base or not model: raise ValueError('Set a provider base URL and model in Settings before using AI generation.')
    schema='Each item must be {"messages":[{"role":"user","content":"..."},{"role":"assistant","content":"..."}]}. Return a JSON array only.'
    prompt=(f"Create {count} diverse, non-duplicated {kind} instruction-tuning records about {topic}. "
            f"Category: {subcategory}. Difficulty: {difficulty}. Writing style: {style}. Tone: {tone}. "
            f"Use these source notes as the factual boundary: {notes or 'Use established, general educational knowledge and do not invent precise statistics.'} "
            f"Every example must have a useful, specific assistant answer. {schema}")
    payload=json.dumps({'model':model,'temperature':0.7,'messages':[{'role':'system','content':'You create carefully curated training data. Avoid placeholders, duplicates, and unsupported claims.'},{'role':'user','content':prompt}]}).encode()
    req=urllib.request.Request(base+'/chat/completions',data=payload,headers={'Authorization':'Bearer '+key,'Content-Type':'application/json'},method='POST')
    try:
        with urllib.request.urlopen(req,timeout=90) as response: data=json.loads(response.read().decode('utf-8'))
        raw=data['choices'][0]['message']['content']
        raw=re.sub(r'^```(?:json)?\s*|\s*```$','',raw.strip(),flags=re.I)
        rows=json.loads(raw)
        if not isinstance(rows,list): raise ValueError('Provider response was not a JSON array.')
        report=validate_records(rows)
        if not report['valid']: raise ValueError('Provider returned invalid training records: '+report['errors'][0]['message'])
        if len(rows)!=count: raise ValueError(f'Provider returned {len(rows)} records; {count} were requested.')
        seen=set(); unique=[]
        for row in rows:
            k=json.dumps(row,ensure_ascii=False,sort_keys=True)
            if k not in seen: seen.add(k); unique.append(row)
        if len(unique)!=count: raise ValueError('Provider returned duplicate records; retry with a more specific topic.')
        return rows
    except urllib.error.HTTPError as exc:
        raise ValueError(f'AI provider returned HTTP {exc.code}. Check provider URL, model, and credentials.') from exc
    except urllib.error.URLError as exc:
        raise ValueError(f'Could not reach the configured AI provider: {exc.reason}') from exc

def generate_preview(payload, settings):
    kind=payload.get('kind','knowledge')
    if kind not in ('behavior','knowledge'): raise ValueError('Choose Behaviour or Knowledge.')
    topic=str(payload.get('topic','')).strip()
    if not topic: raise ValueError('Enter a dataset topic.')
    count=int(payload.get('count',10))
    if not 1<=count<=500: raise ValueError('Record count must be between 1 and 500.')
    difficulty=str(payload.get('difficulty','Intermediate'))
    style=str(payload.get('writing_style','Balanced'))
    tone=str(payload.get('tone','Clear and neutral'))
    notes=str(payload.get('notes',''))[:12000]
    category=str(payload.get('category',''))
    subcategory=str(payload.get('subcategory','')) or category or topic
    if settings.get('provider',{}).get('enabled'):
        records=_provider_records(kind,topic,subcategory,count,difficulty,style,tone,notes,settings)
        source='Configured AI provider'
    else:
        records=_local_records(kind,topic,subcategory,count,difficulty,style,tone,notes)
        source='Local curated generator'
    report=validate_records(records)
    if not report['valid']: raise ValueError('Generated records failed validation.')
    return {'topic':topic,'kind':kind,'category':category or subcategory,'records':records,'record_count':len(records),'validation':report,'source':source}

def save_preview(preview, payload):
    return create_dataset(kind=preview['kind'],name=payload.get('name') or preview['topic'],category=payload.get('category') or preview['category'],subcategory=payload.get('subcategory') or preview['category'],description=payload.get('description') or f"Locally prepared {preview['kind']} dataset for {preview['topic']}.",tags=payload.get('tags') or [preview['kind'],_slug(preview['topic'])],records=preview['records'])
