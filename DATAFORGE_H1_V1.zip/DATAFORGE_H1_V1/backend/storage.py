from __future__ import annotations
import csv, io, json, os, re, shutil, tempfile, time, uuid
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from .config import ROOT, DATASETS, BEHAVIOR_DIR, KNOWLEDGE_DIR, BACKUP_DIR, atomic_json, ensure_dirs
from .validator import validate_records

MANIFEST = DATASETS / 'manifest.json'
PAGE_DEFAULT = 25

def _slug(text: str) -> str:
    slug = re.sub(r'[^a-zA-Z0-9]+','_',str(text or '').strip().lower()).strip('_')
    return slug[:64] or 'dataset'

def _read_manifest() -> list[dict]:
    ensure_dirs()
    try:
        obj=json.loads(MANIFEST.read_text(encoding='utf-8'))
        items=obj.get('datasets',[])
        return items if isinstance(items,list) else []
    except (OSError,json.JSONDecodeError):
        return []

def _write_manifest(items: list[dict]):
    atomic_json(MANIFEST, {'schema_version':1,'product':'DATAFORGE H1 V1','generated_at':datetime.now(timezone.utc).isoformat(),'datasets':items})
    _write_index(items)

def _write_index(items):
    stats={'version':'V1','behavior_datasets':sum(1 for x in items if x.get('kind')=='behavior'),'knowledge_datasets':sum(1 for x in items if x.get('kind')=='knowledge'),'total_datasets':len(items),'metadata_file':'manifest.json','schema':'Chat messages JSONL'}
    atomic_json(DATASETS/'index.json',stats)

def _path_for(meta: dict) -> Path:
    rel=Path(str(meta.get('file','')))
    path=(ROOT/rel).resolve()
    allowed=(BEHAVIOR_DIR.resolve(),KNOWLEDGE_DIR.resolve())
    if not any(base==path.parent for base in allowed) or path.suffix.lower()!='.jsonl':
        raise ValueError('Dataset path is outside the approved library folders.')
    return path

def iter_records(path: Path):
    """Yield one decoded JSONL record at a time."""
    with path.open('r',encoding='utf-8') as f:
        for line_number,line in enumerate(f,1):
            if not line.strip():
                continue
            try:
                yield json.loads(line)
            except json.JSONDecodeError as exc:
                raise ValueError(f'Invalid JSONL at line {line_number}: {exc.msg}') from exc


def _load_rows(path: Path, start=0, limit=None):
    rows=[]; total=0
    for row in iter_records(path):
        index=total; total+=1
        if index < start: continue
        if limit is not None and len(rows)>=limit: continue
        rows.append(row)
    return rows,total

def _count_lines(path: Path):
    total=0
    with path.open('r',encoding='utf-8') as f:
        for line in f:
            if line.strip(): total+=1
    return total

def _reconcile_meta(meta: dict, path: Path):
    try: actual=_count_lines(path)
    except (OSError,UnicodeError): actual=0
    out=dict(meta)
    out['number_of_records']=actual
    out['size_bytes']=path.stat().st_size if path.exists() else 0
    out['modified_at']=datetime.fromtimestamp(path.stat().st_mtime,timezone.utc).isoformat() if path.exists() else None
    return out

def list_all(*, kind=None, q='', category='', quality='', sort='name'):
    items=[]
    q=(q or '').strip().lower(); category=(category or '').strip().lower()
    for meta in _read_manifest():
        if kind and kind not in ('all',meta.get('kind')): continue
        if quality and quality.lower()!=meta.get('quality_status','').lower(): continue
        if category and category not in (meta.get('category','').lower(),meta.get('subcategory','').lower()): continue
        hay=' '.join([str(meta.get(k,'')) for k in ('name','description','category','subcategory','dataset_id','tags')]).lower()
        if q and q not in hay: continue
        try: items.append(_reconcile_meta(meta,_path_for(meta)))
        except (ValueError,OSError): continue
    if sort=='records': items.sort(key=lambda x:x.get('number_of_records',0),reverse=True)
    elif sort=='modified': items.sort(key=lambda x:x.get('modified_at') or '',reverse=True)
    else: items.sort(key=lambda x:x.get('name','').lower())
    return items

def get_dataset(dataset_id: str, *, page=1, page_size=50, query=''):
    meta=next((x for x in _read_manifest() if x.get('dataset_id')==dataset_id),None)
    if not meta: raise KeyError('Dataset was not found.')
    path=_path_for(meta)
    total=_count_lines(path)
    if query:
        matched_count=0; picked=[]; q=query.lower(); start=max(0,(page-1)*page_size)
        for row in iter_records(path):
            if q in json.dumps(row,ensure_ascii=False).lower():
                if start <= matched_count < start+page_size: picked.append(row)
                matched_count+=1
        return {'metadata':_reconcile_meta(meta,path),'records':picked,'total_records':matched_count,'page':page,'page_size':page_size,'total_pages':max(1,(matched_count+page_size-1)//page_size)}
    start=max(0,(page-1)*page_size)
    rows,_=_load_rows(path,start,page_size)
    return {'metadata':_reconcile_meta(meta,path),'records':rows,'total_records':total,'page':page,'page_size':page_size,'total_pages':max(1,(total+page_size-1)//page_size)}

def _backup(path: Path, dataset_id: str, label='versions'):
    if not path.exists(): return None
    dest_dir=BACKUP_DIR/label/_slug(dataset_id)
    dest_dir.mkdir(parents=True,exist_ok=True)
    stamp=datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    dest=dest_dir/f'{stamp}_{path.name}'
    shutil.copy2(path,dest)
    return str(dest.relative_to(ROOT)).replace('\\','/')

def _atomic_jsonl(path: Path, records):
    path.parent.mkdir(parents=True,exist_ok=True)
    fd,temp_name=tempfile.mkstemp(prefix=path.name+'.',suffix='.tmp',dir=str(path.parent))
    try:
        with os.fdopen(fd,'w',encoding='utf-8',newline='\n') as f:
            for row in records:
                f.write(json.dumps(row,ensure_ascii=False,separators=(',',':'))+'\n')
            f.flush(); os.fsync(f.fileno())
        os.replace(temp_name,path)
    except Exception:
        try: os.unlink(temp_name)
        except OSError: pass
        raise


def update_dataset_page(dataset_id: str, *, page: int, page_size: int, records: list[dict], description=None, tags=None, name=None):
    """Atomically replace one editor page without loading the complete dataset."""
    if page < 1 or page_size < 1 or page_size > 1000:
        raise ValueError('Editor page and page size are outside the supported range.')
    report=validate_records(records)
    if not report['valid']:
        raise ValueError('Dataset validation failed: '+report['errors'][0]['message'])
    items=_read_manifest(); meta=next((x for x in items if x.get('dataset_id')==dataset_id),None)
    if not meta: raise KeyError('Dataset was not found.')
    path=_path_for(meta)
    total=_count_lines(path); start=(page-1)*page_size
    if start > total:
        raise ValueError('Requested editor page is beyond the end of the dataset.')
    end=min(total,start+page_size)
    new_total=total-(end-start)+len(records)
    if new_total < 1:
        raise ValueError('A dataset must contain at least one training record.')
    backup=_backup(path,dataset_id) if path.exists() else None
    fd,temp_name=tempfile.mkstemp(prefix=path.name+'.',suffix='.tmp',dir=str(path.parent))
    try:
        with os.fdopen(fd,'w',encoding='utf-8',newline='\n') as out, path.open('r',encoding='utf-8') as src:
            inserted=False
            for idx,line in enumerate(src):
                if idx==start:
                    for row in records:
                        out.write(json.dumps(row,ensure_ascii=False,separators=(',',':'))+'\n')
                    inserted=True
                if not (start <= idx < end):
                    out.write(line if line.endswith('\n') else line+'\n')
            if not inserted:
                for row in records:
                    out.write(json.dumps(row,ensure_ascii=False,separators=(',',':'))+'\n')
            out.flush(); os.fsync(out.fileno())
        os.replace(temp_name,path)
    except Exception:
        try: os.unlink(temp_name)
        except OSError: pass
        raise
    major,minor,patch=(list(map(int,(str(meta.get('version','1.0.0')).split('.')+[0,0,0])[:3])))
    meta['version']=f'{major}.{minor}.{patch+1}'
    meta['number_of_records']=new_total
    meta['quality_status']='validated' if not report['warning_count'] else 'validated with warnings'
    if description is not None: meta['description']=str(description).strip()
    if tags is not None: meta['tags']=[str(t).strip().lower() for t in tags if str(t).strip()][:20]
    if name is not None and str(name).strip(): meta['name']=str(name).strip()
    meta['last_backup']=backup
    _write_manifest(items)
    return _reconcile_meta(meta,path)

def _meta_for_new(kind, name, category, subcategory, description, tags, path, records, version='1.0.0'):
    return {
      'dataset_id': f'{kind}-{path.stem}', 'name':name.strip(), 'category':category.strip() or ('Behaviour' if kind=='behavior' else 'General knowledge'),
      'subcategory':subcategory.strip() or name.strip(), 'description':description.strip() or f'Structured {kind} training examples for {name.strip()}.',
      'number_of_records':len(records),'format':'JSONL','creation_date':datetime.now(timezone.utc).date().isoformat(),'version':version,
      'tags':[str(t).strip().lower() for t in (tags or []) if str(t).strip()][:20], 'quality_status':'validated',
      'file':str(path.relative_to(ROOT)).replace('\\','/'),'kind':kind
    }

def create_dataset(*, kind, name, category='', subcategory='', description='', tags=None, records):
    if kind not in ('behavior','knowledge'): raise ValueError('Kind must be behavior or knowledge.')
    if not str(name or '').strip(): raise ValueError('Dataset name is required.')
    report=validate_records(records)
    if not report['valid']: raise ValueError('Dataset validation failed: '+report['errors'][0]['message'])
    folder=BEHAVIOR_DIR if kind=='behavior' else KNOWLEDGE_DIR
    stem=f"u_{datetime.now().strftime('%y%m%d_%H%M%S')}_{_slug(name)}_{uuid.uuid4().hex[:5]}"
    path=folder/(stem+'.jsonl')
    _atomic_jsonl(path,records)
    meta=_meta_for_new(kind,name,category,subcategory,description,tags,path,records)
    items=_read_manifest(); items.append(meta); _write_manifest(items)
    return _reconcile_meta(meta,path)

def update_dataset(dataset_id: str, records: list[dict], *, description=None, tags=None, name=None):
    report=validate_records(records)
    if not report['valid']: raise ValueError('Dataset validation failed: '+report['errors'][0]['message'])
    items=_read_manifest(); meta=next((x for x in items if x.get('dataset_id')==dataset_id),None)
    if not meta: raise KeyError('Dataset was not found.')
    path=_path_for(meta)
    backup=_backup(path,dataset_id) if path.exists() else None
    _atomic_jsonl(path,records)
    major,minor,patch=(list(map(int,(str(meta.get('version','1.0.0')).split('.')+[0,0,0])[:3])))
    meta['version']=f'{major}.{minor}.{patch+1}'
    meta['number_of_records']=len(records)
    meta['quality_status']='validated' if not report['warning_count'] else 'validated with warnings'
    if description is not None: meta['description']=str(description).strip()
    if tags is not None: meta['tags']=[str(t).strip().lower() for t in tags if str(t).strip()][:20]
    if name is not None and str(name).strip(): meta['name']=str(name).strip()
    meta['last_backup']=backup
    _write_manifest(items)
    return _reconcile_meta(meta,path)

def delete_dataset(dataset_id: str):
    items=_read_manifest(); meta=next((x for x in items if x.get('dataset_id')==dataset_id),None)
    if not meta: raise KeyError('Dataset was not found.')
    path=_path_for(meta)
    backup=_backup(path,dataset_id,label='deleted')
    path.unlink(missing_ok=True)
    _write_manifest([x for x in items if x.get('dataset_id')!=dataset_id])
    return {'deleted':dataset_id,'backup':backup}

def validate_dataset(dataset_id: str):
    meta=next((x for x in _read_manifest() if x.get('dataset_id')==dataset_id),None)
    if not meta: raise KeyError('Dataset was not found.')
    path=_path_for(meta)
    report=validate_records(iter_records(path))
    report['dataset_id']=dataset_id
    report['dataset_name']=meta['name']
    report['cross_dataset_duplicates']=0
    return report

def merge_datasets(dataset_ids: list[str], name='Merged dataset'):
    if len(set(dataset_ids))<2: raise ValueError('Select at least two different datasets to merge.')
    metas={x['dataset_id']:x for x in _read_manifest()}
    if any(x not in metas for x in dataset_ids): raise KeyError('One or more selected datasets do not exist.')
    kinds={metas[x]['kind'] for x in dataset_ids}
    if len(kinds)!=1: raise ValueError('Behaviour and knowledge datasets cannot be merged into one dataset.')
    kind=next(iter(kinds)); rows=[]; seen=set(); duplicates=0
    for did in dataset_ids:
        path=_path_for(metas[did]); records,_=_load_rows(path)
        for row in records:
            key=json.dumps(row,ensure_ascii=False,sort_keys=True)
            if key in seen: duplicates+=1; continue
            seen.add(key); rows.append(row)
    meta=create_dataset(kind=kind,name=name,category=metas[dataset_ids[0]]['category'],subcategory='Merged collection',description='Merged from '+', '.join(metas[x]['name'] for x in dataset_ids),tags=['merged',kind],records=rows)
    return {'dataset':meta,'merged_sources':len(dataset_ids),'records':len(rows),'duplicates_removed':duplicates}

def split_dataset(dataset_id: str, ratio=0.8):
    if not 0.1<=float(ratio)<=0.9: raise ValueError('Split ratio must be between 0.1 and 0.9.')
    data=get_dataset(dataset_id,page=1,page_size=1_000_000); meta=data['metadata']; rows=data['records']
    if len(rows)<2: raise ValueError('At least two records are required to split a dataset.')
    pivot=max(1,min(len(rows)-1,round(len(rows)*float(ratio))))
    common={'kind':meta['kind'],'category':meta['category'],'subcategory':meta['subcategory'],'tags':meta.get('tags',[])}
    first=create_dataset(name=meta['name']+' — Train split',description='First partition of '+meta['name'],records=rows[:pivot],**common)
    second=create_dataset(name=meta['name']+' — Validation split',description='Second partition of '+meta['name'],records=rows[pivot:],**common)
    return {'train':first,'validation':second,'train_records':pivot,'validation_records':len(rows)-pivot}

def stats():
    items=list_all(sort='name')
    by_kind=Counter(x['kind'] for x in items)
    records_by_kind=Counter(); category=Counter(); format_count=Counter(); quality=Counter(); bytes_total=0; recent=[]
    for meta in items:
        records_by_kind[meta['kind']]+=meta['number_of_records']
        category[meta['category']]+=1
        format_count[meta.get('format','JSONL')]+=1
        quality[meta.get('quality_status','unknown')]+=1
        bytes_total+=meta.get('size_bytes',0)
        recent.append(meta)
    recent.sort(key=lambda x:x.get('modified_at') or '',reverse=True)
    return {
        'total_datasets':len(items),'total_records':sum(records_by_kind.values()),
        'behavior_datasets':by_kind['behavior'],'knowledge_datasets':by_kind['knowledge'],
        'behavior_records':records_by_kind['behavior'],'knowledge_records':records_by_kind['knowledge'],
        'storage_bytes':bytes_total,'storage_human':_human_size(bytes_total),'formats':dict(format_count),
        'quality':dict(quality),'category_distribution':[{'category':k,'datasets':v} for k,v in category.most_common()],
        'recent_datasets':recent[:8]
    }

def _human_size(n):
    value=float(n)
    for unit in ('B','KB','MB','GB','TB'):
        if value<1024 or unit=='TB': return f'{value:.1f} {unit}'
        value/=1024

def categories():
    counts=Counter()
    subs=defaultdict(Counter)
    for m in _read_manifest():
        counts[m.get('category','Other')]+=1
        subs[m.get('category','Other')][m.get('subcategory','Other')]+=1
    return [{'name':cat,'datasets':count,'subcategories':[{'name':s,'datasets':n} for s,n in sub.most_common()]} for cat,count in counts.most_common() for sub in [subs[cat]]]

def rebuild_manifest():
    """Rebuild metadata from files; preserves descriptions and user-entered metadata."""
    existing={x.get('file'):x for x in _read_manifest()}; items=[]
    for kind,folder in [('behavior',BEHAVIOR_DIR),('knowledge',KNOWLEDGE_DIR)]:
        for path in sorted(folder.glob('*.jsonl')):
            rel=str(path.relative_to(ROOT)).replace('\\','/')
            meta=existing.get(rel)
            if not meta:
                meta={'dataset_id':f'{kind}-{path.stem}','name':path.stem.replace('_',' ').title(),'category':'Behaviour' if kind=='behavior' else 'General knowledge','subcategory':path.stem,'description':'Imported JSONL training dataset.','creation_date':datetime.now(timezone.utc).date().isoformat(),'version':'1.0.0','format':'JSONL','tags':[kind],'quality_status':'review recommended','file':rel,'kind':kind}
            rows,_=_load_rows(path)
            meta['number_of_records']=len(rows)
            meta['size_bytes']=path.stat().st_size
            meta.setdefault('format','JSONL')
            items.append(meta)
    _write_manifest(items)
    return len(items)

# Ensure manifest exists and stays aligned with the on-disk library.
ensure_dirs()
if not MANIFEST.exists(): rebuild_manifest()
