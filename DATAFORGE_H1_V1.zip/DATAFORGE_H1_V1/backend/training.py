from __future__ import annotations
import importlib.util, json, threading, traceback, time
from pathlib import Path
from .config import ROOT, TRAINING_RUNS, CONFIG_DIR, atomic_json, ensure_dirs
from .storage import get_dataset, list_all
from .validator import validate_records

DEFAULT_TRAINING = {'model_ref':'','method':'lora','output_name':'dataforge_run','epochs':1,'steps':100,'batch':1,'gradient_accumulation':4,'sequence_length':1024,'rank':4,'alpha':8,'learning_rate':0.0002,'validation_split':0.1,'seed':42,'dataset_ids':[]}
TRAINING_CONFIG_FILE=CONFIG_DIR/'training_config.json'

def get_config():
    ensure_dirs()
    try:
        saved=json.loads(TRAINING_CONFIG_FILE.read_text(encoding='utf-8'))
        return {**DEFAULT_TRAINING,**(saved if isinstance(saved,dict) else {})}
    except (OSError,json.JSONDecodeError):
        return dict(DEFAULT_TRAINING)

def save_config(cfg):
    values={**DEFAULT_TRAINING,**(cfg or {})}
    # Persist only documented configuration keys.
    values={k:values[k] for k in DEFAULT_TRAINING}
    atomic_json(TRAINING_CONFIG_FILE,values)
    return values
_STATE={'status':'idle','logs':[],'error':None,'output':None,'started_at':None,'finished_at':None,'progress':0,'stage':'Not started'}
_LOCK=threading.Lock(); _THREAD=None

def dependencies():
    modules=('torch','transformers','peft','accelerate','datasets','safetensors','bitsandbytes')
    out={}
    for name in modules:
        try: out[name]=bool(importlib.util.find_spec(name))
        except (ImportError,ValueError): out[name]=False
    return out

def hardware_profile():
    try:
        from training_engine import hardware
        return hardware()
    except Exception as exc:
        return {'cpu':1,'ram':0,'cuda':False,'gpu_present':False,'gpu':'Unknown','vram':0,'epochs':1,'steps':100,'batch':1,'grad':4,'length':1024,'rank':4,'probe_error':str(exc)}

def validate_config(cfg):
    values=dict(DEFAULT_TRAINING); values.update(cfg or {})
    errors=[]; warnings=[]
    if not values['model_ref'].strip(): errors.append('Set a Hugging Face model ID or local checkpoint path.')
    if values['method'] not in ('lora','qlora','full'): errors.append('Training method must be LoRA, QLoRA, or Full fine-tuning.')
    if not values['dataset_ids']: errors.append('Select at least one dataset.')
    try:
        split=float(values['validation_split'])
        values['validation_split']=split
    except (ValueError,TypeError): split=-1
    if not 0<=split<0.5: errors.append('Validation split must be from 0 up to, but not including, 0.5.')
    hw=hardware_profile(); deps=dependencies()
    caps={'epochs':hw.get('epochs',1),'steps':hw.get('steps',100),'batch':hw.get('batch',1),'gradient_accumulation':hw.get('grad',4),'sequence_length':hw.get('length',1024),'rank':hw.get('rank',4)}
    for field,cap in caps.items():
        try: n=int(values[field])
        except (ValueError,TypeError): errors.append(f'{field} must be an integer.'); continue
        if n<1 or n>cap: errors.append(f'{field} must be between 1 and the hardware cap of {cap}.')
    try:
        lr=float(values['learning_rate'])
        if not 1e-7<=lr<=3e-4: errors.append('Learning rate must be between 1e-7 and 0.0003.')
    except (ValueError,TypeError): errors.append('Learning rate must be numeric.')
    kind_names=[]; total_records=0; files=[]
    indexed={x['dataset_id']:x for x in list_all()}
    for did in values['dataset_ids']:
        try:
            meta=indexed[did]
            kind_names.append(meta['kind']); total_records+=int(meta['number_of_records']); files.append(str(ROOT/meta['file']))
        except Exception: errors.append(f'Selected dataset not found: {did}')
    if len(set(kind_names))>1: warnings.append('Behaviour and knowledge data are mixed; confirm that this is intentional.')
    if total_records<2: errors.append('At least two valid records are required for a train/validation workflow.')
    valid_count=int(total_records*(1-split)) if split>0 else total_records
    eval_count=total_records-valid_count
    if values['method']=='qlora' and not hw.get('cuda'): errors.append('QLoRA requires a verified CUDA-enabled PyTorch environment.')
    needed=['torch','transformers','peft','accelerate','datasets','safetensors'] if values['method'] in ('lora','qlora') else ['torch','transformers','accelerate','datasets','safetensors']
    missing=[m for m in needed if not deps.get(m)]
    if values['method']=='qlora' and not deps.get('bitsandbytes'): missing.append('bitsandbytes')
    if missing: warnings.append('Training dependencies are missing: '+', '.join(missing)+'. Dataset preparation and configuration can still be completed.')
    if values['validation_split'] and eval_count<1: errors.append('The selected validation split produces no evaluation records.')
    return {'valid':not errors,'errors':errors,'warnings':warnings,'config':values,'hardware':hw,'dependencies':deps,'selected_files':files,'records':total_records,'training_records':valid_count,'validation_records':eval_count,'actual_training_available':not missing and not errors}

def _append_log(line):
    with _LOCK:
        _STATE['logs'].append(str(line)[-2000:])
        _STATE['logs']=_STATE['logs'][-300:]

def status():
    with _LOCK: return dict(_STATE)

def _run_worker(cfg, preflight):
    global _STATE
    with _LOCK:
        _STATE.update({'status':'running','error':None,'output':None,'started_at':time.time(),'finished_at':None,'progress':1,'stage':'Loading training engine','logs':[]})
    try:
        from training_engine import train
        hw=preflight['hardware']
        settings={'epochs':int(cfg['epochs']),'steps':int(cfg['steps']),'batch':int(cfg['batch']),'grad':int(cfg['gradient_accumulation']),'length':int(cfg['sequence_length']),'rank':int(cfg['rank']),'alpha':int(cfg.get('alpha',int(cfg['rank'])*2)),'lr':float(cfg['learning_rate']),'validation_split':float(cfg['validation_split']),'seed':int(cfg.get('seed',42))}
        _append_log('Starting model and tokenizer compatibility checks through Transformers.')
        def progress(update):
            with _LOCK:
                _STATE['stage']=str(update.get('stage',_STATE['stage']))
                _STATE['progress']=int(update.get('progress',_STATE['progress']))
                if update.get('step') is not None: _STATE['step']=int(update['step'])
                if update.get('total_steps') is not None: _STATE['total_steps']=int(update['total_steps'])
                if update.get('metrics'): _STATE['logs'].append('Metrics: '+json.dumps(update['metrics'],default=str)[:1500])
        out=train(cfg['model_ref'],preflight['selected_files'],cfg['method'],cfg['output_name'],settings,hw,progress_callback=progress)
        with _LOCK: _STATE.update({'status':'complete','progress':100,'stage':'Model artifact saved','output':str(out/'final'),'finished_at':time.time()})
        _append_log('Training completed. Final model and tokenizer artifacts were saved.')
    except Exception as exc:
        with _LOCK: _STATE.update({'status':'failed','error':str(exc),'stage':'Training failed','finished_at':time.time()})
        _append_log('ERROR: '+str(exc))

def start_training(cfg):
    global _THREAD
    report=validate_config(cfg)
    if not report['valid']: raise ValueError('Training preflight failed: '+'; '.join(report['errors']))
    if not report['actual_training_available']: raise ValueError('Dataset preparation and configuration are available, but actual training cannot start until dependencies are installed: '+'; '.join(report['warnings']))
    with _LOCK:
        if _STATE['status']=='running': raise ValueError('A training job is already running.')
    _THREAD=threading.Thread(target=_run_worker,args=(report['config'],report),daemon=True)
    _THREAD.start()
    return {'started':True,'status':'running','preflight':report}
