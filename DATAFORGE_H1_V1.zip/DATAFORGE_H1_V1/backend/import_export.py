from __future__ import annotations
import csv, io, json, zipfile, base64
from pathlib import Path
from .storage import get_dataset, list_all
from .validator import validate_records

MAX_IMPORT_BYTES = 40 * 1024 * 1024

def parse_import(content: str, fmt: str):
    if len(content.encode('utf-8')) > MAX_IMPORT_BYTES: raise ValueError('Import exceeds the 40 MB limit.')
    fmt=(fmt or '').lower().strip()
    rows=[]
    if fmt in ('jsonl','ndjson'):
        for i,line in enumerate(content.splitlines(),1):
            if not line.strip(): continue
            try: rows.append(json.loads(line))
            except json.JSONDecodeError as exc: raise ValueError(f'Invalid JSON on line {i}: {exc.msg}') from exc
    elif fmt=='json':
        obj=json.loads(content)
        if isinstance(obj,dict) and 'records' in obj: obj=obj['records']
        if isinstance(obj,dict): obj=[obj]
        if not isinstance(obj,list): raise ValueError('JSON import must be an array of records or an object with a records array.')
        rows=obj
    elif fmt=='csv':
        reader=csv.DictReader(io.StringIO(content))
        if not reader.fieldnames: raise ValueError('CSV must include a header row.')
        for i,row in enumerate(reader,2):
            user=row.get('prompt') or row.get('user') or row.get('instruction') or row.get('input')
            assistant=row.get('response') or row.get('assistant') or row.get('output') or row.get('completion')
            if user is None or assistant is None: raise ValueError('CSV requires prompt/response or user/assistant columns.')
            rows.append({'messages':[{'role':'user','content':str(user)},{'role':'assistant','content':str(assistant)}]})
    else: raise ValueError('Supported import formats are JSONL, JSON, and CSV.')
    if not rows: raise ValueError('No records were found in the import.')
    report=validate_records(rows)
    if not report['valid']:
        first=report['errors'][0]
        raise ValueError(f"Record {first['record']}: {first['message']}")
    return rows

def export_dataset(dataset_id: str, fmt='jsonl'):
    data=get_dataset(dataset_id,page=1,page_size=1_000_000)
    meta,rows=data['metadata'],data['records']
    fmt=fmt.lower()
    if fmt=='jsonl':
        payload=''.join(json.dumps(r,ensure_ascii=False,separators=(',',':'))+'\n' for r in rows)
        mime='application/x-ndjson'; ext='jsonl'
    elif fmt=='json':
        payload=json.dumps({'metadata':meta,'records':rows},ensure_ascii=False,indent=2)+'\n'
        mime='application/json'; ext='json'
    elif fmt=='csv':
        buf=io.StringIO(newline='')
        writer=csv.writer(buf); writer.writerow(['prompt','response'])
        for r in rows:
            messages=r.get('messages',[])
            prompt='\n'.join(m.get('content','') for m in messages if m.get('role')=='user')
            response='\n'.join(m.get('content','') for m in messages if m.get('role')=='assistant')
            writer.writerow([prompt,response])
        payload=buf.getvalue(); mime='text/csv'; ext='csv'
    else: raise ValueError('Supported export formats are JSONL, JSON, and CSV.')
    return {'filename':meta['dataset_id']+'.'+ext,'mime':mime,'content_base64':base64.b64encode(payload.encode('utf-8')).decode('ascii'),'records':len(rows)}

def export_all_zip(kind='all'):
    files=list_all(kind=kind if kind in ('behavior','knowledge') else None)
    out=io.BytesIO()
    with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
        for meta in files:
            path=Path(meta['file'])
            from .config import ROOT
            z.write(ROOT/path, f"{meta['kind']}/{path.name}")
        z.writestr('manifest.json',json.dumps({'datasets':files},ensure_ascii=False,indent=2))
    return {'filename':f'dataforge_{kind}_library.zip','mime':'application/zip','content_base64':base64.b64encode(out.getvalue()).decode('ascii'),'datasets':len(files)}
