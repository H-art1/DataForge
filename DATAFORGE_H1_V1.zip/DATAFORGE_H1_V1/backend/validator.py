from __future__ import annotations
import json
from collections import Counter
from typing import Iterable

ALLOWED_ROLES = {'system','developer','user','assistant','tool'}

def validate_records(records: Iterable[dict], *, check_unique=True):
    errors, warnings = [], []
    seen = set()
    count = 0
    duplicates = 0
    for idx, record in enumerate(records, 1):
        count += 1
        if not isinstance(record, dict):
            errors.append({'record':idx,'message':'Record must be a JSON object.'})
            continue
        messages = record.get('messages')
        if not isinstance(messages, list) or len(messages) < 2:
            errors.append({'record':idx,'message':'Expected a messages array with at least two messages.'})
            continue
        roles = []
        valid = True
        for mi, msg in enumerate(messages, 1):
            if not isinstance(msg, dict):
                errors.append({'record':idx,'message':f'Message {mi} must be an object.'}); valid=False; continue
            role, content = msg.get('role'), msg.get('content')
            if role not in ALLOWED_ROLES:
                errors.append({'record':idx,'message':f'Message {mi} has unsupported role: {role!r}.'}); valid=False
            if not isinstance(content, str) or not content.strip():
                errors.append({'record':idx,'message':f'Message {mi} content must be a non-empty string.'}); valid=False
            roles.append(role)
        if 'user' not in roles or 'assistant' not in roles:
            errors.append({'record':idx,'message':'Each training example must contain at least one user and one assistant message.'}); valid=False
        if valid and check_unique:
            fingerprint = json.dumps(record, ensure_ascii=False, sort_keys=True, separators=(',',':'))
            if fingerprint in seen:
                duplicates += 1
                warnings.append({'record':idx,'message':'Exact duplicate record found in this dataset.'})
            else:
                seen.add(fingerprint)
        if valid:
            assistant_text = ' '.join(m.get('content','') for m in messages if m.get('role')=='assistant')
            if len(assistant_text.strip()) < 35:
                warnings.append({'record':idx,'message':'Assistant answer is very short; review whether it contains enough information.'})
    return {
        'valid': len(errors)==0,
        'records': count,
        'valid_records': count-len({e['record'] for e in errors}),
        'error_count': len(errors),
        'warning_count': len(warnings),
        'duplicate_count': duplicates,
        'errors': errors[:200],
        'warnings': warnings[:200],
        'status': 'passed' if not errors and not warnings else ('passed with warnings' if not errors else 'failed')
    }
