from __future__ import annotations
from .config import load_settings, save_settings

def get_settings():
    settings=load_settings()
    # Never expose provider secrets through the settings endpoint.
    provider=settings.get('provider',{})
    import os
    provider['key_available']=bool(os.environ.get(provider.get('api_key_env','OPENAI_API_KEY')))
    return settings

def update_settings(payload):
    allowed={'theme','identity','provider','preferences'}
    clean={k:v for k,v in payload.items() if k in allowed}
    if 'theme' in clean and clean['theme'] not in ('dark','light'):
        raise ValueError('Theme must be dark or light.')
    if 'identity' in clean:
        identity=clean['identity']
        if not isinstance(identity,dict): raise ValueError('Identity settings must be an object.')
        if 'name' in identity:
            identity['name']=str(identity['name']).strip()[:60]
            if not identity['name']: raise ValueError('AI name cannot be empty.')
        if 'description' in identity: identity['description']=str(identity['description']).strip()[:500]
    if 'provider' in clean:
        p=clean['provider']
        if not isinstance(p,dict): raise ValueError('Provider settings must be an object.')
        p['base_url']=str(p.get('base_url','')).strip()[:300]
        p['model']=str(p.get('model','')).strip()[:120]
        p['api_key_env']=str(p.get('api_key_env','OPENAI_API_KEY')).strip()[:80] or 'OPENAI_API_KEY'
    return save_settings(clean)
