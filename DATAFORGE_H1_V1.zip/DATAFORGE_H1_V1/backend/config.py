from pathlib import Path
import json, os, tempfile

ROOT = Path(__file__).resolve().parents[1]
DATASETS = ROOT / 'datasets'
BEHAVIOR_DIR = DATASETS / 'behavior'
KNOWLEDGE_DIR = DATASETS / 'knowledge'
FRONTEND = ROOT / 'frontend'
CONFIG_DIR = ROOT / 'config'
SETTINGS_FILE = CONFIG_DIR / 'app_settings.json'
BACKUP_DIR = ROOT / 'backups'
TRAINING_RUNS = ROOT / 'training_runs'

DEFAULT_SETTINGS = {
    'theme': 'dark',
    'identity': {
        'name': 'My AI',
        'description': 'A helpful, thoughtful AI assistant configured with your selected datasets.',
        'personality_preset': 'Helpful professional',
        'communication_style': 'Balanced',
        'response_tone': 'Calm and clear',
        'default_behavior_profile': 'Helpful assistant',
        'selected_datasets': []
    },
    'provider': {
        'enabled': False,
        'base_url': 'https://api.openai.com/v1',
        'model': '',
        'api_key_env': 'OPENAI_API_KEY'
    },
    'preferences': {
        'page_size': 25,
        'confirm_destructive_actions': True,
        'auto_backup': True
    }
}

def ensure_dirs():
    for p in (DATASETS, BEHAVIOR_DIR, KNOWLEDGE_DIR, CONFIG_DIR, BACKUP_DIR, TRAINING_RUNS):
        p.mkdir(parents=True, exist_ok=True)

def atomic_json(path: Path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=path.name+'.', suffix='.tmp', dir=str(path.parent))
    try:
        with os.fdopen(fd, 'w', encoding='utf-8', newline='\n') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
            f.write('\n')
            f.flush()
            os.fsync(f.fileno())
        os.replace(temp_name, path)
    except Exception:
        try: os.unlink(temp_name)
        except OSError: pass
        raise

def load_settings():
    ensure_dirs()
    if not SETTINGS_FILE.exists():
        atomic_json(SETTINGS_FILE, DEFAULT_SETTINGS)
    try:
        data = json.loads(SETTINGS_FILE.read_text(encoding='utf-8'))
    except (OSError, json.JSONDecodeError):
        data = {}
    # Merge defaults so new settings are introduced without discarding user values.
    merged = json.loads(json.dumps(DEFAULT_SETTINGS))
    if isinstance(data, dict):
        for key, value in data.items():
            if isinstance(value, dict) and isinstance(merged.get(key), dict):
                merged[key].update(value)
            else:
                merged[key] = value
    return merged

def save_settings(settings):
    current = load_settings()
    if not isinstance(settings, dict):
        raise ValueError('Settings must be an object.')
    for key, value in settings.items():
        if isinstance(value, dict) and isinstance(current.get(key), dict):
            current[key].update(value)
        else:
            current[key] = value
    atomic_json(SETTINGS_FILE, current)
    return current
