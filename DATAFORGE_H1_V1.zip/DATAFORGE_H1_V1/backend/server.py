from __future__ import annotations
import argparse, base64, json, mimetypes, os, sys, traceback, webbrowser
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs, unquote
from .config import ROOT, FRONTEND, ensure_dirs
from .storage import (list_all, iter_records, get_dataset, stats, categories, create_dataset, update_dataset,
                      delete_dataset, validate_dataset, merge_datasets, split_dataset, update_dataset_page)
from .import_export import parse_import, export_dataset, export_all_zip
from .settings import get_settings, update_settings
from .generator import generate_preview, save_preview
from .training import DEFAULT_TRAINING, get_config as get_training_config, save_config as save_training_config, validate_config as validate_training, start_training, status as training_status, hardware_profile, dependencies
from .validator import validate_records

class DataForgeHandler(SimpleHTTPRequestHandler):
    server_version = 'DATAFORGE-H1-V1'

    def __init__(self,*args,**kwargs):
        super().__init__(*args,directory=str(FRONTEND),**kwargs)

    def log_message(self, fmt, *args):
        if os.environ.get('DATAFORGE_ACCESS_LOG')=='1': super().log_message(fmt,*args)

    def _json(self, data, status=200):
        payload=json.dumps(data,ensure_ascii=False).encode('utf-8')
        self.send_response(status); self.send_header('Content-Type','application/json; charset=utf-8')
        self.send_header('Content-Length',str(len(payload))); self.send_header('Cache-Control','no-store')
        self.send_header('X-Content-Type-Options','nosniff'); self.end_headers(); self.wfile.write(payload)

    def _body(self):
        try: length=int(self.headers.get('Content-Length','0'))
        except ValueError: raise ValueError('Invalid content length.')
        if length>50*1024*1024: raise ValueError('Request exceeds the 50 MB limit.')
        raw=self.rfile.read(length)
        if not raw: return {}
        try: return json.loads(raw.decode('utf-8'))
        except (UnicodeDecodeError,json.JSONDecodeError) as exc: raise ValueError('Request body must be valid UTF-8 JSON.') from exc

    def _route_error(self, exc):
        if isinstance(exc,KeyError): self._json({'error':str(exc).strip("'")},404)
        elif isinstance(exc,(ValueError,TypeError)): self._json({'error':str(exc)},400)
        else:
            traceback.print_exc()
            self._json({'error':'The operation failed unexpectedly. Check the DATAFORGE console for details.'},500)

    def do_GET(self):
        parsed=urlparse(self.path); path=unquote(parsed.path); query=parse_qs(parsed.query)
        try:
            if path=='/' or path=='/index.html': return self._static('index.html')
            if path=='/api/health': return self._json({'ok':True,'product':'DATAFORGE H1 V1','version':'1.0.0'})
            if path in ('/api/overview','/api/analytics'): return self._json(stats())
            if path=='/api/categories': return self._json({'categories':categories()})
            if path=='/api/settings': return self._json(get_settings())
            if path=='/api/identity': return self._json(get_settings().get('identity',{}))
            if path=='/api/training/config':
                return self._json({'config':get_training_config(),'hardware':hardware_profile(),'dependencies':dependencies()})
            if path=='/api/training/status': return self._json(training_status())
            if path=='/api/system':
                import platform
                return self._json({'python':sys.version.split()[0],'platform':platform.platform(),'root':str(ROOT),'theme':get_settings().get('theme','dark')})
            if path=='/api/datasets':
                kind=query.get('kind',['all'])[0]; q=query.get('q',[''])[0]; category=query.get('category',[''])[0]
                quality=query.get('quality',[''])[0]; sort=query.get('sort',['name'])[0]
                page=max(1,int(query.get('page',['1'])[0])); size=max(1,min(1500,int(query.get('page_size',['25'])[0])))
                items=list_all(kind=kind,q=q,category=category,quality=quality,sort=sort)
                start=(page-1)*size
                return self._json({'datasets':items[start:start+size],'total':len(items),'page':page,'page_size':size,'total_pages':max(1,(len(items)+size-1)//size)})
            if path.startswith('/api/datasets/'):
                dataset_id=path.split('/',3)[3]
                page=max(1,int(query.get('page',['1'])[0])); size=min(1000000,max(1,int(query.get('page_size',['50'])[0])))
                q=query.get('q',[''])[0]
                return self._json(get_dataset(dataset_id,page=page,page_size=size,query=q))
            if path=='/api/templates':
                templates=sorted((ROOT/'templates').glob('*.jsonl'))
                return self._json({'templates':[{'name':p.stem.replace('_',' ').title(),'file':p.name,'records':sum(1 for l in p.read_text(encoding='utf-8').splitlines() if l.strip())} for p in templates]})
            if path=='/api/versions':
                did=query.get('dataset_id',[''])[0]
                from .config import BACKUP_DIR
                folder=BACKUP_DIR/'versions'/did
                versions=[]
                if folder.exists():
                    for p in sorted(folder.glob('*.jsonl'),reverse=True): versions.append({'name':p.name,'path':str(p.relative_to(ROOT)).replace('\\','/'),'size_bytes':p.stat().st_size})
                return self._json({'versions':versions})
            if path=='/api/training/logs': return self._json(training_status())
            # Static files are served only from the frontend directory.
            if path.startswith('/assets/'):
                return self._static(path[len('/assets/'):])
            return self._json({'error':'Route not found.'},404)
        except Exception as exc: return self._route_error(exc)

    def _static(self, rel):
        candidate=(FRONTEND/rel).resolve()
        if FRONTEND.resolve() not in candidate.parents and candidate!=FRONTEND.resolve():
            return self._json({'error':'Invalid path.'},403)
        if not candidate.is_file(): return self._json({'error':'Static asset not found.'},404)
        content=candidate.read_bytes(); mime=mimetypes.guess_type(str(candidate))[0] or 'application/octet-stream'
        if mime.startswith('text/') or mime in ('application/javascript','application/json'): mime+='; charset=utf-8'
        self.send_response(200); self.send_header('Content-Type',mime); self.send_header('Content-Length',str(len(content)))
        self.send_header('X-Content-Type-Options','nosniff'); self.end_headers(); self.wfile.write(content)

    def do_POST(self):
        path=urlparse(self.path).path
        try:
            body=self._body()
            if path=='/api/settings': return self._json(update_settings(body))
            if path=='/api/identity': return self._json(update_settings({'identity':body}).get('identity',{}))
            if path=='/api/datasets':
                meta=create_dataset(kind=body.get('kind','knowledge'),name=body.get('name',''),category=body.get('category',''),subcategory=body.get('subcategory',''),description=body.get('description',''),tags=body.get('tags',[]),records=body.get('records',[]))
                return self._json({'dataset':meta},201)
            if path.startswith('/api/datasets/'):
                rest=path[len('/api/datasets/'):]
                if rest.endswith('/save'):
                    did=rest[:-5].rstrip('/')
                    if 'page' in body and 'page_size' in body:
                        meta=update_dataset_page(did,page=int(body['page']),page_size=int(body['page_size']),records=body.get('records',[]),description=body.get('description'),tags=body.get('tags'),name=body.get('name'))
                    else:
                        meta=update_dataset(did,body.get('records',[]),description=body.get('description'),tags=body.get('tags'),name=body.get('name'))
                    return self._json({'dataset':meta})
                if rest.endswith('/validate'):
                    return self._json(validate_dataset(rest[:-9].rstrip('/')))
                if rest.endswith('/delete'):
                    return self._json(delete_dataset(rest[:-7].rstrip('/')))
                if rest.endswith('/split'):
                    return self._json(split_dataset(rest[:-6].rstrip('/'),body.get('ratio',0.8)),201)
            if path=='/api/datasets/merge': return self._json(merge_datasets(body.get('dataset_ids',[]),body.get('name','Merged dataset')),201)
            if path=='/api/import':
                records=parse_import(body.get('content',''),body.get('format','jsonl'))
                meta=create_dataset(kind=body.get('kind','knowledge'),name=body.get('name') or body.get('filename','Imported dataset').rsplit('.',1)[0],category=body.get('category','Imported'),subcategory=body.get('subcategory','Import'),description=body.get('description','Imported and validated training data.'),tags=['imported',body.get('format','jsonl')],records=records)
                return self._json({'dataset':meta,'imported_records':len(records)},201)
            if path=='/api/export': return self._json(export_dataset(body.get('dataset_id',''),body.get('format','jsonl')))
            if path=='/api/export/all': return self._json(export_all_zip(body.get('kind','all')))
            if path=='/api/generator/preview': return self._json(generate_preview(body,get_settings()))
            if path=='/api/generator/save':
                preview=body.get('preview')
                if not isinstance(preview,dict) or not isinstance(preview.get('records'),list): raise ValueError('Generate and preview a dataset before saving it.')
                return self._json({'dataset':save_preview(preview,body)},201)
            if path=='/api/training/config': return self._json({'config':save_training_config(body)})
            if path=='/api/training/preflight': return self._json(validate_training(body))
            if path=='/api/training/start': return self._json(start_training(body),202)
            if path=='/api/validate-all':
                from .storage import list_all
                import json as _json
                items=list_all(); all_seen=set(); duplicate_global=0; reports=[]; errors=0; warnings=0; records=0
                for m in items:
                    row_iter=iter_records(ROOT/m['file'])
                    report=validate_records(row_iter)
                    records+=report['records']; errors+=report['error_count']; warnings+=report['warning_count']
                    local_dupes=0
                    # Re-read a file for the cross-library fingerprint pass, keeping only hashes in memory.
                    for row in iter_records(ROOT/m['file']):
                        fp=_json.dumps(row,ensure_ascii=False,sort_keys=True,separators=(',',':'))
                        if fp in all_seen: local_dupes+=1; duplicate_global+=1
                        else: all_seen.add(fp)
                    if report['error_count'] or report['warning_count'] or local_dupes:
                        reports.append({'dataset_id':m['dataset_id'],'name':m['name'],'errors':report['error_count'],'warnings':report['warning_count'],'cross_dataset_duplicates':local_dupes})
                return self._json({'datasets_checked':len(items),'records_checked':records,'error_count':errors,'warning_count':warnings,'cross_dataset_duplicates':duplicate_global,'unique_records':len(all_seen),'status':'passed' if not errors and not warnings and not duplicate_global else 'review required','issues':reports[:300]})
            if path=='/api/backup':
                return self._json(export_all_zip(body.get('kind','all')))
            return self._json({'error':'Route not found.'},404)
        except Exception as exc: return self._route_error(exc)

class DataForgeServer(ThreadingHTTPServer):
    daemon_threads=True
    allow_reuse_address=True

def start_server(host='127.0.0.1',port=8765,open_browser=True):
    # The application has no authentication layer; never expose the workspace to a network.
    if host not in ('127.0.0.1', 'localhost', '::1'):
        raise ValueError('DATAFORGE only supports loopback binding (127.0.0.1, localhost, or ::1).')
    ensure_dirs()
    last_error=None; httpd=None
    for candidate in range(port,port+25):
        try:
            httpd=DataForgeServer((host,candidate),DataForgeHandler); port=candidate; break
        except OSError as exc: last_error=exc
    if httpd is None: raise RuntimeError(f'Could not bind a local DATAFORGE port: {last_error}')
    url=f'http://{host}:{port}/'
    print(f'\nDATAFORGE H1 V1 is running at {url}')
    print('Local-only server. Keep this terminal open while using DATAFORGE.')
    if open_browser:
        try: webbrowser.open(url)
        except Exception: pass
    try: httpd.serve_forever(poll_interval=0.35)
    except KeyboardInterrupt: print('\nStopping DATAFORGE H1 V1...')
    finally: httpd.server_close()

if __name__=='__main__':
    parser=argparse.ArgumentParser(description='DATAFORGE H1 V1 local application server')
    parser.add_argument('--host',default='127.0.0.1')
    parser.add_argument('--port',type=int,default=int(os.environ.get('DATAFORGE_PORT','8765')))
    parser.add_argument('--no-browser',action='store_true')
    args=parser.parse_args()
    start_server(args.host,args.port,not args.no_browser)
