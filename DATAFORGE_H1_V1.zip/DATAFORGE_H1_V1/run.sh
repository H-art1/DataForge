#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
PYTHON_BIN="${PYTHON:-python3}"
if ! command -v "$PYTHON_BIN" >/dev/null 2>&1; then
  echo "Python 3.10 or later is required." >&2
  exit 1
fi
"$PYTHON_BIN" - <<'PYVER'
import sys
if sys.version_info < (3, 10):
    raise SystemExit("DATAFORGE H1 V1 requires Python 3.10 or later.")
PYVER
exec "$PYTHON_BIN" datasetmaker.py "$@"
