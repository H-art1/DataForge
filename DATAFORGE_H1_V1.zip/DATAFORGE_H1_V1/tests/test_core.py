from __future__ import annotations
import base64, json, tempfile, threading, urllib.request, urllib.error, unittest
from pathlib import Path

from backend import config
from backend import storage, import_export, settings, training
from backend.generator import generate_preview
from backend.server import DataForgeHandler, DataForgeServer, start_server


def record(i: int):
    return {'messages':[
        {'role':'user','content':f'Please explain test case {i} and the important conditions that apply.'},
        {'role':'assistant','content':f'Test case {i} should be handled by checking its assumptions, explaining the steps, and validating the final result against the stated conditions.'}
    ]}


class LibraryIntegrityTests(unittest.TestCase):
    def test_library_inventory_and_metadata(self):
        all_sets=storage.list_all()
        stats=storage.stats()
        self.assertEqual(len(all_sets),1300)
        self.assertEqual(stats['behavior_datasets'],600)
        self.assertEqual(stats['knowledge_datasets'],700)
        self.assertEqual(stats['behavior_records'],3000)
        self.assertEqual(stats['knowledge_records'],3500)
        behavior_names={m['name'] for m in all_sets if m['kind']=='behavior'}
        self.assertEqual(len(behavior_names),600)
        required={'dataset_id','name','category','subcategory','description','number_of_records','format','creation_date','version','tags','quality_status'}
        self.assertEqual(len({m['name'] for m in all_sets}),1300)
        for meta in all_sets:
            self.assertTrue(required.issubset(meta))
            self.assertEqual(meta['format'],'JSONL')
            self.assertGreater(meta['number_of_records'],0)

    def test_all_records_have_one_schema_and_no_exact_duplicates(self):
        seen=set(); prompts=set(); total=0
        for meta in storage.list_all():
            path=config.ROOT/meta['file']
            with path.open(encoding='utf-8') as stream:
                for line in stream:
                    if not line.strip(): continue
                    row=json.loads(line)
                    self.assertIsInstance(row,dict)
                    messages=row.get('messages')
                    self.assertIsInstance(messages,list)
                    user_text='\n'.join(x.get('content','').strip() for x in messages if x.get('role')=='user')
                    self.assertTrue(user_text)
                    self.assertNotIn(user_text,prompts)
                    prompts.add(user_text)
                    self.assertTrue(any(x.get('role')=='user' for x in messages))
                    self.assertTrue(any(x.get('role')=='assistant' for x in messages))
                    fingerprint=json.dumps(row,ensure_ascii=False,sort_keys=True,separators=(',',':'))
                    self.assertNotIn(fingerprint,seen)
                    seen.add(fingerprint); total+=1
        self.assertEqual(total,6500)
        self.assertEqual(len(seen),6500)
        self.assertEqual(len(prompts),6500)


class StorageWorkflowTests(unittest.TestCase):
    def setUp(self):
        self.created=[]

    def tearDown(self):
        for dataset_id in reversed(self.created):
            try:
                result=storage.delete_dataset(dataset_id)
                if result.get('backup'):
                    (config.ROOT/result['backup']).unlink(missing_ok=True)
            except Exception:
                pass

    def make_dataset(self,name,rows,kind='knowledge'):
        meta=storage.create_dataset(kind=kind,name=name,category='Test',subcategory='Workflow',description='Temporary dataset created by automated tests.',tags=['test'],records=rows)
        self.created.append(meta['dataset_id'])
        return meta

    def test_crud_version_backup_and_validation(self):
        meta=self.make_dataset('CRUD Test', [record(1),record(2),record(3)])
        fetched=storage.get_dataset(meta['dataset_id'],page=1,page_size=2)
        self.assertEqual(len(fetched['records']),2)
        self.assertEqual(fetched['total_records'],3)
        self.assertTrue(storage.validate_dataset(meta['dataset_id'])['valid'])
        updated=storage.update_dataset(meta['dataset_id'],[record(1),record(2),record(4)],name='CRUD Test Updated')
        self.assertEqual(updated['version'],'1.0.1')
        self.assertTrue((config.ROOT/updated['last_backup']).exists())
        self.assertEqual(storage.get_dataset(meta['dataset_id'],page=1,page_size=10)['metadata']['name'],'CRUD Test Updated')

    def test_paged_editor_never_drops_unseen_records(self):
        rows=[record(i) for i in range(123)]
        meta=self.make_dataset('Paged Editor Test',rows)
        page=storage.get_dataset(meta['dataset_id'],page=2,page_size=50)
        changed=list(page['records'])
        changed[0]=record(5000)
        updated=storage.update_dataset_page(meta['dataset_id'],page=2,page_size=50,records=changed)
        self.assertEqual(updated['number_of_records'],123)
        self.assertEqual(len(storage.get_dataset(meta['dataset_id'],page=3,page_size=50)['records']),23)
        page2=storage.get_dataset(meta['dataset_id'],page=2,page_size=50)
        self.assertIn('5000',page2['records'][0]['messages'][0]['content'])
        self.assertTrue((config.ROOT/updated['last_backup']).exists())

    def test_paged_editor_can_append_records(self):
        rows=[record(i) for i in range(50)]
        meta=self.make_dataset('Paged Append Test',rows)
        page=storage.get_dataset(meta['dataset_id'],page=1,page_size=50)
        page['records'].append(record(51))
        updated=storage.update_dataset_page(meta['dataset_id'],page=1,page_size=50,records=page['records'])
        self.assertEqual(updated['number_of_records'],51)
        second=storage.get_dataset(meta['dataset_id'],page=2,page_size=50)
        self.assertEqual(len(second['records']),1)
        self.assertIn('51',second['records'][0]['messages'][0]['content'])

    def test_merge_split_and_delete_backup(self):
        a=self.make_dataset('Merge A',[record(1),record(2)])
        b=self.make_dataset('Merge B',[record(2),record(3)])
        merged=storage.merge_datasets([a['dataset_id'],b['dataset_id']],'Merge Output')
        merged_id=merged['dataset']['dataset_id']; self.created.append(merged_id)
        self.assertEqual(merged['records'],3)
        self.assertEqual(merged['duplicates_removed'],1)
        split=storage.split_dataset(merged_id,0.67)
        self.created.extend([split['train']['dataset_id'],split['validation']['dataset_id']])
        self.assertEqual(split['train_records']+split['validation_records'],3)
        deleted=storage.delete_dataset(a['dataset_id'])
        self.created.remove(a['dataset_id'])
        self.assertTrue((config.ROOT/deleted['backup']).exists())


class ImportExportTests(unittest.TestCase):
    def test_jsonl_json_csv_roundtrip(self):
        rows=[record(10),record(11)]
        for fmt in ('jsonl','json','csv'):
            exported=import_export.export_dataset(self._temporary_dataset(rows),fmt)
            text=base64.b64decode(exported['content_base64']).decode('utf-8')
            parsed=import_export.parse_import(text,fmt)
            self.assertEqual(len(parsed),2)
            self.assertTrue(all('messages' in item for item in parsed))

    def _temporary_dataset(self,rows):
        meta=storage.create_dataset(kind='knowledge',name='Export Roundtrip Temporary',category='Test',records=rows)
        self.addCleanup(lambda: self._delete(meta['dataset_id']))
        return meta['dataset_id']

    def _delete(self,did):
        try:
            result=storage.delete_dataset(did)
            if result.get('backup'): (config.ROOT/result['backup']).unlink(missing_ok=True)
        except Exception: pass

    def test_invalid_import_is_rejected(self):
        with self.assertRaises(ValueError):
            import_export.parse_import('{"messages":[]}', 'jsonl')
        with self.assertRaises(ValueError):
            import_export.parse_import('prompt,other\nhello,world\n','csv')


class SettingsAndGenerationTests(unittest.TestCase):
    def test_identity_and_theme_customization(self):
        old=config.SETTINGS_FILE
        try:
            with tempfile.TemporaryDirectory() as tmp:
                config.SETTINGS_FILE=Path(tmp)/'settings.json'
                defaults=settings.get_settings()
                self.assertEqual(defaults['identity']['name'],'My AI')
                updated=settings.update_settings({'theme':'light','identity':{'name':'Research Copilot','description':'Test identity'}})
                self.assertEqual(updated['identity']['name'],'Research Copilot')
                self.assertEqual(updated['theme'],'light')
                self.assertNotIn('api_key',settings.get_settings()['provider'])
        finally:
            config.SETTINGS_FILE=old

    def test_local_generator_and_source_note_requirement(self):
        settings_obj={'provider':{'enabled':False}}
        result=generate_preview({'kind':'knowledge','topic':'algorithms','count':5},settings_obj)
        self.assertEqual(result['record_count'],5)
        self.assertTrue(result['validation']['valid'])
        with self.assertRaises(ValueError):
            generate_preview({'kind':'knowledge','topic':'unlisted technical subject','count':1},settings_obj)
        with self.assertRaises(ValueError):
            generate_preview({'kind':'behavior','topic':'planning','count':6,'category':'Planning'},settings_obj)

    def test_training_configuration_persistence(self):
        old=training.TRAINING_CONFIG_FILE
        try:
            with tempfile.TemporaryDirectory() as tmp:
                training.TRAINING_CONFIG_FILE=Path(tmp)/'training.json'
                saved=training.save_config({'model_ref':'local/model','dataset_ids':['example-id'],'validation_split':0.2})
                loaded=training.get_config()
                self.assertEqual(saved['model_ref'],loaded['model_ref'])
                self.assertEqual(loaded['validation_split'],0.2)
        finally:
            training.TRAINING_CONFIG_FILE=old


class HttpSmokeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server=DataForgeServer(('127.0.0.1',0),DataForgeHandler)
        cls.port=cls.server.server_address[1]
        cls.thread=threading.Thread(target=cls.server.serve_forever,daemon=True)
        cls.thread.start()
        cls.base=f'http://127.0.0.1:{cls.port}'

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown(); cls.server.server_close(); cls.thread.join(timeout=2)

    def request(self,path,method='GET',body=None):
        data=None if body is None else json.dumps(body).encode()
        req=urllib.request.Request(self.base+path,data=data,method=method,headers={'Content-Type':'application/json'})
        with urllib.request.urlopen(req,timeout=20) as response:
            return response.status,response.headers.get('Content-Type',''),response.read()

    def test_navigation_shell_and_local_only_binding(self):
        html=(config.ROOT/'frontend'/'index.html').read_text(encoding='utf-8')
        for page in ('dashboard','library','explorer','behavior','knowledge','generator','editor','validator','training','export','import','analytics','settings','about'):
            self.assertIn(f'data-page="{page}"',html)
        with self.assertRaises(ValueError):
            start_server('0.0.0.0', port=0, open_browser=False)

    def test_health_and_application_assets(self):
        status,ctype,raw=self.request('/api/health')
        self.assertEqual(status,200); self.assertIn('application/json',ctype)
        self.assertEqual(json.loads(raw)['product'],'DATAFORGE H1 V1')
        self.assertEqual(self.request('/')[0],200)
        self.assertIn('text/html',self.request('/')[1])
        self.assertEqual(self.request('/assets/app.js')[0],200)
        self.assertEqual(self.request('/assets/styles.css')[0],200)

    def test_library_search_and_stats_routes(self):
        stats=json.loads(self.request('/api/overview')[2])
        self.assertEqual(stats['total_datasets'],1300)
        page=json.loads(self.request('/api/datasets?kind=behavior&page=1&page_size=5&q=reasoning')[2])
        self.assertLessEqual(len(page['datasets']),5)
        self.assertGreater(page['total'],0)

    def test_create_paged_save_and_delete_api_routes(self):
        payload={'kind':'knowledge','name':'HTTP workflow test','category':'Test','subcategory':'HTTP','description':'Temporary HTTP integration dataset.','tags':['test'],'records':[record(801),record(802)]}
        status,ctype,raw=self.request('/api/datasets','POST',payload)
        self.assertEqual(status,201)
        dataset=json.loads(raw)['dataset']; did=dataset['dataset_id']
        self.addCleanup(lambda: self._cleanup_api_dataset(did))
        update={'page':1,'page_size':50,'records':[record(803),record(804),record(805)],'name':'HTTP workflow updated'}
        status,_,raw=self.request(f'/api/datasets/{did}/save','POST',update)
        self.assertEqual(status,200)
        self.assertEqual(json.loads(raw)['dataset']['number_of_records'],3)
        details=json.loads(self.request(f'/api/datasets/{did}?page=1&page_size=10')[2])
        self.assertEqual(len(details['records']),3)
        status,_,raw=self.request(f'/api/datasets/{did}/delete','POST',{})
        self.assertEqual(status,200)
        deleted=json.loads(raw)
        self.assertTrue(deleted.get('backup'))
        (config.ROOT/deleted['backup']).unlink(missing_ok=True)

    def _cleanup_api_dataset(self,did):
        try:
            result=storage.delete_dataset(did)
            if result.get('backup'): (config.ROOT/result['backup']).unlink(missing_ok=True)
        except Exception: pass

    def test_full_library_validation_api(self):
        report=json.loads(self.request('/api/validate-all','POST',{})[2])
        self.assertEqual(report['status'],'passed')
        self.assertEqual(report['datasets_checked'],1300)
        self.assertEqual(report['records_checked'],6500)
        self.assertEqual(report['unique_records'],6500)
        self.assertEqual(report['error_count'],0)
        self.assertEqual(report['warning_count'],0)
        self.assertEqual(report['cross_dataset_duplicates'],0)

    def test_error_handling_for_unknown_dataset(self):
        req=urllib.request.Request(self.base+'/api/datasets/not-a-real-dataset',method='GET')
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            urllib.request.urlopen(req,timeout=10)
        self.assertEqual(ctx.exception.code,404)
        ctx.exception.close()


if __name__=='__main__':
    unittest.main(verbosity=2)
