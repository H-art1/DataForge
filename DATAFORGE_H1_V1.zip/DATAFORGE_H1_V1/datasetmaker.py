"""DATAFORGE H1 V1 application entry point."""
from backend.server import start_server

if __name__ == '__main__':
    import argparse
    import os

    parser = argparse.ArgumentParser(description='Launch DATAFORGE H1 V1 local application.')
    parser.add_argument('--host', default='127.0.0.1', help='Bind address (loopback addresses only).')
    parser.add_argument('--port', type=int, default=int(os.environ.get('DATAFORGE_PORT', '8765')))
    parser.add_argument('--no-browser', action='store_true', help='Do not open the default browser.')
    args = parser.parse_args()
    if args.host not in ('127.0.0.1', 'localhost', '::1'):
        parser.error('DATAFORGE is local-first; the supported launcher binds to loopback only.')
    start_server(args.host, args.port, not args.no_browser)
