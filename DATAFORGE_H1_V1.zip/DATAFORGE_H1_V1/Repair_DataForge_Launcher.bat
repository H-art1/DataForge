@echo off
setlocal
cd /d "%~dp0"
echo DATAFORGE H1 V1 uses the local run.bat launcher.
echo Launching DATAFORGE H1 V1...
call run.bat %*
set "RC=%ERRORLEVEL%"
endlocal & exit /b %RC%
