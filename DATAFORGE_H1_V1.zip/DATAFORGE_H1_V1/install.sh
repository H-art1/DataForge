#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
PYTHON_BIN="${PYTHON:-python3}"
"$PYTHON_BIN" - <<'PY'
import sys
if sys.version_info < (3, 10):
    raise SystemExit('DATAFORGE H1 V1 requires Python 3.10 or later.')
print(f'Python {sys.version.split()[0]} verified.')
PY
"$PYTHON_BIN" -m py_compile datasetmaker.py backend/*.py training_engine.py
printf '\nDATAFORGE H1 V1 is ready. Start it with ./run.sh\n'
