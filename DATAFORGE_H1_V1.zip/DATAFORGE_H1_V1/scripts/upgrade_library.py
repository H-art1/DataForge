from __future__ import annotations
import json, re, shutil, zipfile, sys
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'datasets'
from backend.knowledge_bank import KNOWLEDGE

SUFFIXES = ('fundamentals', 'core_principles', 'worked_examples', 'comparisons', 'pitfalls')
BEHAVIOR_SUFFIXES = ('brief', 'with_example', 'with_reason', 'for_errors', 'for_long_tasks', 'default', 'explain_first', 'examples_first', 'checklist', 'contrast')

BEHAVIOR_CATEGORY = {
    'reasoning': {'diagnostic_hypotheses','evidence_aware','compare_without_ranking','least_change','minimal_assumption','safe_assumption','reproduce_before_fix','one_change_debugging','read_error_message','syntax_check','technical_precision','tradeoff_focus','scope_control','expert_oriented','example_first','socratic','step_by_step'},
    'communication': {'concise','concise_default','detailed','detailed_on_request','friendly','friendly_professional','formal','professional','neutral_tone','direct','patient','encouraging','casual','casual_conversational','plain_language','short_paragraphs','summary_first','structured','structured_sections','checklist_when_complex','format_following','explicit_output','error_first','code_focused','teacher'},
    'conversation': {'clarify_goal','goal_confirmation','one_question_at_a_time','context_first','progressive_disclosure','user_agency','actionable_next_step','partial_results','preserve_existing_features'},
    'planning': {'constraint_tracking','checkpoint_long_tasks','batch_large_jobs','clear_status','confirm_destructive','disk_space_check','train_again_prompt','resume_integrity','resume_api_jobs','training_caps','hard_cap_epochs','hard_cap_steps','hard_cap_batch','hard_cap_sequence','lower_than_cap'},
    'reliability': {'no_fabrication','uncertainty_honest','uncertainty_aware','no_fake_progress','error_recovery','retry_transient','rollback_safe','regression_check','atomic_save','backup_before_change','graceful_permission_error','timeout_external_calls','api_error_specific','diagnostic_hypotheses','partial_results'},
    'data_quality': {'dataset_role_integrity','dataset_validation','deduplicate_records','safe_file_names','input_validation','model_input_validation','training_config_record','training_artifact_clarity_for_long_tasks'},
    'security': {'no_secret_echo','secret_env_precedence','secure_key_storage','validate_api_key_shape','safety_conscious','respect_rate_limits'},
    'software_operations': {'dependency_clarity','dependency_map','dependency_plan','environment_check','post_install_recheck','idempotent_install','install_confirmation','pytorch_build_match','cuda_validation','cpu_fallback','qlora_requires_cuda','lora_target_detection','model_load_failure','ollama_name_validation','ollama_timeout','supported_family_check','installer_version_arg_for_errors','future_version_discovery','version_deduplicate','version_selector','version_visibility','theme_persistence'},
}

def nice(slug: str) -> str:
    s = re.sub(r'^\d+_', '', slug)
    for suffix in SUFFIXES + BEHAVIOR_SUFFIXES:
        if s.endswith('_' + suffix):
            s = s[:-(len(suffix)+1)]
            break
    replacements = {'ai':'AI','api':'API','cuda':'CUDA','cpu':'CPU','gpu':'GPU','qlora':'QLoRA','lora':'LoRA','tcp':'TCP','ip':'IP','dns':'DNS','http':'HTTP','https':'HTTPS','wifi':'Wi-Fi','wi_fi':'Wi-Fi','ci_cd':'CI/CD','json':'JSON','csv':'CSV','ipv4':'IPv4','ipv6':'IPv6','sql':'SQL','dns':'DNS','ram':'RAM','os':'OS'}
    words = s.split('_')
    return ' '.join(replacements.get(w.lower(), w.capitalize()) for w in words)

def behavior_category(slug: str) -> str:
    s = re.sub(r'^\d+_', '', slug)
    for suffix in BEHAVIOR_SUFFIXES:
        if s.endswith('_' + suffix): s = s[:-(len(suffix)+1)]; break
    for category, keys in BEHAVIOR_CATEGORY.items():
        if s in keys: return category.replace('_',' ').title()
    if any(k in s for k in ('key','secret','auth','secure','safety','rate_limit')): return 'Security'
    if any(k in s for k in ('dataset','file','save','backup','disk','format','dedup','atomic')): return 'Data Quality'
    if any(k in s for k in ('training','model','cuda','lora','ollama','dependency','install','version','pytorch')): return 'Software Operations'
    if any(k in s for k in ('plan','goal','checkpoint','batch','resume','priority','task')): return 'Planning'
    if any(k in s for k in ('error','failure','retry','rollback','timeout','progress','uncertainty')): return 'Reliability'
    if any(k in s for k in ('clarify','question','context','user','conversation')): return 'Conversation'
    if any(k in s for k in ('tone','friendly','formal','concise','detailed','plain','professional','brief','structured','style')): return 'Communication'
    return 'Reasoning'

def knowledge_records(key: str, kind: str):
    domain, subcat, definition, example, related, pitfall = KNOWLEDGE[key]
    label = nice(key)
    # Each dataset has a distinct instructional purpose and five non-identical prompts.
    if kind == 'fundamentals':
        pairs = [
            (f"What is {label} in {domain}?", definition),
            (f"Explain the purpose of {label} to a beginner.", f"{definition} {example}"),
            (f"Where might someone use {label} in a practical task?", f"A practical setting is this: {example} The key is to match the method to the problem and state any assumptions that affect the result."),
            (f"What nearby idea helps put {label} in context?", f"{label} is related to {related}, but the two ideas answer different questions. {definition}"),
            (f"What should a learner remember before applying {label}?", f"Start from this principle: {definition} Then check the context-specific limitation: {pitfall}"),
        ]
    elif kind == 'core_principles':
        pairs = [
            (f"State the central principle behind {label}.", definition),
            (f"What rule or relationship is useful when working with {label}?", f"Use the concept in a way that matches its definition: {definition} For example, {example}"),
            (f"Which assumptions should be checked when applying {label}?", f"Check the conditions of the problem before applying a rule. For {label}, one important boundary is: {pitfall}"),
            (f"How can a result involving {label} be checked?", f"Work through the inputs and units, then compare the result with the expected behavior. A representative case is {example}"),
            (f"How is {label} connected to a broader {domain.lower()} idea?", f"{label} is often considered alongside {related}. {definition} Keeping the distinction clear prevents a category error."),
        ]
    elif kind == 'worked_examples':
        pairs = [
            (f"Work through this example of {label}: {example}", f"First identify the relevant quantities or system: {example} Next apply the defining idea: {definition} Finally interpret the outcome in the original context rather than treating the calculation or observation as context-free."),
            (f"Can you explain the steps in the {label} example?", f"1. Identify the concept and its assumptions. 2. Apply it to the case: {example} 3. Check whether the conclusion is consistent with the definition: {definition}"),
            (f"What does the practical example teach about {label}?", f"The example, {example} illustrates the central role of {label}. The result should be interpreted using the relevant conditions; {pitfall}"),
            (f"Give me a beginner-friendly application of {label}.", f"Consider this case: {example} It is useful because it connects the abstract idea to an observable task. The governing concept is: {definition}"),
            (f"How would you verify the example involving {label}?", f"Verify each input and assumption, repeat the reasoning independently, and check the result against the domain rules. In this case: {example} Remember that {pitfall}"),
        ]
    elif kind == 'comparisons':
        pairs = [
            (f"How does {label} differ from {related}?", f"{label} focuses on this idea: {definition} {related} is a related but distinct concept; choose between them based on the question being answered, not just similar terminology."),
            (f"When should I use {label} rather than {related}?", f"Use {label} when the task matches its purpose: {example} Use {related} when the problem instead requires its own assumptions and outputs. The distinction matters because {pitfall}"),
            (f"Are {label} and {related} interchangeable?", f"No. They are connected but not interchangeable. {definition} In contrast, {related} addresses a neighboring part of the problem. The practical boundary is determined by the task and its required result."),
            (f"Compare the strengths and limits of {label} with {related}.", f"The main strength of {label} is that it addresses the problem described here: {definition} Its limitation is: {pitfall} Compare those properties with {related} before selecting a method."),
            (f"Give a real-world distinction between {label} and {related}.", f"For example, {example} is a case where {label} is relevant. A task centered on {related} would require a different model or procedure. Keep each concept's scope separate."),
        ]
    else:  # pitfalls
        pairs = [
            (f"What is a common misconception about {label}?", pitfall),
            (f"What mistake should a beginner avoid when using {label}?", f"Do not apply {label} without checking its assumptions. {pitfall} A useful check is to test the reasoning on a small, representative case such as: {example}"),
            (f"How can I tell whether I have misunderstood {label}?", f"Look for conclusions that conflict with the definition or the conditions of the problem. {definition} One warning sign is: {pitfall}"),
            (f"What limitation should be included in an explanation of {label}?", f"A sound explanation should state the scope and limitations, not just the headline rule. For {label}: {pitfall}"),
            (f"How do I avoid overgeneralizing from an example of {label}?", f"Treat examples as demonstrations, not universal proof. Check whether the assumptions hold in the new case. For reference: {example} The key caution is: {pitfall}"),
        ]
    return [{'messages':[{'role':'user','content':q},{'role':'assistant','content':a}]} for q,a in pairs]

BEHAVIOR_VARIANTS = {
    'brief': ('Brief Responses', 'short, accurate answers that preserve essential information'),
    'with_example': ('Example Led', 'concrete examples that make the behaviour observable'),
    'with_reason': ('Reasoned Guidance', 'clear explanations of why the behaviour is useful'),
    'for_errors': ('Error Scenarios', 'calm, diagnostic responses when something goes wrong'),
    'for_long_tasks': ('Long Task Support', 'consistent behaviour across multi-stage work'),
    'default': ('Default Practice', 'reliable behaviour in everyday assistant interactions'),
    'explain_first': ('Explain First', 'a clear principle before the practical recommendation'),
    'examples_first': ('Examples First', 'a practical example before the general rule'),
    'checklist': ('Checklist Practice', 'an actionable checklist for consistent execution'),
    'contrast': ('Behaviour Contrast', 'the practical difference between good and poor responses'),
}

BEHAVIOR_PROMPTS = {
    'brief': [
        'A user asks for a quick explanation of {name}. How can the assistant answer concisely without losing the essential point?',
        'The user has little time and needs help applying {name}. What short reply would still be accurate and useful?',
        'Rewrite an overlong response about {name} so that the key guidance is easy to act on.',
        'A user asks for the next step related to {name}. Give a focused response with no unnecessary framing.',
        'How can an assistant stay concise while handling a follow-up question about {name}?',
    ],
    'with_example': [
        'Show a realistic assistant-user exchange that demonstrates {name}.',
        'A learner does not understand {name}. Teach it through one concrete example and explain what makes the example effective.',
        'Give an example of a response that applies {name} well, then identify the behaviour it demonstrates.',
        'Create a practical scenario in which {name} matters and show the assistant responding appropriately.',
        'What example would help a new assistant recognize when to use {name}?',
    ],
    'with_reason': [
        'Why does {name} improve the quality of an assistant response? Explain the reason and the practical effect.',
        'A user asks why the assistant is following {name}. How should the assistant explain its choice?',
        'Describe the trade-off involved in applying {name} and explain why the recommended approach is appropriate.',
        'What problem can occur when {name} is ignored, and why does the behaviour prevent it?',
        'Explain the principle behind {name}, then connect it to a useful response decision.',
    ],
    'for_errors': [
        'A user reports that something went wrong while applying {name}. What should the assistant check before suggesting a fix?',
        'An earlier answer about {name} contained an error. How should the assistant acknowledge and correct it?',
        'A user is frustrated by a failed attempt involving {name}. Give a calm, practical recovery response.',
        'Several possible causes could explain a problem related to {name}. How should the assistant narrow them down?',
        'What should the assistant do when it cannot confidently resolve an error involving {name}?',
    ],
    'for_long_tasks': [
        'A user has a multi-stage project where {name} must remain consistent. How should the assistant manage the work?',
        'A long task has resumed after a pause. What context should the assistant re-check to continue applying {name}?',
        'The requirements of a project change midway through work involving {name}. How should the assistant adapt?',
        'How can the assistant maintain {name} across several milestones without repeating unnecessary information?',
        'A project is almost complete, but the final response must still reflect {name}. What should be checked?',
    ],
    'default': [
        'In an ordinary help request, what does applying {name} look like from the first response through completion?',
        'A user asks for a practical recommendation related to {name}. What should a dependable assistant do?',
        'What signals tell an assistant that {name} is relevant to the current request?',
        "How should the assistant balance the user's immediate request with the principle of {name}?",
        'Describe a reliable default response pattern for a conversation where {name} matters.',
    ],
    'explain_first': [
        'Before giving a solution, how should the assistant explain the core idea behind {name}?',
        'A user is unfamiliar with {name}. Write an explanation-first response that builds understanding before giving advice.',
        'What key term or assumption should be clarified before applying {name} to a task?',
        'Show how to introduce the principle of {name} in plain language before moving to the practical steps.',
        'How can the assistant explain {name} without overwhelming a beginner with unnecessary detail?',
    ],
    'examples_first': [
        'Start with a concrete example of {name}, then state the general rule an assistant should learn from it.',
        'A user learns best by seeing a worked situation. Demonstrate {name} before explaining the abstract principle.',
        'Choose a simple scenario that illustrates {name} and explain why it is representative.',
        'How can an assistant use an example to make {name} understandable without implying that every case is identical?',
        'Give an example-first teaching response for {name}, followed by a concise takeaway.',
    ],
    'checklist': [
        'Create a short pre-response checklist an assistant can use to apply {name} consistently.',
        'What should an assistant verify while drafting a response that depends on {name}?',
        'Turn {name} into a practical sequence of checks that can be used during a conversation.',
        'Give a final quality-control checklist for a response intended to demonstrate {name}.',
        'Which observable checks distinguish a response that follows {name} from one that only claims to?',
    ],
    'contrast': [
        'Compare an assistant response that follows {name} with one that violates it. Explain the practical difference.',
        'Give a before-and-after example showing how a response improves when {name} is applied.',
        'What is a subtle failure mode that looks like {name} but does not actually satisfy it?',
        'Contrast a rushed application of {name} with a careful one and identify the important distinction.',
        'How can a reviewer recognize the difference between genuine {name} and superficial compliance?',
    ],
}

def behavior_variant(slug: str) -> str:
    s = re.sub(r'^\d+_', '', slug)
    return next((suffix for suffix in BEHAVIOR_SUFFIXES if s.endswith('_' + suffix)), 'default')

def behavior_prompts(slug: str) -> list[str]:
    name = nice(slug)
    variant = behavior_variant(slug)
    return [template.format(name=name) for template in BEHAVIOR_PROMPTS[variant]]

def make_metadata(path: Path, kind: str, records: list[dict]) -> dict:
    slug = path.stem
    if kind == 'behavior':
        cat = behavior_category(slug)
        sub = nice(slug)
        variant = behavior_variant(slug)
        variant_name, focus = BEHAVIOR_VARIANTS[variant]
        description = f"Assistant-behaviour dataset for {sub.lower()}, focused on {variant_name.lower()}. It trains {focus} through five distinct instruction-tuning examples."
    else:
        stripped = re.sub(r'^\d+_', '', slug)
        suffix = next((x for x in SUFFIXES if stripped.endswith('_'+x)), None)
        key = stripped[:-(len(suffix)+1)] if suffix else stripped
        if key in KNOWLEDGE:
            domain, sub, definition, *_ = KNOWLEDGE[key]
            cat = domain
            description = f"{nice(key)} examples for {domain.lower()}, focused on {suffix.replace('_',' ') if suffix else 'topic-specific learning'}. {definition}"
        else:
            cat = 'General knowledge'
            sub = nice(slug)
            description = f"Topic-specific knowledge examples for {sub}, preserved from the V13.3 library and available for review."
    users = [m['content'] for r in records for m in r.get('messages',[]) if m.get('role')=='user']
    assistants = [m['content'] for r in records for m in r.get('messages',[]) if m.get('role')=='assistant']
    content_short = any(len(x.strip()) < 35 for x in assistants)
    seen = set(); duplicate = False
    for r in records:
        k = json.dumps(r, ensure_ascii=False, sort_keys=True)
        if k in seen: duplicate = True
        seen.add(k)
    stat = path.stat()
    display_name = nice(slug)
    extra_tags = []
    if kind == 'behavior':
        variant = behavior_variant(slug)
        variant_name, _ = BEHAVIOR_VARIANTS[variant]
        display_name = f"{display_name} — {variant_name}"
        extra_tags.extend([t.lower() for t in re.findall(r'[A-Za-z0-9]+', variant_name)])
    elif kind == 'knowledge':
        stripped = re.sub(r'^\d+_', '', slug)
        suffix = next((x for x in SUFFIXES if stripped.endswith('_' + x)), None)
        key = stripped[:-(len(suffix)+1)] if suffix else stripped
        if suffix and key in KNOWLEDGE:
            variant_name = suffix.replace('_', ' ').title()
            display_name = f"{display_name} — {variant_name}"
            extra_tags.extend([t.lower() for t in re.findall(r'[A-Za-z0-9]+', variant_name)])
    return {
        'dataset_id': f"{kind}-{slug}",
        'name': display_name,
        'category': cat,
        'subcategory': sub,
        'description': description,
        'number_of_records': len(records),
        'format': 'JSONL',
        'creation_date': datetime.fromtimestamp(stat.st_mtime, timezone.utc).date().isoformat(),
        'version': '1.0.0',
        'tags': list(dict.fromkeys([kind, cat.lower(), *[t.lower() for t in re.findall(r'[A-Za-z0-9]+', sub) if len(t)>2][:6], *extra_tags])),
        'quality_status': 'review recommended' if duplicate or content_short or not records else 'validated',
        'file': str(path.relative_to(ROOT)).replace('\\','/'),
        'kind': kind,
    }

def write_jsonl(path: Path, records):
    tmp = path.with_suffix(path.suffix+'.tmp')
    with tmp.open('w', encoding='utf-8', newline='\n') as f:
        for row in records:
            f.write(json.dumps(row, ensure_ascii=False, separators=(',',':'))+'\n')
    tmp.replace(path)

# Repair the 500 template-derived knowledge datasets whose previous records were
# boilerplate. The other 200 hand-authored topic files are retained verbatim.
for p in sorted((DATA/'knowledge').glob('*.jsonl')):
    stripped = re.sub(r'^\d+_', '', p.stem)
    suffix = next((x for x in SUFFIXES if stripped.endswith('_'+x)), None)
    if suffix:
        key = stripped[:-(len(suffix)+1)]
        if key in KNOWLEDGE:
            write_jsonl(p, knowledge_records(key, suffix))

# Give each behaviour dataset variant its own scenario-oriented prompts while
# retaining its distinct behaviour instructions and answer variants.
for p in sorted((DATA/'behavior').glob('*.jsonl')):
    rows = []
    for i, line in enumerate(p.read_text(encoding='utf-8').splitlines()):
        if not line.strip(): continue
        row = json.loads(line)
        messages = row.get('messages', [])
        if len(messages) >= 2:
            user = next((m for m in messages if m.get('role') == 'user'), None)
            if user:
                user['content'] = behavior_prompts(p.stem)[i % 5]
        rows.append(row)
    write_jsonl(p, rows)

manifest = []
for kind in ('behavior','knowledge'):
    for p in sorted((DATA/kind).glob('*.jsonl')):
        rows = []
        for line in p.read_text(encoding='utf-8').splitlines():
            if line.strip():
                try: rows.append(json.loads(line))
                except json.JSONDecodeError: pass
        manifest.append(make_metadata(p,kind,rows))

(DATA/'manifest.json').write_text(json.dumps({'schema_version':1,'product':'DATAFORGE H1 V1','generated_at':datetime.now(timezone.utc).isoformat(),'datasets':manifest},indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
index = {
    'version':'V1',
    'behavior_datasets':sum(x['kind']=='behavior' for x in manifest),
    'knowledge_datasets':sum(x['kind']=='knowledge' for x in manifest),
    'total_datasets':len(manifest),
    'behavior_records':sum(x['number_of_records'] for x in manifest if x['kind']=='behavior'),
    'knowledge_records':sum(x['number_of_records'] for x in manifest if x['kind']=='knowledge'),
    'schema':'Chat messages: {"messages":[{"role":"user","content":"..."},{"role":"assistant","content":"..."}]}',
    'metadata_file':'manifest.json',
    'archived_v13_3_library':'../archive/v13_3_dataset_library.zip'
}
(DATA/'index.json').write_text(json.dumps(index,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(json.dumps(index,indent=2))
