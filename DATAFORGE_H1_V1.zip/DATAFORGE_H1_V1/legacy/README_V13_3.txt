DATAFORGE H1 V13.3
==================

V13.3 fixes the CUDA setup failure shown in V13.1 when nvidia-smi did not expose a parseable CUDA Version string.

CUDA / QLoRA FIX
----------------
- DATAFORGE no longer requires a parsed nvidia-smi CUDA Version before attempting setup.
- It detects NVIDIA hardware with nvidia-smi and a Windows device-enumeration fallback.
- It tries official PyTorch CUDA wheel indexes in descending preference: cu128, cu126, cu124, cu121, cu118.
- Each installation is followed by a fresh-process torch.cuda.is_available() verification.
- An incompatible wheel is treated as a failed attempt and DATAFORGE continues to the next official index.
- Failed QLoRA setup can be retried without restarting DATAFORGE.
- Empty pip install commands are still impossible.

The official PyTorch installation guidance recommends selecting the CUDA platform suited to the system and verifying GPU access with torch.cuda.is_available().

LAUNCHER
--------
- The V13.1 safe PowerShell dispatcher is preserved.
- The installer validates the dispatcher before reporting success.
- Duplicate installations are deduplicated by path.
- Future sibling DATAFORGE_H1_DatasetMaker_v* folders can be discovered.

TRAINING
--------
- Ollama checks remain bounded and model names are validated before loading.
- Hardware caps are calculated after dependency setup.
- LoRA / QLoRA / full fine-tune remain available.

IMPORTANT
---------
V13.3 cannot verify a real NVIDIA driver or perform a live CUDA training run inside this package build environment. The final CUDA installation and training test must be performed on the user's Windows machine.

SCREENSHOT-SPECIFIC FIX
------------------------
V13.1 could report: "Could not determine a supported CUDA wheel index from the NVIDIA driver."
That happened when nvidia-smi did not provide a parseable CUDA Version string even though an NVIDIA GPU was present. V13.3 no longer uses that string as the gate for CUDA installation.

When QLoRA needs CUDA PyTorch, V13.3 now shows the NVIDIA detection result, tries the official PyTorch wheel indexes in order, and verifies the installed torch package from a fresh Python process before moving on. If all attempts fail, DATAFORGE offers a retry instead of silently hanging or pretending training started.
