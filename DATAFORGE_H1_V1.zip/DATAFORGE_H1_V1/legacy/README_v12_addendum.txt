DATAFORGE H1 V12 ADDENDUM

New training data libraries:
- 500 separate Knowledge datasets
- 100 separate Behavior datasets
- They are stored separately under datasets/knowledge and datasets/behavior.

Train Model is now operational:
- LoRA
- QLoRA
- Full fine-tune
- Pre-existing model IDs: Gemma family, OpenAI gpt-oss, Dolphin family
- Custom Hugging Face model ID or local checkpoint
- Ollama model bridge

The app checks training dependencies and hardware before starting. Missing Python
packages can be installed after explicit user confirmation. QLoRA requires CUDA
usable by PyTorch on this build. Hardware-based caps are enforced for epochs,
steps/epoch, batch size, gradient accumulation, sequence length, and LoRA rank.
Users may choose lower values.

UI themes:
Cyan, Emerald, Purple, Amber, Blue, Red, White, Mono.
