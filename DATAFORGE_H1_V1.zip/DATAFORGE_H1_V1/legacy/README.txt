DATAFORGE H1 V13.3
================

DATA LIBRARY EXPANSION
----------------------
V13.3 adds exactly 500 new Behavior datasets and exactly 200 new Knowledge datasets.
Because V12 shipped 100 Behavior and 500 Knowledge datasets, the shipped libraries
now contain 600 Behavior and 700 Knowledge datasets respectively. Knowledge and
Behavior remain separate on disk and in the training-data selector.

BUG FIXES AND HARDENING
-----------------------
- Universal version selector now deduplicates the same installation path, so a
  registered folder and its legacy per-version launcher do not appear twice.
- Version selector accepts numbers and version names such as V13.3.
- Future sibling DATAFORGE_H1_DatasetMaker_v* folders continue to be auto-discovered.
- Missing-dependency installation never calls pip with an empty package list.
- Missing training packages are mapped explicitly to installable package names.
- CUDA is verified with torch.cuda.is_available() after attempting a CUDA PyTorch install.
- NVIDIA driver information is used to choose a bounded set of CUDA wheel indexes.
- Ollama model names are validated against `ollama list` before model inspection.
- Ollama commands have finite timeouts so invalid models cannot leave the UI waiting forever.
- Training dependency status is rechecked after installation.
- Malformed training records are skipped and valid records are deduplicated before training.
- Trainer tokenizer/processing-class compatibility is handled across supported
  Transformers versions.
- Training runs save the effective model, method, selected files, hardware profile,
  and settings alongside the final artifact.
- Windows training uses zero dataloader worker processes to reduce multiprocessing
  surprises in terminal-based runs.

TRAINING
--------
LoRA, QLoRA, and full fine-tuning remain available. Pre-existing model IDs are
restricted to Gemma, GPT-OSS, and Dolphin families; custom HF/local checkpoints and
Ollama model sources are supported as before. QLoRA requires verified CUDA-capable
PyTorch in V13.3. Hardware-based hard caps prevent the user from selecting epochs,
steps, batch size, sequence length, or LoRA rank above the calculated DATAFORGE ceiling.

V13.3 is a continuation of the existing DATAFORGE H1 project; previous dataset, image
generation, API-key, AI-name, theme, resume, archive, and global `dataforge` features
remain included.

DATAFORGE H1 V12

DATAFORGE H1 DATASET MAKER v3

QUICK SETUP
-----------
Use the **AI Name Studio** in the main menu to set any AI name you want. The name is stored for this DATAFORGE version. The AI Name Studio also includes a separate **Change AI Name in ALL Base Templates** action that refreshes every built-in text template and the active base dataset with the current name.

BASE DATASET TEMPLATES
----------------------
The program includes:
- Gen-Z
- Friendly
- Explainer
- Honest
- Correction
- Serious
- Personality
- Boundaries
- All templates

The base dataset is the SEED MATERIAL. The generator takes those examples
and creates variations to build dataset.jsonl.

DATASET SIZE
------------
Choose any target from 10 MB to 5 GB.

CONTROLS
--------
P = Pause
C = Continue
S = Stop and save

If stopped, choose Resume Dataset next time.

RUN
---
Double-click run.bat

OR:

python datasetmaker.py

IMPORTANT
---------
A bigger synthetic dataset is not automatically a better training dataset.
Use high-quality, diverse seed examples. The generator is a starting point,
not a substitute for a carefully curated training corpus.


NEW IN v2
---------
SIDEBAR / NAVIGATION
--------------------
The terminal now has a sidebar-style navigation panel.

OLD GENERATIONS
----------------
When you create a replacement dataset, the previous dataset is archived
under:

    generations/

Use [3] Old Generations to see old datasets and switch the active
dataset back to one of them.

IMAGE GENERATION
----------------
The sidebar contains a locked Image Generation panel:

    🔒 IMAGE GENERATION
          COMING SOON

It is only a UI placeholder for now.


V5 IMAGE TEMPLATE LIBRARY
- Added exactly 30 base image-generation templates from the supplied specification.
- Centralized metadata: templates/image_templates/image_templates.json
- Local SVG previews: templates/image_templates/previews/
- Menu option [7] Image Templates supports browse, search, category filtering, and Use Template.
- Selected template settings are saved to selected_image_template.json.
- The current DATAFORGE project is a terminal dataset generator and does not contain an image-generation engine; template selection therefore does not generate images automatically.

DATAFORGE H1 v6 CHANGE
-----------------------
Before a new dataset is generated, immediately after entering the dataset size, DATAFORGE now asks which seed dataset to use:
  1. Default Dataset — uses the current base_dataset.jsonl.
  2. Select a Dataset — choose one built-in base template for this generation.
  3. Back.

Selecting a built-in dataset for generation does not overwrite or modify base_dataset.jsonl. Resume Dataset behavior remains unchanged.


V7 COMMAND-LINE LAUNCH
-----------------------
DATAFORGE can now be launched from a normal fresh Windows terminal by typing:

    dataforge

ONE-TIME SETUP
--------------
Double-click:

    Install_DataForge.bat

The installer creates a user-level DATAFORGE launcher in %USERPROFILE%\bin and
adds that folder to your user PATH. Close the installer, open a NEW terminal,
and type `dataforge` from any folder. You do not need to cd into the project
folder or manually open a terminal there.

The launcher uses `python` when available and falls back to `py -3`.

TRAIN MODEL
-----------
A locked TRAIN MODEL panel is displayed directly beneath IMAGE GENERATION:

    🔒 TRAIN MODEL
          COMING SOON

Menu option [8] Train Model (LOCKED) only shows the coming-soon screen.
No training backend was added. Existing dataset generation and all previous
features remain unchanged.


TEXT BASE DATASET LIBRARY
-------------------------
V8 adds 30 new text base datasets to the existing Base Templates system.
The original built-in templates are preserved, and the new library is available
from [4] Base Templates and from the dataset-source selector used during dataset generation.

New text datasets:
01 Coding
02 Python
03 JavaScript
04 Mathematics
05 Physics
06 Chemistry
07 Biology
08 Geography
09 History
10 Literature
11 Writing
12 Grammar
13 Translation
14 Summarization
15 Brainstorming
16 Study Help
17 Productivity
18 Customer Support
19 Troubleshooting
20 FAQ
21 Cybersecurity Awareness
22 Data Analysis
23 SQL
24 Web Development
25 Linux
26 Windows
27 Networking
28 Creative Writing
29 Roleplay
30 General Knowledge
Each new text dataset contains five seed examples.

The new datasets are stored as JSONL files under templates/ and are also embedded
in datasetmaker.py so the app can recreate missing template files without deleting
or replacing existing user-created template files.

V9 VERSION / GENERATION MODES
-----------------------------
V9 is shown in the DATAFORGE title banner and sidebar so the running version is
visible immediately after launch.

After entering a dataset size, V9 asks for a generation type:
  1. Coding — coding/programming templates only.
  2. Chatbot — conversational/assistant templates only.
  3. Coding + Chatbot — both libraries, with a 70% chatbot / 30% coding sampling
     bias during generation.

The template selector shows the type beside every template. Coding-only mode
cannot select chatbot templates, and Chatbot-only mode cannot select coding
templates.

V9 adds 20 more text datasets (10 coding and 10 chatbot):
C++, Java, C#, Rust, Go, TypeScript, Git, Algorithms, Machine Learning, Regex,
Travel Assistant, Tutor, Interview Coach, Email Assistant, Recipe Assistant,
Fitness Coach, Language Practice, Debate Practice, Customer Service, and
Personal Assistant.

OUTPUT FILENAMES
----------------
When generation finishes, DATAFORGE asks for the output filename. Press Enter
without typing a name to use:

    no-name-dataset.jsonl

If a name does not end in .jsonl, DATAFORGE adds .jsonl automatically. The
selected active filename is remembered for later launches.

VERSION INSTALLER
-----------------
Install_DataForge.bat now supports V8 and V9. You can either pass a version:

    Install_DataForge.bat V9

or simply double-click it and choose V8 or V9 when prompted. V8 is detected as
a sibling folder named DATAFORGE_H1_DatasetMaker_v8. To switch the global
`dataforge` command between versions, run the installer again and choose the
other version, then open a NEW terminal.


V10
===
DATAFORGE V10 is the current build in this package. The main banner, sidebar, and terminal title identify the running build as V10.

50 NEW TEXT DATASETS
--------------------
V10 adds exactly 50 additional text-based dataset templates. Existing V9 templates are preserved.

VERSION-AWARE DATAFORGE COMMAND
--------------------------------
The V10 installer registers discoverable V8, V9, and V10 project folders as separate launchers under %USERPROFILE%\\bin. The global `dataforge` command checks how many versions are registered. If exactly one is found, it launches it directly. If two or more are found, it displays a version selector and asks which DATAFORGE version to launch.

ONE-TIME SETUP
--------------
Run from the version folder you want to register:

    .\\Install_DataForge.bat V10

or double-click the installer. If no version is supplied, it asks for the version contained in the current folder.

After installation, open a NEW terminal and type:

    dataforge

The dispatcher will detect registered versions before launching.



V10.1
=====
DATAFORGE V10.1 is the future-compatible launcher build. The running banner, sidebar, and Windows terminal title identify the build as V10.1.

FUTURE-COMPATIBLE GLOBAL DATAFORGE COMMAND
-------------------------------------------
Installing V10.1 or V11 installs the universal `dataforge` dispatcher under %USERPROFILE%\bin. The dispatcher does not hard-code a fixed list of versions. It reads registered version paths and automatically scans registered parent folders for any DATAFORGE_H1_DatasetMaker_v* folder containing datasetmaker.py.

This means future versions can be added beside V10.1 and the existing `dataforge` command can discover them without reinstalling V10.1. When multiple versions are detected, `dataforge` shows them and asks which one to launch. When only one is detected, it launches that version directly.

ONE-TIME SETUP
--------------
Run this from the version folder you want to register:

    .\Install_DataForge.bat 10.1

or double-click the installer and enter the version when prompted. Then open a NEW terminal and type:

    dataforge

FUTURE VERSION BEHAVIOR
------------------------
Future DATAFORGE installers based on this universal dispatcher can register their own exact path. Future version folders placed beside a registered DATAFORGE folder are auto-discovered as long as they use the DATAFORGE_H1_DatasetMaker_v* naming pattern and contain datasetmaker.py.

The package includes `dataforge_dispatcher.cmd`, the universal dispatcher copied into the user's global DATAFORGE command location by the installer.


V11 IMAGE DATASET GENERATOR
---------------------------
V11 adds a real OpenAI image dataset generator.

From the main menu choose:

    [8] Image Dataset Generator

The generator asks for a natural-language image description, for example:

    images of friendly golden retriever dogs playing in a park

Then choose one of the supported dataset sizes:

    5, 10, 15, 20, 30, 35, 40, 45, 50 images

DATAFORGE batches requests automatically because the current Images API limits a
single request to at most 10 images. V11 uses the GPT-Image-2 model and saves the
returned PNGs plus metadata.jsonl and dataset_info.json inside image_datasets/.

OPENAI API KEY
--------------
V11 requires an OpenAI API key for image generation. The key is never bundled
with the DATAFORGE ZIP and is not written into the Python source code.

Use:

    [9] Image API Key Setup

or let the image generator prompt for the key. DATAFORGE stores the key locally
at the user's home .dataforge folder. You may instead set OPENAI_API_KEY in the
environment, which takes precedence.

Image generation uses the OpenAI Images API endpoint. API usage is subject to
OpenAI account access, model availability, safety controls, and API charges.

TEXT TEMPLATES
--------------
V11 adds 50 additional text datasets while preserving all earlier templates.


V12
=====
DATAFORGE V11.1 is the UI and AI-name update build. The main banner, dashboard, and Windows terminal title identify the running build as V11.1.

AI NAME STUDIO
--------------
The main menu includes:

    [7] AI Name Studio

Inside AI Name Studio:

    [1] Set AI Name
    [2] Change AI Name in ALL Base Templates
    [3] Back

The AI name can be any non-empty value. It is saved locally in `ai_name.txt` for the active DATAFORGE version. The global apply action rewrites the built-in text template JSONL files using the current name and also refreshes `base_dataset.jsonl`. Template selection and generation also apply the current AI name automatically, so the runtime uses the latest name even before the global refresh is run.

IMPROVED UI
-----------
V11.1 replaces the older sidebar with a compact terminal dashboard that separates dataset tools from image/model tools, shows the DATAFORGE version and current AI name at the top, and keeps the active dataset visible.

TEXT TEMPLATE COUNT
-------------------
V11.1 preserves the full V11 text-template library: 156 built-in text templates in total.

IMAGE DATASET GENERATOR MENU
----------------------------
The V11 image dataset generator remains available as:

    [9] Image Dataset Gen
    [10] Image API Key Setup

The supported image counts remain 5, 10, 15, 20, 30, 35, 40, 45, and 50.


V12
===
V12 separates the new training-data library into two families: Knowledge and Behavior.

DATA LIBRARY
------------
500 Knowledge datasets and 100 Behavior datasets are shipped as separate JSONL
files under datasets/knowledge/ and datasets/behavior/. The main menu includes a
Training Data Library browser, and the Train Model wizard can use all Knowledge data,
all Behavior data, both, or a selected subset.

TRAIN MODEL
-----------
The Train Model feature now supports LoRA, QLoRA, and full fine-tuning using a
Hugging Face model ID, local checkpoint directory, or an Ollama model reference.
The supported pre-existing families are Gemma, OpenAI gpt-oss, and Dolphin; the
wizard accepts exact model IDs so compatible variants do not require a DATAFORGE
code update.

For LoRA/QLoRA training, DATAFORGE uses Transformers + PEFT. QLoRA uses 4-bit
quantization through bitsandbytes when available. Before training, DATAFORGE checks
PyTorch, CUDA availability, Transformers, PEFT, Accelerate, Datasets, bitsandbytes
(for QLoRA), and Ollama when Ollama mode is selected. Missing software triggers an
explicit install/download prompt rather than silent installation.

Hardware caps are computed from CPU, RAM, GPU, VRAM, and CUDA availability. The user
can select the detected cap or a lower value. Caps are conservative estimates, not
guarantees that every model will fit.

OLLAMA
------
An Ollama model name can be entered. DATAFORGE inspects the model definition. If it
points to a trainable local Safetensors directory, that path can be used. For an
Ollama GGUF/inference package, DATAFORGE asks for the corresponding Hugging Face or
Safetensors base checkpoint because the Transformers/PEFT trainer does not treat an
arbitrary GGUF file as a trainable model. After training, an Ollama Modelfile can be
created for the resulting adapter/checkpoint.

UI THEMES
---------
Menu option [13] provides Cyan, Emerald, Purple, Amber, Blue, Red, White, and Mono
terminal accent themes.

V13.3 QUICK INSTALL
--------------------
From a terminal opened inside this DATAFORGE V13.3 folder, run:

    .\Install_DataForge.bat 13.3

Then close the terminal, open a NEW PowerShell/Windows Terminal, and type:

    dataforge

V13.3 repairs the universal launcher and validates its PowerShell dispatcher during installation.
If the global launcher is ever damaged, run:

    .\Repair_DataForge_Launcher.bat

TRAINING SETUP RECOVERY
-----------------------
V13.3 never calls an empty `pip install`. QLoRA installs CUDA-capable PyTorch separately,
verifies CUDA in a fresh Python process, re-checks all dependencies, and continues to the
hardware/training setup only after the required stack is present.
