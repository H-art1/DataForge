DATAFORGE H1 V11 IMAGE API

No extra Python package is required for the image generator. V11 uses the Python standard library to call the OpenAI Images API.

Set OPENAI_API_KEY in the environment or use DATAFORGE [9] Image API Key Setup.
