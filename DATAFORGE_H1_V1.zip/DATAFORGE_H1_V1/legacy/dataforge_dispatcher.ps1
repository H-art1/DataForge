param(
    [Parameter(ValueFromRemainingArguments = $true)]
    [string[]] $AppArgs
)

$ErrorActionPreference = "Stop"
$bin = Split-Path -Parent $MyInvocation.MyCommand.Path
$versionFile = Join-Path $bin "dataforge_versions.txt"
$rootFile = Join-Path $bin "dataforge_roots.txt"

function Normalize-PathText([string]$p) {
    try { return [IO.Path]::GetFullPath($p).TrimEnd('\') } catch { return $p.TrimEnd('\') }
}

function Get-VersionFromFolder([string]$path) {
    $name = Split-Path -Leaf $path
    if ($name -match '_v(.+)$') { return ($Matches[1] -replace '_','.') }
    return 'unknown'
}

function Get-VersionKey([string]$version) {
    $clean = [string]$version
    $clean = $clean.Trim()
    $clean = $clean -replace '^[Vv]', ''
    $clean = $clean -replace '_', '.'
    try { return [version]$clean } catch { return [version]'0.0' }
}

$items = @()
$seenPaths = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)

function Add-Install([string]$version, [string]$path, [string]$source) {
    if ([string]::IsNullOrWhiteSpace($path)) { return }
    $path = Normalize-PathText $path
    $script = Join-Path $path 'datasetmaker.py'
    if (-not (Test-Path -LiteralPath $script -PathType Leaf)) { return }
    if ($script:seenPaths.Contains($path)) { return }
    if ([string]::IsNullOrWhiteSpace($version) -or $version -eq 'unknown') { $version = Get-VersionFromFolder $path }
    [void]$script:seenPaths.Add($path)
    $script:items += [pscustomobject]@{
        Version = $version
        Path = $path
        Source = $source
        VersionKey = Get-VersionKey $version
    }
}

# 1) Exact installer registrations.
if (Test-Path -LiteralPath $versionFile -PathType Leaf) {
    foreach ($line in @(Get-Content -LiteralPath $versionFile -ErrorAction SilentlyContinue)) {
        if ($line -match '^([^|]+)\|(.*)$') { Add-Install $Matches[1].Trim() $Matches[2].Trim() 'registered' }
    }
}

# 2) Future sibling versions under registered roots.
$roots = @()
if (Test-Path -LiteralPath $rootFile -PathType Leaf) {
    $roots += @(Get-Content -LiteralPath $rootFile -ErrorAction SilentlyContinue | Where-Object { $_ -and $_.Trim() })
}
# Also consider the parent of every registered install; this makes a newly
# extracted v14/v15 folder discoverable without another installer run.
foreach ($known in @($items)) {
    try {
        $parent = Split-Path -Parent $known.Path
        if ($parent) { $roots += $parent }
    } catch {}
}
$roots = @($roots | ForEach-Object { Normalize-PathText $_ } | Sort-Object -Unique)
foreach ($r in $roots) {
    if (-not (Test-Path -LiteralPath $r -PathType Container)) { continue }
    # Scan direct children and one nested level. This supports extracted ZIP
    # layouts such as Downloads\FULL_v14\DATAFORGE_H1_DatasetMaker_v14.
    $children = @(Get-ChildItem -LiteralPath $r -Directory -ErrorAction SilentlyContinue)
    foreach ($child in $children) {
        if ($child.Name -match '^DATAFORGE_H1_DatasetMaker_v.+$') {
            Add-Install (Get-VersionFromFolder $child.FullName) $child.FullName 'discovered'
            continue
        }
        $nested = @(Get-ChildItem -LiteralPath $child.FullName -Directory -ErrorAction SilentlyContinue)
        foreach ($n in $nested) {
            if ($n.Name -match '^DATAFORGE_H1_DatasetMaker_v.+$') {
                Add-Install (Get-VersionFromFolder $n.FullName) $n.FullName 'discovered'
            }
        }
    }
}

# 3) Legacy version launchers. Validate their target before adding them.
Get-ChildItem -LiteralPath $bin -Filter 'dataforge_v*.cmd' -File -ErrorAction SilentlyContinue | ForEach-Object {
    $text = Get-Content -LiteralPath $_.FullName -Raw -ErrorAction SilentlyContinue
    if ($text -match '(?im)^cd /d "([^"]+)"') {
        Add-Install (Get-VersionFromFolder $Matches[1]) $Matches[1] 'legacy'
    }
}

$items = @($items | Sort-Object VersionKey, Path)

if ($items.Count -eq 0) {
    Write-Host 'DATAFORGE could not find an installed version.' -ForegroundColor Yellow
    Write-Host 'Run Install_DataForge.bat from a DATAFORGE version folder first.'
    exit 1
}

$requested = if ($AppArgs) { [string]$AppArgs[0] } else { '' }
$selected = $null
if ($requested) {
    $clean = $requested.Trim() -replace '^[Vv]', '' -replace '_','.'
    $idx = 0
    if ([int]::TryParse($clean,[ref]$idx) -and $idx -ge 1 -and $idx -le $items.Count) {
        $selected = $items[$idx-1]
    }
    if (-not $selected) {
        $selected = @($items | Where-Object { $_.Version -ieq $clean } | Select-Object -First 1)[0]
    }
}

if (-not $selected -and $items.Count -eq 1) { $selected = $items[0] }

if (-not $selected) {
    Write-Host ''
    Write-Host '================================================' -ForegroundColor Cyan
    Write-Host '         DATAFORGE VERSION SELECTOR' -ForegroundColor Cyan
    Write-Host '================================================' -ForegroundColor Cyan
    Write-Host ''
    Write-Host ("Detected {0} DATAFORGE versions:" -f $items.Count)
    for ($i=0; $i -lt $items.Count; $i++) {
        $marker = ''
        try {
            $here = Normalize-PathText (Get-Location).Path
            if ($here -ieq $items[$i].Path) { $marker = '  <current folder>' }
        } catch {}
        Write-Host ("[{0}] V{1}  {2}{3}" -f ($i+1), $items[$i].Version, $items[$i].Path, $marker)
    }
    Write-Host ''
    do {
        $choice = Read-Host 'Which version do you want to launch? (number or version)'
        $clean = $choice.Trim() -replace '^[Vv]', '' -replace '_','.'
        $candidate = $null
        $idx = 0
        if ([int]::TryParse($clean,[ref]$idx) -and $idx -ge 1 -and $idx -le $items.Count) { $candidate = $items[$idx-1] }
        if (-not $candidate) { $candidate = @($items | Where-Object { $_.Version -ieq $clean } | Select-Object -First 1)[0] }
        if ($candidate) { $selected = $candidate; break }
        Write-Host 'Invalid version selection. Enter a listed number or version such as V13.2.' -ForegroundColor Yellow
    } while ($true)
}

Set-Location -LiteralPath $selected.Path
$python = (Get-Command python -ErrorAction SilentlyContinue).Source
if (-not $python) { $python = (Get-Command py -ErrorAction SilentlyContinue).Source }
if (-not $python) {
    Write-Host 'DATAFORGE could not find Python. Install Python 3 and try again.' -ForegroundColor Red
    exit 1
}

Write-Host ("Launching DATAFORGE V{0}..." -f $selected.Version) -ForegroundColor Green
& $python 'datasetmaker.py'
exit $LASTEXITCODE
