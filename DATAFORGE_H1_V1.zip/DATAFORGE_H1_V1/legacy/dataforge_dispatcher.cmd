@echo off
setlocal
set "DISPATCHER=%~dp0dataforge_dispatcher.ps1"
if not exist "%DISPATCHER%" (
    echo DATAFORGE launcher error: dispatcher script is missing.
    echo Re-run Install_DataForge.bat from a DATAFORGE version folder.
    endlocal & exit /b 1
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%DISPATCHER%" %*
set "RC=%ERRORLEVEL%"
endlocal & exit /b %RC%
