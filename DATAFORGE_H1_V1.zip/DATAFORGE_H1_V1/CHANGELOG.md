# Changelog — DATAFORGE H1

## V1.0.0 — DATAFORGE H1 V1

### Product and interface
- Replaced the terminal-first home workflow with a local browser application and a responsive macOS-inspired desktop shell.
- Added Dashboard, Dataset Library, Dataset Explorer, Behaviour Datasets, Knowledge Datasets, Dataset Generator, Dataset Editor, Data Validator, Training Studio, Export Center, Import Center, Analytics, Settings, and About.
- Added persisted dark/light themes and the editable default AI display identity **My AI**.
- Kept identity configuration explicitly separate from the underlying model and model weights.

### Data library and quality
- Retained the existing 600 behaviour and 700 knowledge dataset file inventory as the active V1 library.
- Rewrote behaviour prompts to be unique across all 3,000 examples, with variant-specific names and descriptions; rewrote 500 template-derived knowledge collections with topic-specific definitions, examples, comparisons, and limitations.
- Preserved 200 existing topic-specific knowledge files.
- Produced a metadata manifest with dataset IDs, names, categories, descriptions, record counts, JSONL format, dates, versions, tags, and quality status.
- Full release validation checked 1,300 datasets / 6,500 records: zero schema errors, zero validation warnings, zero repeated user prompts, and zero cross-dataset exact duplicates.
- Archived the original V13.3 dataset library, templates, and base dataset in `archive/v13_3_dataset_library.zip`.

### Dataset workflows
- Added manifest-backed search/filter/pagination, paginated exploration, and 50-record paginated editing.
- Added atomic versioned saves, full-file backups, delete backups, merge, split, validation, bulk export, and JSONL/JSON/CSV import/export.
- Added a local curated generator and optional OpenAI-compatible provider integration through environment-based API keys.
- Added on-disk analytics for actual dataset counts, records, categories, storage, quality, formats, and recently modified files.

### Training
- Preserved the existing Transformers/PEFT engine as the actual model-training implementation.
- Added saved training configuration, dataset selection, train/validation split, bounded hardware parameters, dependency checks, QLoRA CUDA checks, preflight, threaded progress, logs, and failure reporting.
- Added hold-out evaluation at the end of training and stored evaluation metrics in the run configuration.
- Kept preparation, configuration, actual training, and model evaluation clearly distinguished.
- Prevented full fine-tuning from requiring PEFT imports and avoided overwriting a prior output run directory.

### Reliability and engineering
- Added separated backend/frontend/schemas/tests/docs/scripts/configuration structure.
- Added streaming JSONL iteration for record searches and validation, atomic file replacement, and safer path checks.
- Added 17 automated tests covering library integrity, CRUD, pagination, imports/exports, identity, generator constraints, training configuration, and HTTP routes.
- Added Windows and Unix launch/install scripts and updated this README.

## V13.3 — Previous release
- Terminal-driven DATAFORGE H1 dataset maker with 600 behaviour and 700 knowledge dataset files.
- Included an existing training engine, batch launchers, templates, and historical data library.
- The original CLI and its README are retained under `legacy/`, while the pre-upgrade library is stored in the archive ZIP.
