@echo off
setlocal
cd /d "%~dp0"
title Install DATAFORGE H1 V1
where py >nul 2>&1
if errorlevel 1 (
  where python >nul 2>&1
  if errorlevel 1 (
    echo Python 3.10 or later is required. Install from https://www.python.org/downloads/.
    pause
    exit /b 1
  )
  set "PYTHON_CMD=python"
) else (
  set "PYTHON_CMD=py -3"
)
%PYTHON_CMD% -c "import sys; assert sys.version_info >= (3,10), 'Python 3.10+'; print('Python',sys.version.split()[0],'verified.')"
if errorlevel 1 (
  echo Install Python 3.10 or later and run this installer again.
  pause
  exit /b 1
)
%PYTHON_CMD% -m compileall -q datasetmaker.py backend training_engine.py
if errorlevel 1 (
  echo DATAFORGE files did not pass Python compilation.
  pause
  exit /b 1
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$root=(Resolve-Path '.').Path; $desktop=[Environment]::GetFolderPath('Desktop'); $shell=New-Object -ComObject WScript.Shell; $shortcut=$shell.CreateShortcut((Join-Path $desktop 'DATAFORGE H1 V1.lnk')); $shortcut.TargetPath=(Join-Path $root 'run.bat'); $shortcut.WorkingDirectory=$root; $shortcut.Description='Launch DATAFORGE H1 V1 local dataset workspace'; $shortcut.Save()"
if errorlevel 1 echo Desktop shortcut could not be created; use run.bat directly.
echo.
echo DATAFORGE H1 V1 setup complete.
echo Launch with run.bat or the Desktop shortcut.
echo The core application uses only Python's standard library.
echo Optional model-training dependencies are documented in README.md.
pause
endlocal
