@echo off
setlocal
cd /d "%~dp0"
title DATAFORGE H1 V1
where py >nul 2>&1
if not errorlevel 1 (
  py -3 -c "import sys; assert sys.version_info >= (3,10), 'Python 3.10+ required'"
  if errorlevel 1 (echo Python 3.10 or later is required.& pause & exit /b 1)
  py -3 datasetmaker.py %*
) else (
  where python >nul 2>&1
  if errorlevel 1 (
    echo Python 3.10 or later was not found. Install Python and add it to PATH.
    pause
    exit /b 1
  )
  python -c "import sys; assert sys.version_info >= (3,10), 'Python 3.10+ required'"
  if errorlevel 1 (echo Python 3.10 or later is required.& pause & exit /b 1)
  python datasetmaker.py %*
)
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" echo DATAFORGE stopped with exit code %RC%.
endlocal & exit /b %RC%
