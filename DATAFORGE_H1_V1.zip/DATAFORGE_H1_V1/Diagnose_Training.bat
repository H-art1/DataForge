@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
title DATAFORGE H1 V1 - Training Diagnostic
echo DATAFORGE H1 V1 - TRAINING DIAGNOSTIC
echo.
where py >nul 2>&1
if not errorlevel 1 (py -3 --version) else (python --version)
if errorlevel 1 exit /b 1
py -3 -c "import importlib.util; names=['torch','transformers','peft','accelerate','datasets','safetensors','bitsandbytes']; [print(n+': '+('available' if importlib.util.find_spec(n) else 'not installed')) for n in names]" 2>nul
if errorlevel 1 python -c "import importlib.util; names=['torch','transformers','peft','accelerate','datasets','safetensors','bitsandbytes']; [print(n+': '+('available' if importlib.util.find_spec(n) else 'not installed')) for n in names]"
where nvidia-smi >nul 2>&1
if errorlevel 1 (echo nvidia-smi: not found) else (echo nvidia-smi: available)
echo.
echo This diagnostic does not install or modify anything.
pause
endlocal
