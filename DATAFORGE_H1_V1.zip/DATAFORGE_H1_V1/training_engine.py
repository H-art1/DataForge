from __future__ import annotations

from pathlib import Path
import importlib.util
import inspect
import json
import os
import re
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
TRAINING_DIR = ROOT / 'training_runs'
TRAINING_DIR.mkdir(exist_ok=True)
APP_VERSION = 'V1'

PACKAGE_FOR = {
    'PyTorch': ['torch'],
    'Transformers': ['transformers'],
    'PEFT': ['peft'],
    'Accelerate': ['accelerate'],
    'Datasets': ['datasets'],
    'Safetensors': ['safetensors'],
    'bitsandbytes (QLoRA)': ['bitsandbytes'],
}

OLLAMA_COMMON = [
    Path(os.environ.get('LOCALAPPDATA', '')) / 'Programs' / 'Ollama' / 'ollama.exe',
    Path(os.environ.get('ProgramFiles', '')) / 'Ollama' / 'ollama.exe',
]
_OLLAMA_EXE = None


def which(name: str) -> str | None:
    return shutil.which(name)


def find_ollama() -> str | None:
    global _OLLAMA_EXE
    if _OLLAMA_EXE and Path(_OLLAMA_EXE).exists():
        return _OLLAMA_EXE
    hit = shutil.which('ollama')
    if hit:
        _OLLAMA_EXE = hit
        return hit
    for candidate in OLLAMA_COMMON:
        try:
            if candidate.is_file():
                _OLLAMA_EXE = str(candidate)
                return _OLLAMA_EXE
        except OSError:
            pass
    return None


def run_cmd(cmd, timeout=60):
    """Run a bounded subprocess without letting a hung helper freeze DATAFORGE."""
    kwargs = dict(capture_output=True, text=True, timeout=timeout, check=False, stdin=subprocess.DEVNULL)
    if os.name == 'nt':
        kwargs['creationflags'] = getattr(subprocess, 'CREATE_NO_WINDOW', 0)
    try:
        return subprocess.run(cmd, **kwargs)
    except subprocess.TimeoutExpired:
        return subprocess.CompletedProcess(cmd, 124, '', f'timeout after {timeout}s')
    except OSError as exc:
        return subprocess.CompletedProcess(cmd, 1, '', str(exc))


def has_module(name: str) -> bool:
    try:
        return importlib.util.find_spec(name) is not None
    except (ImportError, ValueError):
        return False


def cuda_status():
    """Probe PyTorch CUDA in a fresh Python process.

    This is deliberate: DATAFORGE may install/upgrade torch during the same
    session. A fresh interpreter prevents a previously imported CPU-only torch
    module from making the post-install verification appear to fail.
    """
    code = (
        'import json\n'
        'try:\n'
        ' import torch\n'
        ' print(json.dumps({"ok": bool(torch.cuda.is_available()), "cuda": str(getattr(torch.version, "cuda", "") or ""), "version": str(getattr(torch, "__version__", ""))}))\n'
        'except Exception as e:\n'
        ' print(json.dumps({"ok": False, "error": str(e)}))'
    )
    p = run_cmd([sys.executable, '-c', code], timeout=45)
    try:
        data = json.loads((p.stdout or '').strip().splitlines()[-1])
    except Exception:
        return False, ''
    return bool(data.get('ok')), str(data.get('cuda') or '')


def dep_status(method: str, use_ollama: bool = False):
    status = {
        'PyTorch': has_module('torch'),
        'Transformers': has_module('transformers'),
        'PEFT': has_module('peft'),
        'Accelerate': has_module('accelerate'),
        'Datasets': has_module('datasets'),
        'Safetensors': has_module('safetensors'),
    }
    if method == 'qlora':
        status['bitsandbytes (QLoRA)'] = has_module('bitsandbytes')
    cuda, torch_cuda = cuda_status()
    status['CUDA PyTorch'] = cuda
    if use_ollama:
        status['Ollama executable'] = find_ollama() is not None
    return status, torch_cuda


def nvidia_info():
    """Best-effort NVIDIA detection. Missing nvidia-smi metadata must not block CUDA setup."""
    p = run_cmd(['nvidia-smi', '--query-gpu=name,memory.total', '--format=csv,noheader,nounits'], timeout=5)
    lines = (p.stdout or '').strip().splitlines()
    name = ''
    memory_gb = 0.0
    if lines:
        try:
            name, mem = [x.strip() for x in lines[0].split(',', 1)]
            memory_gb = float(mem) / 1024
        except (ValueError, IndexError):
            name = ''
            memory_gb = 0.0
    ver = ''
    raw = run_cmd(['nvidia-smi'], timeout=5)
    m = re.search(r'CUDA Version:\s*([0-9.]+)', raw.stdout or '')
    if m:
        ver = m.group(1)

    # If nvidia-smi is unavailable or incomplete, use Windows device enumeration
    # as a secondary signal. This is only a presence check; PyTorch itself is the
    # final authority for CUDA availability.
    if not name and os.name == 'nt':
        probe = run_cmd([
            'powershell.exe', '-NoProfile', '-ExecutionPolicy', 'Bypass',
            '-Command',
            "Get-CimInstance Win32_VideoController | Select-Object -ExpandProperty Name"
        ], timeout=8)
        for line in (probe.stdout or '').splitlines():
            if 'NVIDIA' in line.upper():
                name = line.strip()
                break
    return name, memory_gb, ver


def hardware():
    ram = 8.0
    cpu = os.cpu_count() or 1
    try:
        import psutil
        ram = psutil.virtual_memory().total / 1024 ** 3
    except Exception:
        pass

    cuda, torch_cuda = cuda_status()
    name = ''
    vram = 0.0
    driver_cuda = ''
    try:
        import torch
        if cuda:
            name = torch.cuda.get_device_name(0)
            vram = torch.cuda.get_device_properties(0).total_memory / 1024 ** 3
    except Exception:
        pass

    detected_name, detected_vram, driver_cuda = nvidia_info()
    if not name and detected_name:
        name = detected_name
        vram = detected_vram
    # IMPORTANT: CUDA availability is determined by PyTorch, not merely by the
    # presence of an NVIDIA GPU. This prevents unsafe GPU caps with CPU-only torch.

    if cuda and vram >= 24:
        caps = (5, 1000, 8, 8, 4096, 32)
    elif cuda and vram >= 16:
        caps = (4, 750, 4, 16, 4096, 16)
    elif cuda and vram >= 8:
        caps = (3, 500, 2, 16, 2048, 16)
    elif cuda:
        caps = (2, 250, 1, 32, 1024, 8)
    else:
        caps = (1, 100, 1, 4, 1024, 4)

    if ram < 16:
        caps = (min(caps[0], 2), min(caps[1], 250), caps[2], min(caps[3], 8), min(caps[4], 2048), min(caps[5], 16))
    if ram < 8:
        caps = (1, 100, 1, 4, 1024, 4)

    return {
        'cpu': cpu,
        'ram': round(ram, 1),
        'cuda': cuda,
        'gpu_present': bool(name),
        'torch_cuda_version': torch_cuda,
        'driver_cuda_version': driver_cuda,
        'gpu': name or 'CPU only',
        'vram': round(vram, 1),
        'epochs': caps[0],
        'steps': caps[1],
        'batch': caps[2],
        'grad': caps[3],
        'length': caps[4],
        'rank': caps[5],
    }


def run_live_cmd(cmd, timeout=1800):
    """Run a long-lived command with live stdout/stderr and a hard timeout."""
    try:
        kwargs = {
            'stdin': subprocess.DEVNULL,
            'text': True,
            'check': False,
        }
        if os.name == 'nt':
            # Keep the child attached to the current Windows Terminal so pip's
            # progress bar and errors remain visible. Do not use CREATE_NO_WINDOW.
            kwargs['creationflags'] = 0
        proc = subprocess.Popen(cmd, **kwargs)
    except OSError as exc:
        return subprocess.CompletedProcess(cmd, 1, '', str(exc))

    started = time.monotonic()
    while True:
        rc = proc.poll()
        if rc is not None:
            return subprocess.CompletedProcess(cmd, rc, '', '')
        if time.monotonic() - started >= timeout:
            try:
                proc.terminate()
                proc.wait(timeout=8)
            except Exception:
                try:
                    proc.kill()
                except Exception:
                    pass
            return subprocess.CompletedProcess(cmd, 124, '', f'timeout after {timeout}s')
        time.sleep(0.5)


def pip_install(packages, label='packages', timeout=900):
    """Install an explicit, non-empty package list with visible pip progress."""
    packages = list(dict.fromkeys(str(x).strip() for x in packages if str(x).strip()))
    if not packages:
        print(f'No {label} were selected; nothing to install.')
        return True
    print('\nInstalling:', ', '.join(packages))
    p = run_live_cmd([
        sys.executable, '-m', 'pip', 'install', '--upgrade', '--disable-pip-version-check',
        '--progress-bar', 'on', *packages
    ], timeout=timeout)
    if p.returncode != 0:
        print('\nPIP INSTALL FAILED')
        print(p.stderr or '')
        return False
    return True


def cuda_pytorch_index_candidates():
    """Return known official PyTorch CUDA wheel indexes without trusting driver text parsing.

    V13.1 incorrectly stopped when nvidia-smi did not expose a parseable
    ``CUDA Version`` string. PyTorch publishes CUDA-specific wheel indexes,
    and pip can test whether a wheel exists for the user's Python/Windows
    combination. V13.3 therefore tries known official indexes in descending
    preference and verifies the resulting torch build afterward.
    """
    override = os.environ.get('DATAFORGE_TORCH_INDEX_URL', '').strip()
    # Prefer cu126 for broad driver compatibility, then try newer/older
    # official indexes if the wheel cannot be installed or verified.
    tags = ['cu126', 'cu128', 'cu124', 'cu121', 'cu118']
    urls = [override] if override else []
    for tag in tags:
        url = f'https://download.pytorch.org/whl/{tag}'
        if url not in urls:
            urls.append(url)
    return urls


def fresh_module_status(names):
    """Check module imports in a separate interpreter."""
    unique = list(dict.fromkeys(names))
    if not unique:
        return {}
    payload = json.dumps(unique)
    code = (
        'import importlib.util,json\n'
        f'names=json.loads({payload!r})\n'
        'out={}\n'
        'for n in names:\n'
        ' try:\n'
        '  out[n]=importlib.util.find_spec(n) is not None\n'
        ' except Exception:\n'
        '  out[n]=False\n'
        'print(json.dumps(out))'
    )
    p = run_cmd([sys.executable, '-c', code], timeout=30)
    try:
        return json.loads((p.stdout or '').strip().splitlines()[-1])
    except Exception:
        return {n: False for n in unique}


def install_cuda_pytorch():
    gpu_name, _, _ = nvidia_info()
    if not gpu_name:
        print('No NVIDIA GPU was detected by nvidia-smi or Windows device enumeration.')
        print('QLoRA requires an NVIDIA CUDA-capable GPU in this DATAFORGE build.')
        return False
    urls = cuda_pytorch_index_candidates()
    print('NVIDIA GPU detected:', gpu_name)
    print('DATAFORGE will test official PyTorch CUDA wheel indexes and verify the result.')

    for url in urls:
        print(f'\nTrying CUDA-capable PyTorch from: {url}')
        print('Downloading/installing PyTorch with LIVE progress. This package is large; DATAFORGE will not appear frozen.')
        p = run_live_cmd([
            sys.executable, '-m', 'pip', 'install', '--upgrade', '--force-reinstall',
            '--no-cache-dir', '--disable-pip-version-check', '--progress-bar', 'on',
            '--only-binary', ':all:', 'torch',
            '--index-url', url, '--extra-index-url', 'https://pypi.org/simple'
        ], timeout=1800)
        if p.returncode != 0:
            print('That CUDA wheel install failed or has no compatible wheel for this Python/platform.')
            if p.stderr:
                print(p.stderr[-2200:])
            if p.returncode == 124:
                print('The PyTorch download/install timed out after 30 minutes.')
            continue
        ok, version = cuda_status()
        if ok:
            print(f'CUDA PyTorch verified in a fresh interpreter (CUDA runtime {version or "detected"}).')
            return True
        print('Torch installed, but CUDA is still unavailable. Trying the next official wheel index.')

    print('\nCUDA-capable PyTorch could not be verified after all supported wheel attempts.')
    print('Nothing was trained.')
    print('You can manually set DATAFORGE_TORCH_INDEX_URL to an official PyTorch CUDA wheel index and retry.')
    return False


def install_ollama():
    if find_ollama():
        return True
    winget = which('winget')
    if winget:
        print('Installing Ollama with winget...')
        p = run_cmd([winget, 'install', '--id', 'Ollama.Ollama', '-e', '--accept-package-agreements', '--accept-source-agreements'], timeout=900)
        if p.returncode == 0:
            global _OLLAMA_EXE
            _OLLAMA_EXE = None
            if find_ollama():
                return True
    print('DATAFORGE could not automatically locate Ollama after installation.')
    print('Install Ollama from its official Windows installer, then reopen DATAFORGE.')
    return False


def caps_prompt(hw):
    print('\nHARDWARE PROFILE')
    print(f"CPU {hw['cpu']} threads | RAM {hw['ram']} GB | GPU {hw['gpu']} | VRAM {hw['vram']} GB | CUDA {'YES' if hw['cuda'] else 'NO'}")
    print(f"Hard caps: epochs={hw['epochs']}, steps/epoch={hw['steps']}, batch={hw['batch']}, grad_accum={hw['grad']}, max_seq={hw['length']}, LoRA rank={hw['rank']}")

    def geti(label, maxv, default):
        while True:
            r = input(f'{label} (max {maxv}) [{default}]: ').strip()
            if not r:
                return default
            try:
                v = int(r)
                if 1 <= v <= maxv:
                    return v
            except ValueError:
                pass
            print('Value is invalid or exceeds the DATAFORGE hardware cap.')

    epochs = geti('Epochs', hw['epochs'], hw['epochs'])
    steps = geti('Steps per epoch', hw['steps'], hw['steps'])
    batch = geti('Batch size', hw['batch'], hw['batch'])
    grad = geti('Gradient accumulation', hw['grad'], hw['grad'])
    length = geti('Max sequence length', hw['length'], hw['length'])
    rank = geti('LoRA rank', hw['rank'], hw['rank'])
    while True:
        r = input('Learning rate (max 0.0003) [0.0002]: ').strip() or '0.0002'
        try:
            lr = float(r)
            if 1e-7 <= lr <= 3e-4:
                break
        except ValueError:
            pass
        print('Learning rate must be between 1e-7 and 3e-4.')
    return {'epochs': epochs, 'steps': steps, 'batch': batch, 'grad': grad, 'length': length, 'rank': rank, 'alpha': max(rank * 2, rank), 'lr': lr}


def ollama_list(timeout=10):
    exe = find_ollama()
    if not exe:
        return []
    p = run_cmd([exe, 'list'], timeout=timeout)
    if p.returncode != 0:
        return []
    names = []
    seen = set()
    for line in (p.stdout or '').splitlines():
        line = line.strip()
        if not line or line.upper().startswith('NAME '):
            continue
        name = line.split()[0]
        if name and name.lower() not in seen:
            names.append(name)
            seen.add(name.lower())
    return names


def ollama_show(model, timeout=15):
    exe = find_ollama()
    if not exe:
        return None, 'Ollama executable not found.'
    p = run_cmd([exe, 'show', '--modelfile', model], timeout=timeout)
    if p.returncode != 0:
        return None, (p.stderr or p.stdout or 'Ollama show failed.').strip()
    return p.stdout, ''


def load_model_ref(kind, ref):
    if kind != 'ollama':
        return ref
    models = ollama_list()
    if not models:
        print('\nERROR: Ollama did not return a usable local model list.')
        print('Run `ollama list` in another terminal to verify the service and model names.')
        return None
    exact = next((x for x in models if x.lower() == ref.lower()), None)
    if not exact:
        print(f'\nERROR: Ollama model "{ref}" was not found.')
        print('Available local models:')
        for name in models[:30]:
            print(' -', name)
        return None
    modelfile, err = ollama_show(exact)
    if err:
        print('\nERROR: Ollama model inspection failed:')
        print(err[:2000])
        return None
    base = ''
    for line in (modelfile or '').splitlines():
        if line.upper().startswith('FROM '):
            base = line.split(None, 1)[1].strip()
            break
    if base and Path(base).is_dir() and list(Path(base).glob('*.safetensors')):
        return base
    print(f'\nOllama model selected: {exact}')
    if base:
        print('Ollama FROM:', base)
    print('DATAFORGE training uses Transformers/PEFT. A local Ollama model may be an inference package such as GGUF rather than a trainable Transformers checkpoint.')
    alt = input('Corresponding Hugging Face model ID or local Safetensors checkpoint folder (blank cancels): ').strip()
    return alt or None


def format_row(tok, row):
    try:
        return tok.apply_chat_template(row['messages'], tokenize=False, add_generation_prompt=False)
    except Exception:
        return '\n'.join(f"{m.get('role', 'user').upper()}: {m.get('content', '')}" for m in row['messages'])


def load_training_rows(files):
    rows = []
    seen = set()
    bad = 0
    for f in files:
        try:
            for line in Path(f).read_text(encoding='utf-8').splitlines():
                if not line.strip():
                    continue
                try:
                    x = json.loads(line)
                except json.JSONDecodeError:
                    bad += 1
                    continue
                msgs = x.get('messages')
                if not isinstance(msgs, list) or len(msgs) < 2:
                    bad += 1
                    continue
                if not all(isinstance(m, dict) and isinstance(m.get('content'), str) for m in msgs):
                    bad += 1
                    continue
                key = json.dumps(msgs, ensure_ascii=False, sort_keys=True)
                if key not in seen:
                    seen.add(key)
                    rows.append({'messages': msgs})
        except OSError:
            bad += 1
    return rows, bad


def supported_preexisting(ref):
    low = ref.lower()
    return any(marker in low for marker in ('gemma', 'gpt-oss', 'dolphin'))


def train(model_ref, files, method, out_name, settings, hw, progress_callback=None):
    import torch
    from datasets import Dataset
    from transformers import AutoTokenizer, AutoModelForCausalLM, TrainingArguments, Trainer, DataCollatorForLanguageModeling
    if method in {'lora', 'qlora'}:
        from peft import LoraConfig, get_peft_model
    if method == 'qlora':
        from peft import prepare_model_for_kbit_training
        from transformers import BitsAndBytesConfig

    rows, bad = load_training_rows(files)
    if bad:
        print(f'Ignored {bad:,} malformed training records.')
    if not rows:
        raise RuntimeError('No valid training examples were selected.')

    safe = re.sub(r'[^A-Za-z0-9_.-]+', '_', out_name).strip('._') or time.strftime('run_%Y%m%d_%H%M%S')
    out = TRAINING_DIR / safe
    if out.exists():
        out = TRAINING_DIR / f"{safe}_{time.strftime('%Y%m%d_%H%M%S')}_{os.getpid()}"
    out.mkdir(parents=True, exist_ok=False)

    tokenizer = AutoTokenizer.from_pretrained(model_ref, use_fast=True, trust_remote_code=False)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token or tokenizer.unk_token

    ds = Dataset.from_dict({'text': [format_row(tokenizer, r) for r in rows]})
    validation_split = float(settings.get('validation_split', 0.0) or 0.0)
    eval_ds = None
    if validation_split > 0:
        if not 0 < validation_split < 0.5:
            raise ValueError('Validation split must be between 0 and 0.5.')
        if len(ds) < 2:
            raise ValueError('At least two records are required for a train/validation split.')
        split_seed = int(settings.get('seed', 42))
        partition = ds.train_test_split(test_size=validation_split, seed=split_seed, shuffle=True)
        ds, eval_ds = partition['train'], partition['test']
    ds = ds.map(lambda b: tokenizer(b['text'], truncation=True, max_length=settings['length']), batched=True, remove_columns=['text'])
    if eval_ds is not None:
        eval_ds = eval_ds.map(lambda b: tokenizer(b['text'], truncation=True, max_length=settings['length']), batched=True, remove_columns=['text'])
    if progress_callback:
        progress_callback({'stage':'Dataset tokenized','progress':10,'training_records':len(ds),'validation_records':len(eval_ds) if eval_ds is not None else 0})

    load_kwargs = {'trust_remote_code': False}
    if method == 'qlora':
        use_bf16 = False
        try:
            use_bf16 = bool(hw['cuda'] and torch.cuda.is_bf16_supported())
        except Exception:
            use_bf16 = bool(hw['cuda'] and hw['vram'] >= 16)
        load_kwargs['quantization_config'] = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_quant_type='nf4',
            bnb_4bit_use_double_quant=True,
            bnb_4bit_compute_dtype=torch.bfloat16 if use_bf16 else torch.float16,
        )
        load_kwargs['device_map'] = 'auto'

    model = AutoModelForCausalLM.from_pretrained(model_ref, **load_kwargs)
    if hasattr(model.config, 'use_cache'):
        model.config.use_cache = False

    if method in {'lora', 'qlora'}:
        if method == 'qlora':
            model = prepare_model_for_kbit_training(model)
        leaves = {n.rsplit('.', 1)[-1] for n, _ in model.named_modules()}
        targets = [x for x in ('q_proj','k_proj','v_proj','o_proj','gate_proj','up_proj','down_proj') if x in leaves]
        if not targets:
            raise RuntimeError('No common attention/MLP projection targets were found for LoRA on this model.')
        model = get_peft_model(model, LoraConfig(
            r=settings['rank'],
            lora_alpha=settings['alpha'],
            lora_dropout=0.05,
            target_modules=targets,
            task_type='CAUSAL_LM',
            bias='none',
        ))
        try:
            model.print_trainable_parameters()
        except Exception:
            pass

    bf16 = bool(hw['cuda'] and hw['vram'] >= 16)
    fp16 = bool(hw['cuda'] and not bf16)
    save_steps = max(10, min(100, settings['steps']))
    ta_kwargs = dict(
        output_dir=str(out),
        num_train_epochs=settings['epochs'],
        max_steps=settings['epochs'] * settings['steps'],
        per_device_train_batch_size=settings['batch'],
        gradient_accumulation_steps=settings['grad'],
        learning_rate=settings['lr'],
        logging_steps=10,
        save_strategy='steps',
        save_steps=save_steps,
        save_total_limit=2,
        fp16=fp16,
        bf16=bf16,
        gradient_checkpointing=bool(hw['cuda']),
        dataloader_num_workers=0,
        report_to='none',
        remove_unused_columns=False,
        optim='adamw_torch',
    )

    trainer_args = inspect.signature(TrainingArguments.__init__).parameters
    if eval_ds is not None:
        if 'eval_strategy' in trainer_args:
            ta_kwargs['eval_strategy'] = 'steps'
        elif 'evaluation_strategy' in trainer_args:
            ta_kwargs['evaluation_strategy'] = 'steps'
        ta_kwargs['eval_steps'] = save_steps
    trainer_init = inspect.signature(Trainer.__init__).parameters
    trainer_kwargs = {
        'model': model,
        'args': TrainingArguments(**ta_kwargs),
        'train_dataset': ds,
        'data_collator': DataCollatorForLanguageModeling(tokenizer, mlm=False),
    }
    if eval_ds is not None:
        trainer_kwargs['eval_dataset'] = eval_ds
    if progress_callback:
        try:
            from transformers import TrainerCallback
            class _DataForgeProgress(TrainerCallback):
                def on_step_end(self, args, state, control, **kwargs):
                    total = max(1, int(getattr(state, 'max_steps', 1) or 1))
                    done = int(getattr(state, 'global_step', 0) or 0)
                    progress_callback({'stage':'Training model','progress':min(95, 10 + int(85*done/total)), 'step':done, 'total_steps':total})
                def on_log(self, args, state, control, logs=None, **kwargs):
                    if logs:
                        progress_callback({'stage':'Training metrics','progress':min(95, 10 + int(85*int(getattr(state,'global_step',0) or 0)/max(1,int(getattr(state,'max_steps',1) or 1)))), 'metrics':logs})
            trainer_kwargs['callbacks'] = [_DataForgeProgress()]
        except Exception:
            pass
    if 'processing_class' in trainer_init:
        trainer_kwargs['processing_class'] = tokenizer
    else:
        trainer_kwargs['tokenizer'] = tokenizer

    trainer = Trainer(**trainer_kwargs)
    result = trainer.train()
    evaluation_metrics = {}
    if eval_ds is not None:
        if progress_callback:
            progress_callback({'stage':'Evaluating hold-out set','progress':96})
        evaluation_metrics = trainer.evaluate(eval_dataset=eval_ds)
        if progress_callback:
            progress_callback({'stage':'Evaluation complete','progress':98,'metrics':evaluation_metrics})
    trainer.save_model(str(out / 'final'))
    tokenizer.save_pretrained(str(out / 'final'))
    config = {
        'version': APP_VERSION,
        'model': model_ref,
        'method': method,
        'examples': len(rows),
        'training_examples': len(ds),
        'validation_examples': len(eval_ds) if eval_ds is not None else 0,
        'validation_split': validation_split,
        'files': [str(Path(f)) for f in files],
        'settings': settings,
        'hardware': hw,
        'steps_completed': int(getattr(result, 'global_step', 0)),
        'evaluation_metrics': evaluation_metrics,
    }
    (out / 'training_config.json').write_text(json.dumps(config, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    return out


def dependency_install_plan(method, use_ollama, status):
    """Return explicit packages to install; never invoke an empty pip command."""
    plan = []
    if not status.get('PyTorch'):
        # For QLoRA, CUDA torch must be installed by install_cuda_pytorch().
        if method != 'qlora' or not status.get('CUDA PyTorch'):
            plan.append('torch')
    if not status.get('Transformers'):
        plan.append('transformers')
    if not status.get('PEFT'):
        plan.append('peft')
    if not status.get('Accelerate'):
        plan.append('accelerate')
    if not status.get('Datasets'):
        plan.append('datasets')
    if not status.get('Safetensors'):
        plan.append('safetensors')
    if method == 'qlora' and not status.get('bitsandbytes (QLoRA)'):
        plan.append('bitsandbytes')
    if use_ollama and not status.get('Ollama executable'):
        # Ollama is not a pip package; installation is handled separately.
        pass
    return list(dict.fromkeys(plan))


def show_requirement_check(method, use_ollama):
    status, torch_cuda = dep_status(method, use_ollama)
    print('\nREQUIREMENT CHECK')
    for k, v in status.items():
        print(f"{'OK  ' if v else 'MISS'} {k}")
    if torch_cuda:
        print(f'      PyTorch CUDA runtime: {torch_cuda}')
    return status


def ensure_training_requirements(method, use_ollama):
    """Install missing requirements and re-check them before allowing training."""
    status = show_requirement_check(method, use_ollama)

    if use_ollama and not status.get('Ollama executable'):
        answer = input('\nOllama is missing. Download/install it now? [Y/n]: ').strip().lower()
        if answer not in {'', 'y', 'yes'}:
            return None
        if not install_ollama():
            print('Ollama installation could not be verified. Training cannot continue with an Ollama source.')
            return None
        status = show_requirement_check(method, True)
        if not status.get('Ollama executable'):
            print('Ollama is still unavailable. Please start/reinstall Ollama and try again.')
            return None

    # QLoRA specifically needs CUDA-capable torch. Do that BEFORE the generic
    # package install so a CPU torch wheel is never installed first.
    if method == 'qlora' and not status.get('CUDA PyTorch'):
        if not status.get('PyTorch'):
            print('\nPyTorch is missing and QLoRA requires CUDA-capable PyTorch.')
        else:
            print('\nCUDA-capable PyTorch is missing.')
        answer = input('Install/repair CUDA-capable PyTorch now? [Y/n]: ').strip().lower()
        if answer not in {'', 'y', 'yes'}:
            return None
        if not install_cuda_pytorch():
            print('\nQLoRA cannot continue without verified CUDA-capable PyTorch.')
            retry = input('[T] Try CUDA setup again   [M] Main menu\nSelect: ').strip().lower()
            if retry == 't':
                return ensure_training_requirements(method, use_ollama)
            return None
        status = show_requirement_check(method, use_ollama)
        if not status.get('CUDA PyTorch'):
            print('\nCUDA PyTorch was installed but could not be verified. Training was not started.')
            retry = input('[T] Retry CUDA setup   [M] Main menu\nSelect: ').strip().lower()
            if retry == 't':
                return ensure_training_requirements(method, use_ollama)
            return None

    packages = dependency_install_plan(method, use_ollama, status)
    if packages:
        print('\nMISSING REQUIREMENTS:')
        for name in packages:
            print(' -', name)
        answer = input('Download/install the missing requirements? [Y/n]: ').strip().lower()
        if answer not in {'', 'y', 'yes'}:
            return None
        if not pip_install(packages, 'training packages'):
            return None
        # Fresh-process verification means a just-installed package is visible
        # immediately; no stale module cache can falsely block continuation.
        status = show_requirement_check(method, use_ollama)
        remaining = [k for k, v in status.items() if not v]
        if method != 'qlora':
            remaining = [x for x in remaining if x != 'CUDA PyTorch']
        if remaining:
            print('\nRequirements are still incomplete:')
            for name in remaining:
                print(' -', name)
            return None

    # Final sanity pass. Re-probe CUDA after all installs and refresh the
    # hardware profile only after dependency installation is complete.
    status = show_requirement_check(method, use_ollama)
    if method == 'qlora' and not status.get('CUDA PyTorch'):
        print('\nQLoRA cannot continue: CUDA-capable PyTorch is not verified.')
        return None
    return status


def wizard(choose_files):
    print('\nTRAIN MODEL — DATAFORGE V13.3')
    print('[1] LoRA\n[2] QLoRA\n[3] Full fine-tune\n[4] Back')
    raw_method = input('Method: ').strip()
    method = {'1': 'lora', '2': 'qlora', '3': 'full'}.get(raw_method)
    if not method:
        return

    print('\nMODEL SOURCE')
    print('[1] Pre-existing\n[2] Custom HF/local\n[3] Ollama\n[4] Back')
    source = input('Source: ').strip()
    if source == '4' or source not in {'1', '2', '3'}:
        return

    use_ollama = source == '3'
    if source == '1':
        print('Supported pre-existing families: Gemma, GPT-OSS, and Dolphin.')
        ref = input('Model ID: ').strip()
        if not ref or not supported_preexisting(ref):
            print('Unsupported or empty pre-existing model ID. Enter a Gemma, GPT-OSS, or Dolphin model ID.')
            return
    elif source == '2':
        ref = input('HF model ID or local checkpoint: ').strip()
        if not ref:
            return
    else:
        # Accept a model name first. The requirement checker can then install
        # Ollama before we query its model list.
        ref = input('Ollama model name (or number after install): ').strip()
        if not ref:
            return

    # Dependencies are checked before hardware caps so a stale CPU-only torch
    # install cannot poison the hardware result.
    status = ensure_training_requirements(method, use_ollama)
    if status is None:
        print('\nTraining setup stopped before model loading. Nothing was trained.')
        return

    if use_ollama:
        # Now that Ollama has passed the requirement check, resolve the user's
        # name against the live local model list. A numeric selection is accepted.
        models = ollama_list(timeout=10)
        if not models:
            print('\nERROR: Ollama is installed but did not return any local models.')
            print('Run `ollama list` and make sure the Ollama service is running with at least one model.')
            return
        if ref.isdigit() and 1 <= int(ref) <= len(models):
            ref = models[int(ref) - 1]
        if ref.lower() not in {x.lower() for x in models}:
            print(f'\nERROR: Ollama model "{ref}" was not found.')
            print('Available local models:')
            for name in models[:30]:
                print(' -', name)
            return
        ref = load_model_ref('ollama', ref)
        if not ref:
            return

    hw = hardware()
    settings = caps_prompt(hw)
    files = choose_files()
    if not files:
        print('\nNo training data selected. Returning to the main menu.')
        return
    name = input('Training run name: ').strip() or time.strftime('run_%Y%m%d_%H%M%S')
    if input('Start training? [y/N]: ').strip().lower() != 'y':
        return
    print('\nTRAINING STARTED — DATAFORGE will keep within the displayed hardware caps.')
    try:
        out = train(ref, files, method, name, settings, hw)
    except KeyboardInterrupt:
        print('\nTRAINING STOPPED by user.')
        return False
    except Exception as exc:
        print('\nTRAINING FAILED:')
        print(str(exc)[:6000])
        retry = input('\n[T] Retry setup   [M] Main menu\nSelect: ').strip().lower()
        if retry == 't':
            return wizard(choose_files)
        return False
    print('\nTRAINING COMPLETE')
    print('Final artifact:', (out / 'final').resolve())
    return True

