from pathlib import Path
import json
ROOT=Path(__file__).resolve().parent
KNOWLEDGE_DIR=ROOT/'datasets'/'knowledge'
BEHAVIOR_DIR=ROOT/'datasets'/'behavior'
def stats():
    k=len(list(KNOWLEDGE_DIR.glob('*.jsonl'))); b=len(list(BEHAVIOR_DIR.glob('*.jsonl')))
    return {'knowledge':k,'behavior':b,'total':k+b}
def all_files(kind):
    d=KNOWLEDGE_DIR if kind=='knowledge' else BEHAVIOR_DIR
    return sorted(d.glob('*.jsonl'))
def search(kind,q=''):
    q=q.strip().lower(); return [p for p in all_files(kind) if not q or q in p.stem.lower()]
def load_rows(paths):
    rows=[]
    for p in paths:
        try:
            for line in Path(p).read_text(encoding='utf-8').splitlines():
                if line.strip():
                    x=json.loads(line)
                    if x.get('messages'): rows.append(x)
        except Exception: pass
    return rows
def choose_library_files():
    s=stats(); print(f"\nKnowledge: {s['knowledge']:,} datasets | Behavior: {s['behavior']:,} datasets")
    print('[1] All Knowledge\n[2] All Behavior\n[3] Knowledge + Behavior\n[4] Search/select\n[5] Back')
    c=input('Select: ').strip()
    if c=='1': return all_files('knowledge')
    if c=='2': return all_files('behavior')
    if c=='3': return all_files('knowledge')+all_files('behavior')
    if c!='4': return None
    kind=input('Type knowledge or behavior: ').strip().lower()
    if kind not in {'knowledge','behavior'}: return None
    q=input('Search: ').strip(); m=search(kind,q)
    for i,p in enumerate(m[:60],1): print(f'[{i:03}] {p.stem}')
    raw=input('Numbers comma-separated, A=all shown, B=back: ').strip().lower()
    if raw=='b': return None
    if raw=='a': return m[:60]
    out=[]
    for part in raw.split(','):
        try:
            n=int(part); out.append(m[n-1]) if 1<=n<=min(len(m),60) else None
        except ValueError: pass
    return out or None
