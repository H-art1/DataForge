'use strict';

const $ = (s, root=document) => root.querySelector(s);
const $$ = (s, root=document) => [...root.querySelectorAll(s)];
const state = {
  page:'dashboard', stats:null, list:[], selected:new Set(), currentDataset:null,
  editorRecords:[], editorMeta:null, editorPage:1, editorPageSize:50, editorTotalRecords:0, editorTotalPages:1, generatorPreview:null, generatorPayload:null,
  settings:null, trainingConfig:null, trainingReport:null, trainingStatus:null,
  libraryPage:1, libraryPageSize:25, libraryKind:'all', libraryQuery:'', libraryCategory:'',
  trainingDatasets:[], trainingSearch:'', exportDatasets:[], exportSearch:'',
  explorerDatasetId:'', explorerQuery:'', explorerPage:1, explorerTotalPages:1, importedFile:null, mobileOpen:false
};

async function api(path, options={}) {
  const opts={...options,headers:{'Content-Type':'application/json',...(options.headers||{})}};
  const response=await fetch(path,opts);
  const raw=await response.text();
  let data={};
  try { data=raw?JSON.parse(raw):{}; } catch { data={error:raw||'Unexpected server response.'}; }
  if(!response.ok) throw new Error(data.error||`Request failed (${response.status}).`);
  return data;
}
function esc(value='') { return String(value).replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
function n(value) { return Number(value||0).toLocaleString(); }
function size(value) { let x=Number(value||0); for(const unit of ['B','KB','MB','GB']) { if(x<1024||unit==='GB') return `${x.toFixed(1)} ${unit}`; x/=1024; } }
function toast(message,type='success') {
  const host=$('#toastHost'); const item=document.createElement('div'); item.className=`toast ${type}`; item.textContent=message; host.appendChild(item); setTimeout(()=>item.remove(),3800);
}
function badge(text,kind='') { return `<span class="badge ${kind}">${esc(text)}</span>`; }
function pageHeading(title,description,actions='') {
  return `<div class="page-heading"><div><div class="eyebrow">DATAFORGE WORKSPACE</div><h1>${esc(title)}</h1><p class="page-description">${esc(description)}</p></div><div class="heading-actions">${actions}</div></div>`;
}
function loading() { return `<div class="loading-state"><div class="spinner"></div><span>Loading workspace data…</span></div>`; }
function empty(title,detail='') { return `<div class="empty-state"><div class="empty-icon">◌</div><strong>${esc(title)}</strong><span>${esc(detail)}</span></div>`; }
function fmtCount(count) { return Number(count||0).toLocaleString(); }

const pageMeta={
  dashboard:['Dashboard','A live view of the datasets, records, and storage in this workspace.'],
  library:['Dataset Library','Search, filter, inspect, merge, split, and manage the active JSONL collections.'],
  explorer:['Dataset Explorer','Inspect dataset metadata and browse individual training records.'],
  behavior:['Behaviour Datasets','Browse instruction-tuning examples for assistant behaviour and interaction patterns.'],
  knowledge:['Knowledge Datasets','Browse topic-focused educational examples and specialist knowledge collections.'],
  generator:['Dataset Generator','Create a dataset from a topic, curated local seeds, or an optional configured AI provider.'],
  editor:['Dataset Editor','Edit individual message pairs, update metadata, and create versioned saves.'],
  validator:['Data Validator','Validate dataset structure, check duplicate records, and inspect library-wide quality.'],
  training:['Training Studio','Prepare datasets and compatible training configurations; start training only when the required stack is available.'],
  export:['Export Center','Export individual datasets or complete collections to JSONL, JSON, CSV, or ZIP.'],
  import:['Import Center','Import and validate JSONL, JSON, and CSV training data.'],
  analytics:['Analytics','Explore live counts, category distribution, storage usage, and quality signals.'],
  settings:['Settings','Configure the AI display identity, generation provider, preferences, and appearance.'],
  about:['About DATAFORGE','Product details, project architecture, release notes, and important capability boundaries.']
};

function setPage(page) {
  if(!pageMeta[page]) return;
  state.page=page;
  $('#currentSection').textContent=pageMeta[page][0];
  $$('.nav-item').forEach(el=>el.classList.toggle('active',el.dataset.page===page));
  $('#sidebar').classList.remove('open');
  renderPage();
}
async function renderPage() {
  const host=$('#pageContent'); host.innerHTML=loading();
  try {
    switch(state.page) {
      case 'dashboard': await renderDashboard(); break;
      case 'library': await renderLibrary('all'); break;
      case 'behavior': await renderLibrary('behavior'); break;
      case 'knowledge': await renderLibrary('knowledge'); break;
      case 'explorer': await renderExplorer(); break;
      case 'generator': await renderGenerator(); break;
      case 'editor': await renderEditor(); break;
      case 'validator': await renderValidator(); break;
      case 'training': await renderTraining(); break;
      case 'export': await renderExport(); break;
      case 'import': renderImport(); break;
      case 'analytics': await renderAnalytics(); break;
      case 'settings': await renderSettings(); break;
      case 'about': await renderAbout(); break;
    }
    $('#footerSystem').textContent='Local engine · Ready';
  } catch(error) {
    host.innerHTML=`<div class="panel">${empty('Could not load this workspace view',error.message)}<div style="text-align:center"><button class="btn" data-action="retry-page">Retry</button></div></div>`;
  }
}
function applyTheme(theme) {
  const chosen=theme==='light'?'light':'dark';
  document.documentElement.dataset.theme=chosen;
  const btn=$('#themeToggle'); if(btn) btn.textContent=chosen==='dark'?'☼':'☾';
}
function identityName() { return state.settings?.identity?.name || 'My AI'; }
function syncIdentity() {
  const name=identityName();
  $('#sidebarAiName').textContent=name;
  $('.profile-avatar').textContent=name.trim().charAt(0).toUpperCase()||'M';
  $('#sidebarAiName').title=name;
  $('.topbar-avatar').textContent=name.trim().charAt(0).toUpperCase()||'M';
}
async function loadSettings() {
  state.settings=await api('/api/settings');
  applyTheme(state.settings.theme);
  syncIdentity();
}
async function loadStats() { state.stats=await api('/api/overview'); return state.stats; }
function statsCards(stats) {
  const cards=[
    ['Total datasets',stats.total_datasets,'Across both libraries','▤'],
    ['Training records',stats.total_records,'Validated JSONL examples','≋'],
    ['Behaviour datasets',stats.behavior_datasets,`${n(stats.behavior_records)} records`,'◉'],
    ['Knowledge datasets',stats.knowledge_datasets,`${n(stats.knowledge_records)} records`,'⌘']
  ];
  return `<div class="stats-grid">${cards.map(c=>`<div class="stat-card"><div class="stat-top"><span>${c[0]}</span><span class="stat-symbol">${c[3]}</span></div><div class="stat-number">${n(c[1])}</div><div class="stat-caption">${c[2]}</div></div>`).join('')}</div>`;
}
function tableRows(items, checkboxes=false) {
  if(!items.length) return `<tr><td colspan="${checkboxes?6:5}">${empty('No datasets found','Try another search or filter.')}</td></tr>`;
  return items.map(d=>`<tr>
    ${checkboxes?`<td><input type="checkbox" class="dataset-check" data-id="${esc(d.dataset_id)}" ${state.selected.has(d.dataset_id)?'checked':''} aria-label="Select ${esc(d.name)}"></td>`:''}
    <td><div class="dataset-cell"><strong>${esc(d.name)}</strong><span>${esc(d.dataset_id)}</span></div></td>
    <td>${badge(d.kind==='behavior'?'Behaviour':'Knowledge')}</td>
    <td>${esc(d.category||'—')}</td>
    <td class="mono">${n(d.number_of_records)}</td>
    <td>${badge(d.quality_status||'unknown',String(d.quality_status||'').includes('validated')?'good':'warn')}</td>
    <td><button class="row-action" data-open-dataset="${esc(d.dataset_id)}">Open →</button></td>
  </tr>`).join('');
}
function categoryBars(items,maxItems=8) {
  const rows=(items||[]).slice(0,maxItems); const max=Math.max(1,...rows.map(x=>x.datasets));
  if(!rows.length) return empty('No category data','Category totals will appear after datasets are indexed.');
  return `<div class="chart-list">${rows.map(x=>`<div class="chart-row"><div class="chart-label" title="${esc(x.category)}">${esc(x.category)}</div><div class="chart-track"><div class="chart-fill" style="width:${Math.max(2,x.datasets/max*100)}%"></div></div><div class="chart-value">${n(x.datasets)}</div></div>`).join('')}</div>`;
}
async function renderDashboard() {
  const s=await loadStats();
  const recent=s.recent_datasets||[];
  $('#pageContent').innerHTML=`${pageHeading('Dashboard','Your dataset workspace at a glance.',`<button class="btn" data-go="library">Browse library</button><button class="btn primary" data-go="generator">＋ New dataset</button>`)}
    ${statsCards(s)}
    <div class="dashboard-grid">
      <div class="panel"><div class="panel-header"><div><h2 class="panel-title">Library distribution</h2><div class="panel-subtitle">Datasets grouped by their actual on-disk category metadata</div></div><button class="text-link" data-go="analytics">View analytics →</button></div>${categoryBars(s.category_distribution,9)}</div>
      <div class="panel"><div class="panel-header"><div><h2 class="panel-title">Workspace health</h2><div class="panel-subtitle">Live storage and quality indicators</div></div>${badge('Local','good')}</div>
        <div class="format-list">
          <div class="format-item"><div class="format-left"><div class="format-icon">DB</div><span>Storage used</span></div><div class="format-right">${esc(s.storage_human)}</div></div>
          <div class="format-item"><div class="format-left"><div class="format-icon">JL</div><span>Primary format</span></div><div class="format-right">JSONL</div></div>
          <div class="format-item"><div class="format-left"><div class="format-icon">✓</div><span>Validated datasets</span></div><div class="format-right">${n((s.quality||{}).validated||0)}</div></div>
          <div class="format-item"><div class="format-left"><div class="format-icon">B</div><span>Behaviour records</span></div><div class="format-right">${n(s.behavior_records)}</div></div>
          <div class="format-item"><div class="format-left"><div class="format-icon">K</div><span>Knowledge records</span></div><div class="format-right">${n(s.knowledge_records)}</div></div>
        </div><div style="margin-top:16px"><button class="btn ghost" data-go="validator">Run quality checks →</button></div>
      </div>
    </div>
    <div class="panel table-panel" style="margin-top:14px"><div class="table-toolbar"><div><h2 class="panel-title">Recently modified datasets</h2><div class="panel-subtitle">Based on file modification times</div></div><button class="text-link" data-go="library">Open dataset library →</button></div><div class="table-wrap"><table><thead><tr><th>Dataset</th><th>Collection</th><th>Category</th><th>Records</th><th>Quality</th><th></th></tr></thead><tbody>${recent.length?recent.map(d=>`<tr><td><div class="dataset-cell"><strong>${esc(d.name)}</strong><span>${esc(d.dataset_id)}</span></div></td><td>${badge(d.kind==='behavior'?'Behaviour':'Knowledge')}</td><td>${esc(d.category)}</td><td class="mono">${n(d.number_of_records)}</td><td>${badge(d.quality_status||'unknown','good')}</td><td><button class="row-action" data-open-dataset="${esc(d.dataset_id)}">Open →</button></td></tr>`).join(''):`<tr><td colspan="6">${empty('No datasets','Add or import a dataset to begin.')}</td></tr>`}</tbody></table></div></div>`;
}
async function renderLibrary(kind='all', page=state.libraryPage) {
  state.libraryKind=kind; state.libraryPage=page;
  const title=kind==='behavior'?'Behaviour Datasets':kind==='knowledge'?'Knowledge Datasets':'Dataset Library';
  const description=kind==='behavior'?pageMeta.behavior[1]:kind==='knowledge'?pageMeta.knowledge[1]:pageMeta.library[1];
  const params=new URLSearchParams({kind,q:state.libraryQuery,page:String(page),page_size:String(state.libraryPageSize),sort:'name'});
  if(state.libraryCategory) params.set('category',state.libraryCategory);
  const data=await api('/api/datasets?'+params.toString()); state.list=data.datasets||[];
  const counts=state.stats||await loadStats();
  const categoriesData=await api('/api/categories');
  const options=(categoriesData.categories||[]).map(c=>`<option value="${esc(c.name)}" ${state.libraryCategory===c.name?'selected':''}>${esc(c.name)}</option>`).join('');
  $('#pageContent').innerHTML=`${pageHeading(title,description,`<button class="btn" data-go="import">Import data</button><button class="btn primary" data-go="generator">＋ Generate</button>`)}
    <div class="mini-kpi" style="margin-bottom:14px"><span>${n(kind==='behavior'?counts.behavior_datasets:kind==='knowledge'?counts.knowledge_datasets:counts.total_datasets)} datasets</span><span>${n(kind==='behavior'?counts.behavior_records:kind==='knowledge'?counts.knowledge_records:counts.total_records)} records</span><span>JSONL primary format</span></div>
    <div class="panel table-panel"><div class="table-toolbar"><div class="toolbar-left"><div class="search-wrap"><span class="search-icon">⌕</span><input id="librarySearch" type="search" value="${esc(state.libraryQuery)}" placeholder="Search datasets, topics, or tags"></div><select id="libraryCategory" style="width:170px"><option value="">All categories</option>${options}</select><button class="btn" id="librarySearchBtn">Search</button></div><div class="toolbar-right"><button class="btn" id="mergeSelected" ${state.selected.size<2?'disabled':''}>Merge selected (${state.selected.size})</button><button class="btn" data-action="export-selected" ${state.selected.size<1?'disabled':''}>Export selected</button></div></div>
      <div class="table-wrap"><table><thead><tr><th style="width:32px"><input type="checkbox" id="selectPage" aria-label="Select page"></th><th>Dataset</th><th>Collection</th><th>Category</th><th>Records</th><th>Quality status</th><th></th></tr></thead><tbody>${tableRows(state.list,true)}</tbody></table></div>
      <div class="table-footer"><span>Showing ${data.total?((page-1)*state.libraryPageSize+1):0}–${Math.min(page*state.libraryPageSize,data.total)} of ${n(data.total)} datasets</span><div class="pagination"><button class="btn" data-page="${Math.max(1,page-1)}" ${page<=1?'disabled':''}>← Previous</button><span>${page} / ${data.total_pages}</span><button class="btn" data-page="${Math.min(data.total_pages,page+1)}" ${page>=data.total_pages?'disabled':''}>Next →</button></div></div>
    </div>`;
  $('#navDatasetCount').textContent=counts.total_datasets>=1000?(counts.total_datasets/1000).toFixed(1)+'k':n(counts.total_datasets);
}
async function datasetOptions(selected='') {
  const data=await api('/api/datasets?page=1&page_size=1500&sort=name');
  return data.datasets.map(d=>`<option value="${esc(d.dataset_id)}" ${d.dataset_id===selected?'selected':''}>${esc(d.name)} · ${d.kind==='behavior'?'Behaviour':'Knowledge'}</option>`).join('');
}
async function renderExplorer() {
  const opts=await datasetOptions(state.explorerDatasetId);
  $('#pageContent').innerHTML=`${pageHeading('Dataset Explorer',pageMeta.explorer[1])}
    <div class="panel"><div class="field-grid three"><div class="field" style="grid-column:span 2"><label>Choose a dataset</label><select id="explorerSelect"><option value="">Select a dataset…</option>${opts}</select></div><div class="field"><label>Search records</label><input id="explorerSearch" placeholder="Search within dataset" value="${esc(state.explorerQuery)}"></div></div><div style="display:flex;gap:8px;margin-top:13px"><button class="btn primary" id="explorerLoad">Load dataset</button><button class="btn" id="explorerClear">Clear search</button></div><div id="explorerResult" style="margin-top:18px">${state.explorerDatasetId?'Loading selected dataset…':empty('Select a dataset','Inspect its messages and metadata here.')}</div></div>`;
  if(state.explorerDatasetId) await loadExplorerDataset(state.explorerDatasetId,state.explorerQuery,1);
}
async function loadExplorerDataset(id,q='',page=1) {
  const host=$('#explorerResult'); if(!host) return; host.innerHTML=loading();
  const data=await api(`/api/datasets/${encodeURIComponent(id)}?page=${page}&page_size=50${q?'&q='+encodeURIComponent(q):''}`);
  const m=data.metadata; state.explorerPage=data.page; state.explorerTotalPages=data.total_pages;
  const first=data.total_records?(data.page-1)*data.page_size+1:0;
  const last=Math.min(data.page*data.page_size,data.total_records);
  host.innerHTML=`<div class="split-layout"><div class="panel" style="box-shadow:none"><div class="panel-header"><div><h2 class="panel-title">${esc(m.name)}</h2><div class="panel-subtitle">${esc(m.dataset_id)}</div></div>${badge(m.quality_status,'good')}</div><div class="info-list"><div class="info-row"><span>Collection</span><strong>${esc(m.kind)}</strong></div><div class="info-row"><span>Category</span><strong>${esc(m.category)}</strong></div><div class="info-row"><span>Subcategory</span><strong>${esc(m.subcategory)}</strong></div><div class="info-row"><span>Records</span><strong>${n(m.number_of_records)}</strong></div><div class="info-row"><span>Format</span><strong>${esc(m.format)}</strong></div><div class="info-row"><span>Version</span><strong>${esc(m.version)}</strong></div><div class="info-row"><span>Created</span><strong>${esc(m.creation_date)}</strong></div><div class="info-row"><span>Storage</span><strong>${size(m.size_bytes)}</strong></div></div><p class="page-description" style="margin-top:14px">${esc(m.description)}</p><div style="display:flex;gap:8px;margin-top:13px"><button class="btn" data-edit-dataset="${esc(m.dataset_id)}">Edit dataset</button><button class="btn" data-validate-dataset="${esc(m.dataset_id)}">Validate</button></div></div><div class="panel" style="box-shadow:none"><div class="panel-header"><div><h2 class="panel-title">Training record preview</h2><div class="panel-subtitle">${n(data.total_records)} matching records · showing ${n(first)}–${n(last)}</div></div></div>${data.records.map((r,i)=>`<div class="record-card"><div class="record-header"><span>RECORD ${first+i}</span>${badge('Chat messages')}</div>${(r.messages||[]).map(msg=>`<div class="record-view"><div class="record-role">${esc(msg.role)}</div><div class="record-content">${esc(msg.content)}</div></div>`).join('')}</div>`).join('')||empty('No matching records','Change the search term or inspect the full dataset.')}<div class="table-footer"><span>Page ${data.page} of ${data.total_pages}</span><div class="pagination"><button class="btn" id="explorerPrev" ${data.page<=1?'disabled':''}>← Previous</button><span>${data.page} / ${data.total_pages}</span><button class="btn" id="explorerNext" ${data.page>=data.total_pages?'disabled':''}>Next →</button></div></div></div></div>`;
  state.currentDataset=m;
}

async function renderGenerator() {
  const cats=await api('/api/categories');
  const groups=(cats.categories||[]).filter(c=>c.name!=='Behaviour');
  $('#pageContent').innerHTML=`${pageHeading('Dataset Generator',pageMeta.generator[1],`<button class="btn" data-go="editor">Open editor</button>`)}
    <div class="split-layout">
      <div class="panel"><div class="panel-header"><div><h2 class="panel-title">Generation setup</h2><div class="panel-subtitle">Configure a dataset and preview it before saving. Local curated mode creates up to five distinct seed records; larger runs use the optional provider.</div></div>${badge('Preview first')}</div>
        <div class="field-grid"><div class="field"><label>Collection</label><select id="genKind"><option value="behavior">Behaviour</option><option value="knowledge" selected>Knowledge</option></select></div><div class="field"><label>Category</label><input id="genCategory" placeholder="e.g. Artificial Intelligence" value="Artificial Intelligence"></div>
        <div class="field"><label>Dataset topic</label><input id="genTopic" placeholder="e.g. attention mechanism" value="AI fine tuning"></div><div class="field"><label>Subcategory / profile</label><input id="genSubcategory" placeholder="e.g. Transformer architecture" value="Model adaptation"></div>
        <div class="field"><label>Number of records</label><input id="genCount" type="number" min="1" max="500" value="5"></div><div class="field"><label>Difficulty</label><select id="genDifficulty"><option>Beginner</option><option selected>Intermediate</option><option>Advanced</option></select></div>
        <div class="field"><label>Writing style</label><select id="genStyle"><option>Balanced</option><option>Concise</option><option>Detailed</option><option>Formal</option></select></div><div class="field"><label>Response tone</label><select id="genTone"><option>Clear and neutral</option><option>Encouraging</option><option>Professional</option><option>Friendly</option></select></div></div>
        <div class="field" style="margin-top:13px"><label>Source notes (recommended for new knowledge topics)</label><textarea id="genNotes" rows="4" placeholder="Add reviewed facts, definitions, examples, constraints, or references. For unlisted knowledge topics this prevents local generation from inventing facts."></textarea><small>Local generation uses curated seeds for known topics. Unknown knowledge topics require source notes. No provider is called unless enabled in Settings.</small></div>
        <div style="display:flex;gap:8px;margin-top:15px"><button class="btn primary" id="genPreview">Generate preview</button><button class="btn" id="genReset">Reset</button></div>
      </div>
      <div class="panel"><div class="panel-header"><div><h2 class="panel-title">Generation preview</h2><div class="panel-subtitle">Inspect records and validation before saving.</div></div><div id="genStatus">${badge('Not generated')}</div></div><div id="generatorPreviewArea">${empty('No preview yet','Configure the topic and generate a sample set.')}</div></div>
    </div>`;
  if(state.generatorPreview) renderGeneratorPreview(state.generatorPreview);
}
function renderGeneratorPreview(preview) {
  const host=$('#generatorPreviewArea'); if(!host) return;
  host.innerHTML=`<div class="mini-kpi"><span>${n(preview.record_count)} records</span><span>${esc(preview.source)}</span><span>${badge(preview.validation.status,preview.validation.valid?'good':'bad')}</span></div><div class="notice">Preview only · not yet saved to the library</div><div style="max-height:440px;overflow:auto;margin-top:10px">${preview.records.slice(0,8).map((r,i)=>`<div class="record-card"><div class="record-header"><span>PREVIEW ${(i+1)}</span></div>${r.messages.map(m=>`<div class="record-view"><div class="record-role">${esc(m.role)}</div><div class="record-content">${esc(m.content)}</div></div>`).join('')}</div>`).join('')}</div><div style="display:flex;gap:8px;margin-top:12px"><button class="btn primary" id="genSave">Save to library</button><button class="btn" data-go="validator">Open validator</button></div>`;
  $('#genStatus').innerHTML=badge('Preview ready','good');
}
async function renderEditor() {
  const opts=await datasetOptions(state.editorMeta?.dataset_id||'');
  $('#pageContent').innerHTML=`${pageHeading('Dataset Editor',pageMeta.editor[1])}
    <div class="panel"><div class="field-grid three"><div class="field" style="grid-column:span 2"><label>Dataset</label><select id="editorSelect"><option value="">Select a dataset…</option>${opts}</select></div><div class="field"><label>Actions</label><button class="btn" id="editorLoad">Load selected dataset</button></div></div></div>
    <div id="editorWorkspace" style="margin-top:14px">${empty('No dataset loaded','Select a dataset above to edit its training records.')}</div>`;
  if(state.editorMeta) await loadEditorDataset(state.editorMeta.dataset_id);
}
async function loadEditorDataset(id,page=1) {
  const host=$('#editorWorkspace'); if(!host) return; host.innerHTML=loading();
  const data=await api(`/api/datasets/${encodeURIComponent(id)}?page=${page}&page_size=${state.editorPageSize}`);
  state.editorMeta=data.metadata; state.editorRecords=data.records; state.editorPage=data.page;
  state.editorTotalRecords=data.total_records; state.editorTotalPages=data.total_pages;
  renderEditorWorkspace();
}
function renderEditorWorkspace() {
  const m=state.editorMeta, rows=state.editorRecords;
  const host=$('#editorWorkspace'); if(!host||!m) return;
  const first=state.editorTotalRecords?((state.editorPage-1)*state.editorPageSize+1):0;
  const last=Math.min(state.editorPage*state.editorPageSize,state.editorTotalRecords);
  host.innerHTML=`<div class="split-layout"><div class="stack"><div class="panel"><div class="panel-header"><div><h2 class="panel-title">Dataset metadata</h2><div class="panel-subtitle">${esc(m.dataset_id)} · Version ${esc(m.version)}</div></div>${badge(m.quality_status,'good')}</div><div class="field-grid"><div class="field"><label>Name</label><input id="editorName" value="${esc(m.name)}"></div><div class="field"><label>Tags (comma separated)</label><input id="editorTags" value="${esc((m.tags||[]).join(', '))}"></div></div><div class="field" style="margin-top:12px"><label>Description</label><textarea id="editorDescription">${esc(m.description)}</textarea></div><div class="mini-kpi" style="margin-top:10px"><span>${n(state.editorTotalRecords)} total records</span><span>${esc(m.kind)}</span><span>${size(m.size_bytes)}</span><span>Page ${state.editorPage} of ${state.editorTotalPages}</span></div></div><div class="panel"><div class="panel-header"><div><h2 class="panel-title">Record editor</h2><div class="panel-subtitle">Edit records in bounded pages; large datasets are never loaded all at once.</div></div><button class="btn" id="addRecord">＋ Add record</button></div><div id="editorRecords">${rows.map((r,i)=>editorRecordCard(r,i,first+i)).join('')}</div><div class="table-footer" style="margin-top:12px"><span>Showing ${n(first)}–${n(last)} of ${n(state.editorTotalRecords)}</span><div class="pagination"><button class="btn" id="editorPrev" ${state.editorPage<=1?'disabled':''}>← Previous</button><span>${state.editorPage} / ${state.editorTotalPages}</span><button class="btn" id="editorNext" ${state.editorPage>=state.editorTotalPages?'disabled':''}>Next →</button></div></div><div style="display:flex;gap:8px;margin-top:14px;flex-wrap:wrap"><button class="btn primary" id="saveEditor">Save page as version</button><button class="btn" id="editorValidate">Validate full dataset</button><button class="btn" id="splitEditor">Split dataset</button><button class="btn danger" id="deleteEditor">Delete dataset</button></div></div></div><div class="panel"><div class="panel-header"><div><h2 class="panel-title">Version history</h2><div class="panel-subtitle">A recoverable full-file backup is created before each save.</div></div><button class="text-link" id="loadVersions">Refresh versions</button></div><div id="versionList">${empty('Version history','No saved versions listed yet.')}</div></div></div>`;
}
function editorRecordCard(row,i,displayIndex=i+1) {
  const user=(row.messages||[]).find(m=>m.role==='user')?.content||'';
  const assistant=(row.messages||[]).find(m=>m.role==='assistant')?.content||'';
  return `<div class="record-card" data-record="${i}"><div class="record-header"><span>RECORD ${displayIndex}</span><button class="row-action" data-remove-record="${i}">Remove</button></div><div class="record-fields"><div><label>User prompt</label><textarea data-record-field="user" data-index="${i}">${esc(user)}</textarea></div><div><label>Assistant response</label><textarea data-record-field="assistant" data-index="${i}">${esc(assistant)}</textarea></div></div></div>`;
}
async function renderValidator() {
  $('#pageContent').innerHTML=`${pageHeading('Data Validator',pageMeta.validator[1],`<button class="btn primary" id="validateAll">Run full library validation</button>`)}
    <div class="panel"><div class="panel-header"><div><h2 class="panel-title">Validation report</h2><div class="panel-subtitle">Checks the chat schema, required roles, empty content, and exact duplicates.</div></div>${badge('Ready')}</div><div id="validatorResult">${empty('No validation run yet','The full library scan checks every JSONL record on disk.')}</div></div>`;
}
async function renderTraining() {
  const [cfgData,sets]=await Promise.all([api('/api/training/config'),api('/api/datasets?page=1&page_size=60')]);
  state.trainingConfig={...cfgData.config,...(state.trainingConfig||{})}; state.trainingDatasets=sets.datasets;
  const c=state.trainingConfig,h=cfgData.hardware||{},deps=cfgData.dependencies||{};
  state.trainingSelectedIds=new Set(c.dataset_ids||[]);
  $('#pageContent').innerHTML=`${pageHeading('Training Studio',pageMeta.training[1],`<button class="btn" id="saveTrainingConfig">Save configuration</button>`)}
    <div class="split-layout">
      <div class="stack">
        <div class="panel"><div class="panel-header"><div><h2 class="panel-title">Training configuration</h2><div class="panel-subtitle">Configuration is separate from dataset export and actual model training.</div></div>${badge('Configuration','good')}</div>
          <div class="field-grid"><div class="field"><label>Model ID or local checkpoint</label><input id="trainModel" placeholder="e.g. org/model or ./checkpoints/model" value="${esc(c.model_ref||'')}"></div><div class="field"><label>Training method</label><select id="trainMethod"><option value="lora" ${c.method==='lora'?'selected':''}>LoRA</option><option value="qlora" ${c.method==='qlora'?'selected':''}>QLoRA</option><option value="full" ${c.method==='full'?'selected':''}>Full fine-tuning</option></select></div>
          <div class="field"><label>Run name</label><input id="trainOutput" value="${esc(c.output_name||'dataforge_run')}"></div><div class="field"><label>Validation split</label><input id="trainSplit" type="number" min="0" max="0.49" step="0.05" value="${Number(c.validation_split??.1)}"></div>
          <div class="field"><label>Epochs (max ${h.epochs||1})</label><input id="trainEpochs" type="number" min="1" max="${h.epochs||1}" value="${c.epochs||1}"></div><div class="field"><label>Steps per epoch (max ${h.steps||100})</label><input id="trainSteps" type="number" min="1" max="${h.steps||100}" value="${c.steps||100}"></div>
          <div class="field"><label>Batch size (max ${h.batch||1})</label><input id="trainBatch" type="number" min="1" max="${h.batch||1}" value="${c.batch||1}"></div><div class="field"><label>Gradient accumulation (max ${h.grad||4})</label><input id="trainGrad" type="number" min="1" max="${h.grad||4}" value="${c.gradient_accumulation||4}"></div>
          <div class="field"><label>Sequence length (max ${h.length||1024})</label><input id="trainLength" type="number" min="1" max="${h.length||1024}" value="${c.sequence_length||1024}"></div><div class="field"><label>LoRA rank (max ${h.rank||4})</label><input id="trainRank" type="number" min="1" max="${h.rank||4}" value="${c.rank||4}"></div>
          <div class="field"><label>Learning rate (max 0.0003)</label><input id="trainLr" type="number" min="0.0000001" max="0.0003" step="0.00001" value="${c.learning_rate||0.0002}"></div><div class="field"><label>Random seed</label><input id="trainSeed" type="number" value="${c.seed||42}"></div></div>
          <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:14px"><button class="btn primary" id="trainPreflight">Run preflight checks</button><button class="btn" id="trainStart" disabled>Start actual training</button><button class="btn" id="downloadTrainingConfig">Export config JSON</button></div>
          <div id="trainingPreflight" style="margin-top:14px">${empty('Preflight not run','Check dependencies, selected data, hardware caps, and split sizes.')}</div>
        </div>
        <div class="panel"><div class="panel-header"><div><h2 class="panel-title">Dataset selection</h2><div class="panel-subtitle">Choose one or more JSONL datasets for training.</div></div><span id="trainingSelectedCount">${(c.dataset_ids||[]).length} selected</span></div>
          <div class="search-wrap" style="margin-bottom:10px"><span class="search-icon">⌕</span><input id="trainingSearch" type="search" placeholder="Search datasets by name or topic" value="${esc(state.trainingSearch)}"></div><div id="trainingDatasetList" class="selection-list">${renderTrainingDatasetItems()}</div>
          <div class="notice">The list shows the first 60 results. Use search to locate additional datasets in the 1,300-item library.</div>
        </div>
      </div>
      <div class="stack">
        <div class="panel"><div class="panel-header"><div><h2 class="panel-title">Hardware profile</h2><div class="panel-subtitle">Limits are calculated from the current environment.</div></div>${badge(h.cuda?'CUDA available':'CPU mode',h.cuda?'good':'warn')}</div><div class="info-list"><div class="info-row"><span>CPU threads</span><strong>${n(h.cpu)}</strong></div><div class="info-row"><span>System RAM</span><strong>${h.ram||0} GB</strong></div><div class="info-row"><span>GPU</span><strong>${esc(h.gpu||'Unknown')}</strong></div><div class="info-row"><span>GPU memory</span><strong>${h.vram||0} GB</strong></div><div class="info-row"><span>PyTorch CUDA</span><strong>${h.cuda?'Verified':'Not available'}</strong></div></div></div>
        <div class="panel"><div class="panel-header"><div><h2 class="panel-title">Dependency status</h2><div class="panel-subtitle">Availability in the current Python environment.</div></div></div><div class="check-list">${Object.entries(deps).map(([k,v])=>`<div class="check-item"><span class="check-mark ${v?'':'warn'}">${v?'✓':'!'}</span><span>${esc(k)} · ${v?'Available':'Not installed'}</span></div>`).join('')}</div></div>
        <div class="panel"><div class="panel-header"><div><h2 class="panel-title">Training monitor</h2><div class="panel-subtitle">Live status reported by the training engine.</div></div><span id="trainingStatusBadge">${badge('Idle')}</span></div><div id="trainingMonitor"><div class="progress-track"><div class="progress-fill" style="width:0%"></div></div><div class="notice">No training job is running. Dataset preparation and configuration do not constitute model training.</div></div></div>
      </div>
    </div>`;
  renderTrainingMonitor();
}
function renderTrainingDatasetItems() {
  const selected=state.trainingSelectedIds||new Set();
  return (state.trainingDatasets||[]).map(d=>`<label class="selection-item"><input type="checkbox" data-training-id="${esc(d.dataset_id)}" ${selected.has(d.dataset_id)?'checked':''}><span class="selection-copy"><strong>${esc(d.name)}</strong><span>${esc(d.category)} · ${n(d.number_of_records)} records · ${d.kind}</span></span></label>`).join('')||empty('No dataset results','Search for another topic.');
}
function readTrainingConfig() {
  const ids=[...(state.trainingSelectedIds||new Set())];
  return {model_ref:$('#trainModel')?.value.trim()||'',method:$('#trainMethod')?.value||'lora',output_name:$('#trainOutput')?.value.trim()||'dataforge_run',validation_split:Number($('#trainSplit')?.value??.1),epochs:Number($('#trainEpochs')?.value||1),steps:Number($('#trainSteps')?.value||100),batch:Number($('#trainBatch')?.value||1),gradient_accumulation:Number($('#trainGrad')?.value||4),sequence_length:Number($('#trainLength')?.value||1024),rank:Number($('#trainRank')?.value||4),alpha:Number($('#trainRank')?.value||4)*2,learning_rate:Number($('#trainLr')?.value||.0002),seed:Number($('#trainSeed')?.value||42),dataset_ids:ids};
}
function renderTrainingMonitor() {
  if(!state.trainingStatus) return;
  const m=state.trainingStatus; const badgeText=m.status==='complete'?'Completed':m.status==='running'?'Training':m.status==='failed'?'Failed':'Idle';
  const kind=m.status==='complete'?'good':m.status==='failed'?'bad':m.status==='running'?'warn':'';
  const badgeHost=$('#trainingStatusBadge'); if(badgeHost) badgeHost.innerHTML=badge(badgeText,kind);
  const host=$('#trainingMonitor'); if(!host) return;
  host.innerHTML=`<div class="progress-track"><div class="progress-fill" style="width:${Math.max(0,Math.min(100,m.progress||0))}%"></div></div><div class="info-list" style="margin-top:10px"><div class="info-row"><span>Stage</span><strong>${esc(m.stage||'Not started')}</strong></div><div class="info-row"><span>Progress</span><strong>${n(m.progress||0)}%</strong></div><div class="info-row"><span>Status</span><strong>${esc(m.status)}</strong></div>${m.output?`<div class="info-row"><span>Artifact</span><strong>${esc(m.output)}</strong></div>`:''}</div>${m.error?`<div class="callout warn" style="margin-top:10px">${esc(m.error)}</div>`:''}<div class="record-content" style="margin-top:10px;max-height:130px;overflow:auto">${(m.logs||[]).map(esc).join('\n')}</div>`;
}
let trainingPoll=null;
async function pollTraining() {
  try { state.trainingStatus=await api('/api/training/status'); renderTrainingMonitor(); if(state.trainingStatus.status!=='running'&&trainingPoll){clearInterval(trainingPoll);trainingPoll=null;} }
  catch(e){console.warn(e);}
}
async function renderExport() {
  const opts=await datasetOptions('');
  $('#pageContent').innerHTML=`${pageHeading('Export Center',pageMeta.export[1])}
    <div class="split-layout"><div class="panel"><div class="panel-header"><div><h2 class="panel-title">Export one dataset</h2><div class="panel-subtitle">Download a selected dataset in the format your training stack expects.</div></div></div><div class="field"><label>Dataset</label><select id="exportDataset"><option value="">Select dataset…</option>${opts}</select></div><div class="field" style="margin-top:13px"><label>Export format</label><select id="exportFormat"><option value="jsonl">JSONL — chat training records</option><option value="json">JSON — metadata and records</option><option value="csv">CSV — prompt and response</option></select></div><button class="btn primary" id="exportOne" style="margin-top:14px">Download dataset</button></div>
    <div class="panel"><div class="panel-header"><div><h2 class="panel-title">Export full library</h2><div class="panel-subtitle">Package the active collection and manifest into a ZIP archive.</div></div></div><div class="field"><label>Collection</label><select id="exportKind"><option value="all">Behaviour + Knowledge</option><option value="behavior">Behaviour only</option><option value="knowledge">Knowledge only</option></select></div><div class="callout" style="margin-top:13px">Exports are generated from current files on disk. The legacy V13.3 archive is not included in the active library export.</div><button class="btn primary" id="exportAll" style="margin-top:14px">Download ZIP archive</button></div></div>`;
}
function renderImport() {
  $('#pageContent').innerHTML=`${pageHeading('Import Center',pageMeta.import[1])}
    <div class="split-layout"><div class="panel"><div class="panel-header"><div><h2 class="panel-title">Import training data</h2><div class="panel-subtitle">Files are parsed and validated before they enter the library.</div></div>${badge('40 MB max')}</div>
      <label class="file-drop" for="importFile"><span style="font-size:22px">⇩</span><strong>Choose a dataset file</strong><span>JSONL, JSON, or CSV · UTF-8 text</span><span id="importFileName" class="file-name">No file selected</span><input id="importFile" type="file" accept=".jsonl,.ndjson,.json,.csv,text/plain,application/json,text/csv"></label>
      <div class="field-grid" style="margin-top:14px"><div class="field"><label>Collection</label><select id="importKind"><option value="behavior">Behaviour</option><option value="knowledge" selected>Knowledge</option></select></div><div class="field"><label>Dataset name</label><input id="importName" placeholder="Optional name (uses filename)"></div><div class="field"><label>Category</label><input id="importCategory" value="Imported"></div><div class="field"><label>Subcategory</label><input id="importSubcategory" value="External dataset"></div></div>
      <button class="btn primary" id="importUpload" style="margin-top:15px" disabled>Validate and import</button>
    </div><div class="panel"><div class="panel-header"><div><h2 class="panel-title">Accepted schema</h2><div class="panel-subtitle">Chat-format JSONL is the primary storage format.</div></div></div><pre class="callout" style="white-space:pre-wrap;font-size:10px">{"messages":[
  {"role":"user","content":"Explain ..."},
  {"role":"assistant","content":"..."}
]}</pre><div class="check-list" style="margin-top:12px"><div class="check-item"><span class="check-mark">✓</span><span>JSONL: one training object per line</span></div><div class="check-item"><span class="check-mark">✓</span><span>JSON: array of objects or {"records": [...]}</span></div><div class="check-item"><span class="check-mark">✓</span><span>CSV: prompt/response or user/assistant columns</span></div><div class="check-item"><span class="check-mark">✓</span><span>Invalid data is rejected without altering existing datasets</span></div></div></div></div>`;
}
async function renderAnalytics() {
  const s=await loadStats();
  $('#pageContent').innerHTML=`${pageHeading('Analytics',pageMeta.analytics[1],`<button class="btn" id="refreshAnalytics">Refresh statistics</button>`)}${statsCards(s)}
    <div class="dashboard-grid"><div class="panel"><div class="panel-header"><div><h2 class="panel-title">Category distribution</h2><div class="panel-subtitle">Dataset count by metadata category</div></div></div>${categoryBars(s.category_distribution,20)}</div>
    <div class="stack"><div class="panel"><h2 class="panel-title">Storage profile</h2><div class="stat-number" style="margin-top:17px">${esc(s.storage_human)}</div><div class="stat-caption">Combined on-disk size of active JSONL datasets and metadata.</div><div class="info-list" style="margin-top:14px"><div class="info-row"><span>JSONL datasets</span><strong>${n(s.total_datasets)}</strong></div><div class="info-row"><span>Training records</span><strong>${n(s.total_records)}</strong></div><div class="info-row"><span>Behaviour / Knowledge</span><strong>${n(s.behavior_datasets)} / ${n(s.knowledge_datasets)}</strong></div></div></div>
    <div class="panel"><h2 class="panel-title">Quality status</h2><div class="format-list" style="margin-top:13px">${Object.entries(s.quality||{}).map(([k,v])=>`<div class="format-item"><div class="format-left"><span>${esc(k)}</span></div><div class="format-right">${n(v)}</div></div>`).join('')}</div><div style="margin-top:13px"><button class="btn" data-go="validator">Run validation →</button></div></div></div></div>`;
}
async function renderSettings() {
  const settings=state.settings||await api('/api/settings'); state.settings=settings;
  const id=settings.identity||{}; const p=settings.provider||{};
  $('#pageContent').innerHTML=`${pageHeading('Settings',pageMeta.settings[1],`<button class="btn primary" id="saveSettings">Save changes</button>`)}
    <div class="split-layout"><div class="stack"><div class="panel"><div class="panel-header"><div><h2 class="panel-title">AI Identity</h2><div class="panel-subtitle">Control the display identity used throughout DATAFORGE.</div></div>${badge('Display configuration')}</div>
        <div class="field-grid"><div class="field"><label>AI display name</label><input id="identityName" maxlength="60" value="${esc(id.name||'My AI')}"></div><div class="field"><label>Personality preset</label><select id="identityPersonality">${['Helpful professional','Friendly tutor','Technical expert','Concise analyst','Creative collaborator','Custom'].map(x=>`<option ${id.personality_preset===x?'selected':''}>${x}</option>`).join('')}</select></div>
        <div class="field"><label>Communication style</label><select id="identityStyle">${['Balanced','Concise','Detailed','Conversational','Formal','Step-by-step'].map(x=>`<option ${id.communication_style===x?'selected':''}>${x}</option>`).join('')}</select></div><div class="field"><label>Response tone</label><select id="identityTone">${['Calm and clear','Professional','Friendly','Encouraging','Neutral','Direct'].map(x=>`<option ${id.response_tone===x?'selected':''}>${x}</option>`).join('')}</select></div>
        <div class="field"><label>Default behaviour profile</label><select id="identityBehaviour">${['Helpful assistant','Evidence-aware','Teacher','Problem solver','Research assistant','Custom'].map(x=>`<option ${id.default_behavior_profile===x?'selected':''}>${x}</option>`).join('')}</select></div><div class="field"><label>Selected datasets (IDs separated by commas)</label><input id="identityDatasets" value="${esc((id.selected_datasets||[]).join(', '))}" placeholder="Optional dataset IDs"></div></div>
        <div class="field" style="margin-top:13px"><label>AI description</label><textarea id="identityDescription" rows="3">${esc(id.description||'')}</textarea></div><div class="callout" style="margin-top:12px"><strong>Identity is not model training.</strong> Changing this name or profile updates the application's display configuration. It does not change model weights, capabilities, or the underlying model.</div>
      </div><div class="panel"><div class="panel-header"><div><h2 class="panel-title">AI provider integration</h2><div class="panel-subtitle">Optional OpenAI-compatible endpoint for dataset generation.</div></div>${badge(p.key_available?'API key available':'No API key',p.key_available?'good':'warn')}</div>
        <label class="switch"><input id="providerEnabled" type="checkbox" ${p.enabled?'checked':''}> Enable configured provider for generation</label><div class="field-grid" style="margin-top:13px"><div class="field"><label>Base URL</label><input id="providerUrl" value="${esc(p.base_url||'https://api.openai.com/v1')}"></div><div class="field"><label>Model name</label><input id="providerModel" value="${esc(p.model||'')}" placeholder="Provider model ID"></div><div class="field"><label>API key environment variable</label><input id="providerEnv" value="${esc(p.api_key_env||'OPENAI_API_KEY')}"></div></div><div class="callout" style="margin-top:12px">API keys are not saved in DATAFORGE settings or returned to the interface. Set the named environment variable in your operating system before launching the app. The key is sent only to the configured endpoint when generation is requested.</div>
      </div></div>
      <div class="stack"><div class="panel"><div class="panel-header"><div><h2 class="panel-title">Appearance</h2><div class="panel-subtitle">Theme is saved to the local configuration.</div></div></div><div class="preference-row"><div class="preference-copy"><strong>Dark appearance</strong><span>Low-contrast dark surfaces and muted accents.</span></div><label class="switch"><input type="radio" name="themeChoice" value="dark" ${settings.theme==='dark'?'checked':''}> Dark</label></div><div class="preference-row"><div class="preference-copy"><strong>Light appearance</strong><span>Bright neutral surfaces for daytime use.</span></div><label class="switch"><input type="radio" name="themeChoice" value="light" ${settings.theme==='light'?'checked':''}> Light</label></div></div>
      <div class="panel"><h2 class="panel-title">Workspace preferences</h2><div class="preference-row"><div class="preference-copy"><strong>Confirm destructive actions</strong><span>Ask before deleting a dataset from the active library.</span></div><input id="prefConfirm" type="checkbox" style="width:16px;min-height:16px" ${(settings.preferences||{}).confirm_destructive_actions!==false?'checked':''}></div><div class="preference-row"><div class="preference-copy"><strong>Automatic backups</strong><span>Keep a recoverable copy before destructive edits and deletes.</span></div><input id="prefBackup" type="checkbox" style="width:16px;min-height:16px" ${(settings.preferences||{}).auto_backup!==false?'checked':''}></div></div></div></div>`;
}
async function renderAbout() {
  const s=await loadStats();
  $('#pageContent').innerHTML=`${pageHeading('About DATAFORGE',pageMeta.about[1])}
    <div class="panel" style="padding:25px"><div class="brand-lockup" style="padding:0 0 17px"><div class="brand-mark"><svg viewBox="0 0 36 36"><path d="M7 9.5 18 4l11 5.5v17L18 32 7 26.5z"/><path d="M12 13.5h12M12 18h8M12 22.5h10"/></svg></div><div><div class="brand-name">DATAFORGE H1</div><div class="brand-version">VERSION <span>1.0.0</span></div></div></div><h1 style="font-size:28px">A local-first dataset workspace.</h1><p class="page-description" style="max-width:760px;margin:12px 0 22px">DATAFORGE H1 V1 brings dataset library management, structured generation, validation, export workflows, and model-training preparation into one desktop-style application that runs locally in your browser.</p><div class="stats-grid">${[['Active datasets',s.total_datasets],['Training records',s.total_records],['Behaviour sets',s.behavior_datasets],['Knowledge sets',s.knowledge_datasets]].map(x=>`<div class="stat-card"><div class="stat-top">${x[0]}</div><div class="stat-number">${n(x[1])}</div></div>`).join('')}</div>
    <div class="dashboard-grid"><div><h2 class="panel-title" style="margin-bottom:12px">Release highlights</h2><div class="check-list"><div class="check-item"><span class="check-mark">✓</span><span>Modern local application shell with dashboard, library, explorer, editor, generator, validator, training studio, analytics, settings, and import/export tools.</span></div><div class="check-item"><span class="check-mark">✓</span><span>1,300 active datasets and 6,500 unique structured chat records, with generated metadata and live file-based counts.</span></div><div class="check-item"><span class="check-mark">✓</span><span>Versioned edits, automatic backups, merge/split, validation, and import/export to JSONL, JSON, CSV, and ZIP.</span></div><div class="check-item"><span class="check-mark">✓</span><span>Optional OpenAI-compatible generation provider using operating-system environment variables for API keys.</span></div><div class="check-item"><span class="check-mark">✓</span><span>Training preflight, dataset splitting, hardware caps, dependency checks, and actual training through the preserved Transformers/PEFT engine when dependencies are available.</span></div></div></div><div><h2 class="panel-title" style="margin-bottom:12px">Architecture</h2><div class="info-list"><div class="info-row"><span>Frontend</span><strong>HTML · CSS · JavaScript</strong></div><div class="info-row"><span>Backend</span><strong>Python standard library</strong></div><div class="info-row"><span>Storage</span><strong>JSONL + JSON metadata</strong></div><div class="info-row"><span>Training</span><strong>Transformers / PEFT</strong></div><div class="info-row"><span>Network exposure</span><strong>127.0.0.1 only</strong></div></div><div class="callout" style="margin-top:14px">Actual training requires compatible model/tokenizer access and the optional PyTorch, Transformers, PEFT, Accelerate, Datasets, and Safetensors packages. Saving a dataset or a training configuration is not the same as training a model.</div></div></div>
    <div class="callout" style="margin-top:20px"><strong>Migration note.</strong> Original V13.3 datasets, templates, and base dataset are preserved in <span class="mono">archive/v13_3_dataset_library.zip</span>. The original terminal app is retained under <span class="mono">legacy/</span>.</div></div>`;
}

// User actions
function goPageFrom(el) { const page=el.dataset.go||el.dataset.page; if(page) setPage(page); }
document.addEventListener('click',async e=>{
  const go=e.target.closest('[data-go]'); if(go){setPage(go.dataset.go);return;}
  const open=e.target.closest('[data-open-dataset]'); if(open){state.explorerDatasetId=open.dataset.openDataset;state.explorerQuery='';setPage('explorer');return;}
  const edit=e.target.closest('[data-edit-dataset]'); if(edit){state.editorMeta={dataset_id:edit.dataset.editDataset};setPage('editor');return;}
  const validate=e.target.closest('[data-validate-dataset]'); if(validate){try{const r=await api(`/api/datasets/${encodeURIComponent(validate.dataset.validateDataset)}/validate`,{method:'POST',body:'{}'});toast(`Validation ${r.status}: ${r.records} records checked.` ,r.valid?'success':'error');}catch(err){toast(err.message,'error');}return;}
  const pageBtn=e.target.closest('.pagination [data-page]'); if(pageBtn){await renderLibrary(state.libraryKind,Number(pageBtn.dataset.page));return;}
  if(e.target.id==='librarySearchBtn'){state.libraryQuery=$('#librarySearch').value.trim();state.libraryCategory=$('#libraryCategory').value;state.libraryPage=1;await renderLibrary(state.libraryKind,1);return;}
  if(e.target.id==='selectPage'){
    $$('.dataset-check').forEach(cb=>{cb.checked=e.target.checked;if(cb.checked)state.selected.add(cb.dataset.id);else state.selected.delete(cb.dataset.id);});
    const merge=$('#mergeSelected');if(merge)merge.disabled=state.selected.size<2;return;
  }
  if(e.target.id==='mergeSelected'){
    if(state.selected.size<2)return;
    const name=prompt('Name for the merged dataset:','Merged dataset');if(!name)return;
    try{const r=await api('/api/datasets/merge',{method:'POST',body:JSON.stringify({dataset_ids:[...state.selected],name})});state.selected.clear();toast(`Merged ${r.records} records; removed ${r.duplicates_removed} duplicates.`);await loadStats();await renderLibrary(state.libraryKind,1);}catch(err){toast(err.message,'error');}return;
  }
  if(e.target.closest('[data-action="export-selected"]')){
    if(!state.selected.size)return;
    try {const items=[];for(const id of state.selected){items.push(await api('/api/export',{method:'POST',body:JSON.stringify({dataset_id:id,format:'jsonl'})}));}for(const item of items)downloadBase64(item);toast(`Exported ${items.length} dataset files.`);}catch(err){toast(err.message,'error');}return;
  }
  if(e.target.id==='explorerLoad'){
    const id=$('#explorerSelect').value;if(!id){toast('Choose a dataset first.','error');return;}state.explorerDatasetId=id;state.explorerQuery=$('#explorerSearch').value.trim();await loadExplorerDataset(id,state.explorerQuery,1);return;
  }
  if(e.target.id==='explorerClear'){state.explorerQuery='';$('#explorerSearch').value='';if(state.explorerDatasetId)await loadExplorerDataset(state.explorerDatasetId,'',1);return;}
  if(e.target.id==='explorerPrev'||e.target.id==='explorerNext'){
    const next=state.explorerPage+(e.target.id==='explorerNext'?1:-1);
    if(next>=1&&next<=state.explorerTotalPages)await loadExplorerDataset(state.explorerDatasetId,state.explorerQuery,next);return;
  }
  if(e.target.id==='genPreview'){
    const payload={kind:$('#genKind').value,topic:$('#genTopic').value,category:$('#genCategory').value,subcategory:$('#genSubcategory').value,count:Number($('#genCount').value),difficulty:$('#genDifficulty').value,writing_style:$('#genStyle').value,tone:$('#genTone').value,notes:$('#genNotes').value};
    try{state.generatorPayload=payload;state.generatorPreview=await api('/api/generator/preview',{method:'POST',body:JSON.stringify(payload)});renderGeneratorPreview(state.generatorPreview);toast(`Preview generated: ${state.generatorPreview.record_count} records.`);}catch(err){toast(err.message,'error');}return;
  }
  if(e.target.id==='genSave'){
    if(!state.generatorPreview)return;
    const payload={preview:state.generatorPreview,name:state.generatorPayload.topic,category:state.generatorPayload.category,subcategory:state.generatorPayload.subcategory,description:`Generated ${state.generatorPayload.kind} dataset for ${state.generatorPayload.topic}.`};
    try{const r=await api('/api/generator/save',{method:'POST',body:JSON.stringify(payload)});toast(`Saved ${r.dataset.name} to the library.`);state.generatorPreview=null;await loadStats();setPage('library');}catch(err){toast(err.message,'error');}return;
  }
  if(e.target.id==='genReset'){state.generatorPreview=null;state.generatorPayload=null;await renderGenerator();return;}
  if(e.target.id==='editorLoad'){const id=$('#editorSelect').value;if(!id){toast('Select a dataset first.','error');return;}try{await loadEditorDataset(id);}catch(err){toast(err.message,'error');}return;}
  if(e.target.id==='editorPrev'||e.target.id==='editorNext'){
    const next=state.editorPage+(e.target.id==='editorNext'?1:-1);
    if(next>=1&&next<=state.editorTotalPages){await loadEditorDataset(state.editorMeta.dataset_id,next);}return;
  }
  if(e.target.id==='addRecord'){
    state.editorRecords.push({messages:[{role:'user',content:''},{role:'assistant',content:''}]});renderEditorWorkspace();return;
  }
  const remove=e.target.closest('[data-remove-record]');if(remove){state.editorRecords.splice(Number(remove.dataset.removeRecord),1);renderEditorWorkspace();return;}
  if(e.target.id==='saveEditor'){
    try{const meta=state.editorMeta;const tags=$('#editorTags').value.split(',').map(x=>x.trim()).filter(Boolean);const start=(state.editorPage-1)*state.editorPageSize;const nextCount=state.editorTotalRecords-state.editorRecords.length+state.editorRecords.length;const insertedIndex=start+state.editorRecords.length-1;const nextPage=Math.max(1,Math.floor(insertedIndex/state.editorPageSize)+1);const r=await api(`/api/datasets/${encodeURIComponent(meta.dataset_id)}/save`,{method:'POST',body:JSON.stringify({records:state.editorRecords,page:state.editorPage,page_size:state.editorPageSize,description:$('#editorDescription').value,tags,name:$('#editorName').value})});state.editorMeta=r.dataset;toast(`Saved a new dataset version (${r.dataset.version}).`);await loadEditorDataset(meta.dataset_id,Math.min(nextPage,Math.max(1,Math.ceil(r.dataset.number_of_records/state.editorPageSize))));await loadStats();}catch(err){toast(err.message,'error');}return;
  }
  if(e.target.id==='editorValidate'){
    try{const r=await api(`/api/datasets/${encodeURIComponent(state.editorMeta.dataset_id)}/validate`,{method:'POST',body:'{}'});toast(`Dataset validation: ${r.status} · ${r.records} records.`,r.valid?'success':'error');}catch(err){toast(err.message,'error');}return;
  }
  if(e.target.id==='splitEditor'){
    if(!state.editorMeta)return;const ratio=Number(prompt('Train partition ratio (0.1–0.9):','0.8'));if(!ratio)return;
    try{const r=await api(`/api/datasets/${encodeURIComponent(state.editorMeta.dataset_id)}/split`,{method:'POST',body:JSON.stringify({ratio})});toast(`Created ${r.train_records} / ${r.validation_records} record splits.`);await loadStats();}catch(err){toast(err.message,'error');}return;
  }
  if(e.target.id==='deleteEditor'){
    if(!state.editorMeta)return;const settings=state.settings||await api('/api/settings');if(settings.preferences?.confirm_destructive_actions!==false&&!confirm(`Delete “${state.editorMeta.name}”? A recoverable backup will be kept.`))return;
    try{const r=await api(`/api/datasets/${encodeURIComponent(state.editorMeta.dataset_id)}/delete`,{method:'POST',body:'{}'});toast(`Dataset deleted. Backup saved to ${r.backup}.`);state.editorMeta=null;state.editorRecords=[];await loadStats();setPage('library');}catch(err){toast(err.message,'error');}return;
  }
  if(e.target.id==='loadVersions'){
    if(!state.editorMeta)return;try{const r=await api('/api/versions?dataset_id='+encodeURIComponent(state.editorMeta.dataset_id));$('#versionList').innerHTML=r.versions.length?`<div class="check-list">${r.versions.map(v=>`<div class="check-item"><span class="check-mark">↳</span><span>${esc(v.name)} · ${size(v.size_bytes)}</span></div>`).join('')}</div>`:empty('No backups yet','The first versioned save will create a backup.');}catch(err){toast(err.message,'error');}return;
  }
  if(e.target.id==='validateAll'){
    const host=$('#validatorResult');host.innerHTML=loading();try{const r=await api('/api/validate-all',{method:'POST',body:'{}'});host.innerHTML=`<div class="stats-grid" style="grid-template-columns:repeat(4,minmax(0,1fr))"><div class="stat-card"><div class="stat-top">Datasets checked</div><div class="stat-number">${n(r.datasets_checked)}</div></div><div class="stat-card"><div class="stat-top">Records checked</div><div class="stat-number">${n(r.records_checked)}</div></div><div class="stat-card"><div class="stat-top">Errors</div><div class="stat-number">${n(r.error_count)}</div></div><div class="stat-card"><div class="stat-top">Cross-file duplicates</div><div class="stat-number">${n(r.cross_dataset_duplicates)}</div></div></div><div class="callout ${r.status==='passed'?'good':'warn'}" style="margin-top:14px"><strong>${esc(r.status.toUpperCase())}</strong> · ${n(r.unique_records)} unique structured records detected across ${n(r.datasets_checked)} datasets.</div>${r.issues?.length?`<div class="table-wrap" style="margin-top:15px"><table><thead><tr><th>Dataset</th><th>Errors</th><th>Warnings</th><th>Cross-file duplicates</th></tr></thead><tbody>${r.issues.map(i=>`<tr><td>${esc(i.name)}</td><td>${n(i.errors)}</td><td>${n(i.warnings)}</td><td>${n(i.cross_dataset_duplicates)}</td></tr>`).join('')}</tbody></table></div>`:empty('No issues found','All inspected records passed the current checks.')}`;}catch(err){host.innerHTML=`<div class="callout warn">${esc(err.message)}</div>`;}return;
  }
  if(e.target.id==='saveSettings'){
    const identity={name:$('#identityName').value,description:$('#identityDescription').value,personality_preset:$('#identityPersonality').value,communication_style:$('#identityStyle').value,response_tone:$('#identityTone').value,default_behavior_profile:$('#identityBehaviour').value,selected_datasets:$('#identityDatasets').value.split(',').map(x=>x.trim()).filter(Boolean)};
    const provider={enabled:$('#providerEnabled').checked,base_url:$('#providerUrl').value,model:$('#providerModel').value,api_key_env:$('#providerEnv').value};
    const theme=$('input[name="themeChoice"]:checked')?.value||'dark';const preferences={confirm_destructive_actions:$('#prefConfirm').checked,auto_backup:$('#prefBackup').checked};
    try{state.settings=await api('/api/settings',{method:'POST',body:JSON.stringify({identity,provider,theme,preferences})});applyTheme(theme);syncIdentity();toast('Settings saved.');}catch(err){toast(err.message,'error');}return;
  }
  if(e.target.id==='themeToggle'){
    const current=document.documentElement.dataset.theme||'dark';const theme=current==='dark'?'light':'dark';try{state.settings=await api('/api/settings',{method:'POST',body:JSON.stringify({theme})});applyTheme(theme);toast(`Switched to ${theme} theme.`);}catch(err){toast(err.message,'error');}return;
  }
  if(e.target.id==='refreshAnalytics'){await renderAnalytics();return;}
  if(e.target.id==='exportOne'){
    const id=$('#exportDataset').value;if(!id){toast('Select a dataset to export.','error');return;}try{downloadBase64(await api('/api/export',{method:'POST',body:JSON.stringify({dataset_id:id,format:$('#exportFormat').value})}));toast('Dataset export prepared.');}catch(err){toast(err.message,'error');}return;
  }
  if(e.target.id==='exportAll'){
    try{downloadBase64(await api('/api/export/all',{method:'POST',body:JSON.stringify({kind:$('#exportKind').value})}));toast('Library ZIP archive prepared.');}catch(err){toast(err.message,'error');}return;
  }
  if(e.target.id==='importUpload'){
    if(!state.importedFile)return;const file=state.importedFile;const extension=file.name.split('.').pop().toLowerCase();const format=extension==='ndjson'?'jsonl':extension;
    if(!['jsonl','json','csv'].includes(format)){toast('Select a JSONL, JSON, or CSV file.','error');return;}
    try{const content=await file.text();const r=await api('/api/import',{method:'POST',body:JSON.stringify({filename:file.name,format,content,kind:$('#importKind').value,name:$('#importName').value,category:$('#importCategory').value,subcategory:$('#importSubcategory').value})});toast(`Imported ${r.imported_records} records into ${r.dataset.name}.`);await loadStats();}catch(err){toast(err.message,'error');}return;
  }
  if(e.target.id==='saveTrainingConfig'){
    const cfg=readTrainingConfig();state.trainingConfig=cfg;try{await api('/api/training/config',{method:'POST',body:JSON.stringify(cfg)});toast('Training configuration saved.');}catch(err){toast(err.message,'error');}return;
  }
  if(e.target.id==='trainPreflight'){
    const cfg=readTrainingConfig();state.trainingConfig=cfg;try{const r=await api('/api/training/preflight',{method:'POST',body:JSON.stringify(cfg)});state.trainingReport=r;$('#trainingPreflight').innerHTML=renderPreflight(r);$('#trainStart').disabled=!r.valid||!r.actual_training_available;toast(r.valid?'Preflight complete.':'Preflight found configuration errors.',r.valid?'success':'error');}catch(err){toast(err.message,'error');}return;
  }
  if(e.target.id==='trainStart'){
    const cfg=readTrainingConfig();try{const r=await api('/api/training/start',{method:'POST',body:JSON.stringify(cfg)});state.trainingStatus=await api('/api/training/status');renderTrainingMonitor();toast('Actual training process started.');if(trainingPoll)clearInterval(trainingPoll);trainingPoll=setInterval(pollTraining,2500);}catch(err){toast(err.message,'error');}return;
  }
  if(e.target.id==='downloadTrainingConfig'){
    const blob=new Blob([JSON.stringify(readTrainingConfig(),null,2)],{type:'application/json'});downloadBlob(blob,'dataforge_training_config.json');toast('Configuration downloaded.');return;
  }
  if(e.target.id==='retry-page'){await renderPage();return;}
});

document.addEventListener('change',async e=>{
  if(e.target.matches('.dataset-check')){
    if(e.target.checked)state.selected.add(e.target.dataset.id);else state.selected.delete(e.target.dataset.id);
    const merge=$('#mergeSelected');if(merge)merge.disabled=state.selected.size<2;
    const exportBtn=$('#export-selected');if(exportBtn)exportBtn.disabled=state.selected.size<1;
  }
  if(e.target.id==='importFile'){
    state.importedFile=e.target.files?.[0]||null;$('#importFileName').textContent=state.importedFile?`${state.importedFile.name} · ${size(state.importedFile.size)}`:'No file selected';$('#importUpload').disabled=!state.importedFile;
  }
  if(e.target.matches('[data-training-id]')){
    if(!state.trainingSelectedIds)state.trainingSelectedIds=new Set();
    if(e.target.checked)state.trainingSelectedIds.add(e.target.dataset.trainingId);else state.trainingSelectedIds.delete(e.target.dataset.trainingId);
    $('#trainingSelectedCount').textContent=`${state.trainingSelectedIds.size} selected`;
  }
});

document.addEventListener('input',e=>{
  if(state.editorMeta && e.target.id==='editorName') state.editorMeta.name=e.target.value;
  if(state.editorMeta && e.target.id==='editorDescription') state.editorMeta.description=e.target.value;
  if(state.editorMeta && e.target.id==='editorTags') state.editorMeta.tags=e.target.value.split(',').map(x=>x.trim()).filter(Boolean);
  if(e.target.matches('[data-record-field]')){
    const idx=Number(e.target.dataset.index);const role=e.target.dataset.recordField;const record=state.editorRecords[idx];if(!record)return;
    let m=record.messages.find(x=>x.role===role);if(!m){m={role,content:''};record.messages.push(m);}m.content=e.target.value;
  }
});

document.addEventListener('keydown',e=>{
  if(e.target.id==='librarySearch'&&e.key==='Enter')$('#librarySearchBtn')?.click();
  if(e.target.id==='trainingSearch'&&e.key==='Enter')runTrainingSearch();
  if(e.target.id==='exportSearch'&&e.key==='Enter')runExportSearch();
});

async function runTrainingSearch() {
  const q=$('#trainingSearch').value.trim();state.trainingSearch=q;
  const url='/api/datasets?page=1&page_size=60&q='+encodeURIComponent(q);
  try{const r=await api(url);state.trainingDatasets=r.datasets;$('#trainingDatasetList').innerHTML=renderTrainingDatasetItems();}catch(err){toast(err.message,'error');}
}
async function runExportSearch() {
  const q=$('#exportSearch').value.trim();state.exportSearch=q;
  try{const r=await api('/api/datasets?page=1&page_size=100&q='+encodeURIComponent(q));$('#exportDataset').innerHTML='<option value="">Select dataset…</option>'+r.datasets.map(d=>`<option value="${esc(d.dataset_id)}">${esc(d.name)}</option>`).join('');}catch(err){toast(err.message,'error');}
}
function renderPreflight(r) {
  const kind=r.valid?'good':'warn';
  return `<div class="callout ${kind}"><strong>${r.valid?'Preflight passed':'Preflight requires attention'}</strong><br>${r.records||0} records · ${r.training_records||0} training · ${r.validation_records||0} validation</div>${[...(r.errors||[]).map(x=>({kind:'bad',text:x})),...(r.warnings||[]).map(x=>({kind:'warn',text:x}))].length?`<div class="check-list" style="margin-top:11px">${[...(r.errors||[]).map(x=>({kind:'bad',text:x})),...(r.warnings||[]).map(x=>({kind:'warn',text:x}))].map(x=>`<div class="check-item"><span class="check-mark ${x.kind}">${x.kind==='bad'?'×':'!'}</span><span>${esc(x.text)}</span></div>`).join('')}</div>`:`<div class="check-item" style="margin-top:10px"><span class="check-mark">✓</span><span>Hardware limits and selected files are within the configured bounds.</span></div>`}${r.actual_training_available?'<div class="notice">Training dependencies are available. Model and tokenizer loading will still be verified at start.</div>':'<div class="notice">Actual training is unavailable until required dependencies and hardware conditions are satisfied. You can still save this configuration and export prepared data.</div>'}`;
}
function downloadBase64(item) {
  const bytes=Uint8Array.from(atob(item.content_base64),c=>c.charCodeAt(0));
  const blob=new Blob([bytes],{type:item.mime||'application/octet-stream'});downloadBlob(blob,item.filename||'dataforge_export');
}
function downloadBlob(blob,filename) {
  const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=filename;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1200);
}

$('#mobileMenu').addEventListener('click',()=>$('#sidebar').classList.toggle('open'));
// Bind all nav buttons through data-page after the document loads.
$$('.nav-item').forEach(el=>el.addEventListener('click',()=>setPage(el.dataset.page)));

(async function init(){
  try { await loadSettings(); const health=await api('/api/health'); $('#footerSystem').textContent=`Connected · ${health.version}`; await renderDashboard(); }
  catch(error) { $('#pageContent').innerHTML=`<div class="panel"><h2 class="panel-title">DATAFORGE could not connect to its local engine</h2><p class="page-description">${esc(error.message)}</p><button class="btn" onclick="location.reload()">Reconnect</button></div>`; }
})();
